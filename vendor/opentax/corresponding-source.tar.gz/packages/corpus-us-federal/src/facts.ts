/**
 * The fact catalog: every input the TY2025 federal corpus can consume.
 *
 * Facts with a `default` are documented assumptions — using one is recorded
 * in the proof's assumptions list. Facts without a default MUST be provided;
 * the engine refuses to answer without them.
 */

import type { FactSpec } from "@invaro/opentax-core";
import { OCCUPATION_ENUM } from "./occupations.js";

export const FILING_STATUSES = [
  "single",
  "mfj", // married filing jointly
  "mfs", // married filing separately
  "hoh", // head of household
  "qss", // qualifying surviving spouse
] as const;

export const facts: FactSpec[] = [
  {
    id: "filingStatus",
    type: "enum",
    enumValues: [...FILING_STATUSES],
    description:
      "Filing status (26 U.S.C. § 1, § 2). One of: single, mfj, mfs, hoh, qss.",
    // no default — the engine must never guess a filing status
  },
  {
    id: "wages",
    type: "money",
    min: "0",
    description:
      "Wages, salaries, tips (Form W-2 box 1), in dollars (e.g. 50000 or \"1234.56\").",
    // no default — the engine must never guess income
  },
  {
    id: "taxableInterest",
    type: "money",
    min: "0",
    description: "Taxable interest income, in dollars.",
    default: {
      value: "0",
      rationale: "Assumed no taxable interest absent contrary input",
    },
  },
  {
    id: "isAge65OrOlder",
    type: "bool",
    description:
      "Taxpayer attained age 65 before the close of the taxable year (26 U.S.C. § 63(f)(1)).",
    default: {
      value: false,
      rationale: "Assumed under 65 absent contrary input",
    },
  },
  {
    id: "isBlind",
    type: "bool",
    description: "Taxpayer is blind at the close of the taxable year (26 U.S.C. § 63(f)(2)).",
    default: { value: false, rationale: "Assumed not blind absent contrary input" },
  },
  {
    id: "spouseIsAge65OrOlder",
    type: "bool",
    description: "Spouse attained age 65 before the close of the taxable year.",
    default: {
      value: false,
      rationale: "Assumed spouse under 65 absent contrary input",
    },
  },
  {
    id: "spouseIsBlind",
    type: "bool",
    description: "Spouse is blind at the close of the taxable year.",
    default: {
      value: false,
      rationale: "Assumed spouse not blind absent contrary input",
    },
  },
  {
    id: "isClaimedAsDependent",
    type: "bool",
    description:
      "Taxpayer can be claimed as a dependent on another taxpayer's return (26 U.S.C. § 63(c)(5)).",
    default: {
      value: false,
      rationale: "Assumed not claimable as a dependent absent contrary input",
    },
  },
  {
    id: "qualifyingChildren",
    type: "int",
    min: "0",
    description:
      "Number of qualifying children under age 17 with required SSNs (26 U.S.C. § 24(c), (h)(7)).",
    default: {
      value: "0",
      rationale: "Assumed no qualifying children absent contrary input",
    },
  },
  {
    id: "foreignEarnedIncome",
    type: "money",
    min: "0",
    description:
      "Foreign earned income qualifying for the § 911 exclusion — ATTESTS a foreign tax home plus § 911(d)(1) qualification (bona fide residence for an entire taxable year, or 330 full days abroad in 12 months). Include these earnings in the wages/SE inputs too; the exclusion is computed and subtracted. The § 911(c) housing exclusion is not modeled. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no foreign earned income absent contrary input",
    },
  },
  {
    id: "fiduciaryType",
    type: "enum",
    enumValues: ["estate", "simple-trust", "complex-trust"],
    description:
      "Form 1041 filer type for the § 642(b) exemption: estate ($600), simple trust required to distribute all income currently ($300), or complex trust ($100). Grantor trusts do not file their own tax — use the grantor's individual return.",
    // no default — the engine must never guess the fiduciary type
  },
  {
    id: "fiduciaryIncomeBeforeExemption",
    type: "money",
    min: "0",
    description:
      "The estate/trust's taxable income BEFORE the § 642(b) exemption but AFTER the §§ 651/661 income-distribution deduction (the DNI machinery is attested by this input). In dollars.",
    // no default — the engine must never guess fiduciary income
  },
  {
    id: "fiduciaryLongTermGains",
    type: "money",
    min: "0",
    description:
      "Net long-term capital gain retained by the estate/trust. Any positive amount REFUSES — the § 1(h) preferential breakpoints for estates and trusts are not modeled. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no retained capital gains absent contrary input",
    },
  },
  {
    id: "householdEmployeeCashWages",
    type: "money",
    min: "0",
    description:
      "Cash wages paid to ONE household employee this year (Schedule H; nanny, housekeeper, caregiver). The § 3121(b)(3) family exclusions (spouse, child under 21, certain parents, under-18 students) must not be entered. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no household employees absent contrary input",
    },
  },
  {
    id: "householdFutaTestMet",
    type: "bool",
    description:
      "Total cash wages of $1,000 or more were paid to household employees in some calendar quarter of this or the preceding year (§ 3306(c)(2)) AND all state unemployment contributions were paid on time (the full 5.4% FUTA credit) — attested.",
    default: {
      value: false,
      rationale: "Assumed the FUTA quarter test not met absent contrary input",
    },
  },
  {
    id: "isFarmerOrFisherman",
    type: "bool",
    description:
      "Gross income from farming or fishing (including oyster farming) is at least 66⅔% of total gross income for this year or the preceding year (§ 6654(i)(2)) — attested. Switches the estimated-tax safe harbor to 66⅔% with a single January-15 installment.",
    default: {
      value: false,
      rationale: "Assumed not a qualifying farmer/fisherman absent contrary input",
    },
  },
  {
    id: "homeOfficeSquareFeet",
    type: "int",
    min: "0",
    description:
      "Square footage of the home used regularly and exclusively for business (§ 280A(c)(1) tests attested) — for the Rev. Proc. 2013-13 simplified method ($5/sq ft, 300 sq ft cap), exposed as a standalone target.",
    default: {
      value: "0",
      rationale: "Assumed no home office absent contrary input",
    },
  },
  {
    id: "corpIsREITorRIC",
    type: "bool",
    description:
      "The corporation is a real estate investment trust (§ 856) or regulated investment company (§ 851). REFUSES — their dividends-paid deduction and distribution requirements are not modeled.",
    default: {
      value: false,
      rationale: "Assumed not a REIT/RIC absent contrary input",
    },
  },
  {
    id: "taxExemptInterest",
    type: "money",
    min: "0",
    description:
      "Tax-exempt interest (e.g. municipal bonds, Form 1040 line 2a) — excluded from gross income but counted in the § 86 social-security provisional income and the § 36B premium-tax-credit MAGI. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no tax-exempt interest absent contrary input",
    },
  },
  {
    id: "slcspAnnualPremium",
    type: "money",
    min: "0",
    description:
      "Annual premium of the second-lowest-cost silver plan (SLCSP) benchmark for the taxpayer's coverage family (Form 1095-A line 33B) — the § 36B(b)(3)(B) applicable benchmark. Leave 0 if no Marketplace coverage. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no Marketplace coverage absent contrary input",
    },
  },
  {
    id: "marketplacePremiumsPaid",
    type: "money",
    min: "0",
    description:
      "Annual premiums for the Marketplace qualified health plan(s) actually enrolled in (Form 1095-A line 33A) — the § 36B(b)(2)(A) ceiling on the premium assistance amount. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no Marketplace premiums absent contrary input",
    },
  },
  {
    id: "advancePTC",
    type: "money",
    min: "0",
    description:
      "Advance premium tax credit payments made to the insurer during the year (Form 1095-A line 33C) — reconciled under § 36B(f). MFS RECONCILIATION (§ 36B(c)(1)(C)): an MFS filer with no domestic-abuse/abandonment exception is NOT an applicable taxpayer — PTC = $0 and ALL advance payments are additional tax (Schedule 2 line 2; if the PTC targets refuse the MFS case, add the repayment to line 17 yourself and disclose). The Form 8962 line 28 repayment limitation applies ONLY when household income is under 400% FPL (Table 5 amounts by filing status); at 400% or more line 28 is blank — repayment is UNCAPPED (2025 Form 8962 instructions, verified). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no advance PTC payments absent contrary input",
    },
  },
  {
    id: "ptcHouseholdSize",
    type: "int",
    min: "1",
    description:
      "Tax family size for the § 36B poverty-line lookup (§ 36B(d)(1): the taxpayer, spouse on a joint return, and dependents). Required when claiming the premium tax credit.",
    // no default — the poverty line must never be guessed
  },
  {
    id: "otherDependents",
    type: "int",
    min: "0",
    description:
      "Number of dependents (§ 152) OTHER than CTC qualifying children — e.g. children 17+, college students, parents — for the $500 credit for other dependents (§ 24(h)(4)); includes qualifying children without the required SSN (§ 24(h)(4)(C)).",
    default: {
      value: "0",
      rationale: "Assumed no other dependents absent contrary input",
    },
  },
  {
    id: "dependentCareExpenses",
    type: "money",
    min: "0",
    description:
      "Employment-related dependent care expenses paid (§ 21(b)(2)), NET of any § 129 dependent-care FSA exclusion. Enter only expenses enabling gainful employment for the care of a qualifying individual — attested. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no dependent care expenses absent contrary input",
    },
  },
  {
    id: "careQualifyingIndividuals",
    type: "int",
    min: "0",
    description:
      "Number of § 21(b)(1) qualifying individuals for the child and dependent care credit: a dependent under age 13, or a dependent/spouse physically or mentally incapable of self-care living with the taxpayer over half the year.",
    default: {
      value: "0",
      rationale: "Assumed no care-credit qualifying individuals absent contrary input",
    },
  },
  {
    id: "secondaryEarnedIncome",
    type: "money",
    min: "0",
    description:
      "On a JOINT return: the LOWER-earning spouse's earned income, for the § 21(d)(1)(B) expense limit (the credit cannot exceed either spouse's earned income). The § 21(d)(2) deemed income for a student/incapacitated spouse ($250/$500 per month) is not modeled. In dollars.",
    default: {
      value: "0",
      rationale:
        "Conservative: absent the lower earner's income a joint return gets no dependent-care credit — provide it to claim § 21",
    },
  },
  {
    id: "saversContributions",
    type: "money",
    min: "0",
    description:
      "The taxpayer's qualified retirement savings contributions for § 25B (elective deferrals, IRA contributions, ABLE contributions), NET of § 25B(d)(2) testing-period distributions — attested. Capped at $2,000 per individual by the rule. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no saver's-credit contributions absent contrary input",
    },
  },
  {
    id: "saversContributionsSpouse",
    type: "money",
    min: "0",
    description:
      "The spouse's qualified retirement savings contributions for § 25B on a joint return, net of testing-period distributions. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no spousal saver's-credit contributions absent contrary input",
    },
  },
  {
    id: "isFullTimeStudent",
    type: "bool",
    description:
      "Taxpayer is a full-time student (§ 152(f)(2)) — denies saver's-credit eligibility (§ 25B(c)(2)(B)).",
    default: {
      value: false,
      rationale: "Assumed not a full-time student absent contrary input",
    },
  },
  {
    id: "spouseIsFullTimeStudent",
    type: "bool",
    description:
      "Spouse is a full-time student (§ 152(f)(2)) — denies the spouse's saver's-credit eligibility (§ 25B(c)(2)(B)).",
    default: {
      value: false,
      rationale: "Assumed spouse not a full-time student absent contrary input",
    },
  },
  {
    id: "qualifiedAdoptionExpenses",
    type: "money",
    min: "0",
    description:
      "Qualified adoption expenses paid for a finalized adoption (§ 23(d)(1): reasonable adoption fees, court costs, attorney fees — not for adopting a spouse's child). The multi-year expense-timing rules of § 23(a)(2) are attested by entering the creditable year's amount. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no adoption expenses absent contrary input",
    },
  },
  {
    id: "adoptionIsSpecialNeeds",
    type: "bool",
    description:
      "The adoption is of a child with special needs, finalized this year (§ 23(a)(3), incl. determinations by Indian tribal governments per OBBBA § 70403) — the maximum credit is deemed paid regardless of actual expenses.",
    default: {
      value: false,
      rationale: "Assumed not a special-needs adoption absent contrary input",
    },
  },
  {
    id: "qualifiedTips",
    type: "money",
    min: "0",
    description:
      "Qualified tips (26 U.S.C. § 224): voluntary tips received in an occupation on the Treasury tipped-occupation list, already included in wages. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no qualified tips absent contrary input",
    },
  },
  {
    id: "occupation",
    type: "enum",
    enumValues: OCCUPATION_ENUM,
    description:
      "The taxpayer's tipped occupation, from the Treasury Tipped Occupation list (Treas. Reg. § 1.224-1, final Apr 2026). \"other\" = not on the list. Only demanded when qualified tips are claimed.",
    // no default — the engine must never guess whether a job is on the list
  },
  {
    id: "tipsWereVoluntary",
    type: "bool",
    description:
      "Tips were paid voluntarily by customers, determined by the payor, and not subject to negotiation (§ 224; Treas. Reg. § 1.224-1). Mandatory service charges do NOT qualify.",
    default: {
      value: true,
      rationale:
        "Assumed tips were voluntary and non-negotiated absent contrary input — mandatory service charges would not qualify",
    },
  },
  {
    id: "employerIsSSTB",
    type: "bool",
    description:
      "The tips were received in the course of an employer's specified service trade or business (§ 199A(d)(2)) — such tips are NOT qualified (§ 224).",
    default: {
      value: false,
      rationale:
        "Assumed the employer is not a specified service trade or business absent contrary input",
    },
  },
  {
    id: "qualifiedOvertimePremium",
    type: "money",
    min: "0",
    description:
      "Qualified overtime compensation (26 U.S.C. § 225): the FLSA § 7 premium portion in excess of the regular rate, already included in wages. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no qualified overtime premium absent contrary input",
    },
  },
  {
    id: "longTermCapitalGains",
    type: "money",
    min: "0",
    description:
      "Net long-term capital gains plus qualified dividends (taxed at the § 1(h) preferential rates). Losses are out of scope. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no capital gains or qualified dividends absent contrary input",
    },
  },
  {
    id: "netCapitalLoss",
    type: "money",
    min: "0",
    description:
      "Net capital LOSS for the year from Schedule D netting, entered as a positive number (26 U.S.C. § 1211(b): up to $3,000/$1,500 MFS against ordinary income; remainder carries over). Mutually exclusive with the gain facts AND with the per-bucket loss facts (shortTermCapitalLoss/longTermCapitalLoss) — this is the single OVERALL net result; for mixed years (gain in one bucket, loss in the other) use the per-bucket facts and the engine performs the § 1222 netting. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no net capital loss absent contrary input",
    },
  },
  {
    id: "shortTermCapitalLoss",
    type: "money",
    min: "0",
    description:
      "Net short-term capital LOSS for the year (Schedule D line 7 when negative, entered positive). The ST bucket's single NET result — mutually exclusive with shortTermCapitalGains and with netCapitalLoss. Combine with longTermCapitalGains for mixed years: the engine performs the § 1222 cross-netting (a net ST loss first reduces net LT gain per § 1222(11); any overall loss is capped by § 1211(b)). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no net short-term capital loss absent contrary input",
    },
  },
  {
    id: "longTermCapitalLoss",
    type: "money",
    min: "0",
    description:
      "Net long-term capital LOSS for the year (Schedule D line 15 when negative, entered positive). The LT bucket's single NET result — mutually exclusive with longTermCapitalGains and with netCapitalLoss. Combine with shortTermCapitalGains for mixed years: the engine performs the § 1222 cross-netting (a net LT loss reduces the ordinary-rate net ST gain per § 1222(9); any overall loss is capped by § 1211(b)). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no net long-term capital loss absent contrary input",
    },
  },
  {
    id: "qualifiedDividends",
    type: "money",
    min: "0",
    description:
      "Qualified dividends (Form 1099-DIV box 1b) as a STANDALONE fact — use this instead of folding them into longTermCapitalGains whenever a net capital LOSS also exists (dividends are not capital gains: the § 1211(b) loss offset never touches them, and they keep § 1(h) preferential rates). When there is no capital loss, folding qualified dividends into longTermCapitalGains remains equivalent and supported. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no qualified dividends absent contrary input",
    },
  },
  {
    id: "shortTermCapitalGains",
    type: "money",
    min: "0",
    description:
      "Net short-term capital gain after Schedule D netting, ordinary-rate (§ 1222(5)). Counts as § 32(i) disqualified investment income and § 1411 net investment income. Mutually exclusive with netCapitalLoss (provide the single NET Schedule D result: ST gain and/or LT gain, or a net loss — never both gain and loss). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no net short-term capital gain absent contrary input",
    },
  },
  {
    id: "ordinaryDividends",
    type: "money",
    min: "0",
    description:
      "Ordinary (non-qualified) dividends, taxed at ordinary rates — do NOT fold into otherOrdinaryIncome: dividends count as § 32(i) disqualified income and § 1411 net investment income (Form 1099-DIV box 1a minus box 1b). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no ordinary (non-qualified) dividends absent contrary input",
    },
  },
  {
    id: "selfEmploymentNetProfit",
    type: "money",
    min: "0",
    description:
      "Net profit from self-employment (Schedule C line 31: gross receipts minus ACTUAL Schedule C expenses). Do NOT subtract intake fields like 'W-2 Wages Paid' that exist for the § 199A wage limit — those belong in qbiW2Wages, not here. A loss year goes in scheduleCNetLoss instead (leave this at 0). GROSS-RECEIPTS COMPOSITION: the intake's own gross-receipts field PLUS every 1099-NEC and 1099-K nested under (or issued to) the business PLUS any 1099-MISC box 3 'other income' issued to a filer who operates a Schedule C business (a payer's MISC box-3 payment to an active sole proprietor is business income, not Schedule 1 line 8z) — 1099-MISC box 1 rents belong on Schedule E, never here. A 1099 whose recipient TIN matches NEITHER spouse is not this return's income: exclude it and disclose. PLACEHOLDER/TEMPLATE DOCUMENTS: a 1099 whose payer block is an unfilled template — no payer name, address line 'City, AK 99999' or a similar all-9s placeholder — is an inactive template document, not income: exclude every box on it (income AND withholding) and disclose; a 1099 from a NAMED payer at a real-looking address is live data even when the structured intake has no matching entry. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no self-employment income absent contrary input",
    },
  },
  {
    id: "hasChildUnderSix",
    type: "bool",
    description:
      "At least one qualifying child was under age six at year end — gates the California Young Child Tax Credit (R&TC § 17052.1, us.ca.yctc).",
    default: {
      value: "false",
      rationale: "Assumed no child under six absent contrary input",
    },
  },
  {
    id: "caRentedPrincipalResidence",
    type: "bool",
    description:
      "Rented (did not own) a principal residence in California for at least half of the tax year, was not claimed as a dependent, and the property was not exempt from California property tax — the eligibility gate for the California nonrefundable renter's credit (FTB 540, us.ca.renters_credit).",
    default: {
      value: "false",
      rationale: "Assumed not a qualifying California renter absent contrary input",
    },
  },
  {
    id: "caAmti",
    type: "money",
    min: "0",
    description:
      "California alternative minimum taxable income (Schedule P (540) Part I, line 17) — AGENT-COMPUTED per the R&TC §§ 17062(c)-(e), 17062.1 construction rules, then fed to the CA AMT target (us.ca.amt). CONSTRUCTION NOTES (disclose when composing this figure): California individual AMT is FROZEN to IRC §§ 55-59 as they read on January 1, 2015 (R&TC § 17062.1, re-enacted by SB 711, Stats. 2025 Ch. 231, WITHOUT moving the freeze forward, even though SB 711 rolled CA's general IRC conformity date to January 1, 2025 for other provisions). Starting from CA taxable income (Form 540 line 19), the STANDARD DEDUCTION IS ADDED BACK (R&TC § 17062(c)(1), denying § 56(b)(1)(E)). The ISO exercise spread follows § 56(b)(3) as modified by R&TC § 17062(c)(2) (plus the California Qualified Stock Option addback, R&TC § 17502). There is NO tax-exempt private-activity-bond-interest preference (R&TC § 17062(d) turns off § 57(a)(5)) and NO AMT foreign tax credit (R&TC § 17062(e) turns off § 59(a)). A taxpayer whose aggregate trade/business gross receipts are under $1,000,000 (a flat threshold, NOT doubled for MFJ) excludes ALL trade/business income, adjustments, and preferences from AMTI (R&TC § 17062(b)(4), the CA small-business AMTI exclusion). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no CA AMT adjustments or preference items absent contrary input",
    },
  },
  {
    id: "caRegularTax",
    type: "money",
    min: "0",
    description:
      "California 'regular tax' for the Schedule P (540) Part II tentative-minimum-tax comparison (R&TC § 17062(a)(2)) — the Form 540 line 31 tax as reduced by the exemption credits already claimed, i.e. the figure Schedule P's own worksheet calls the regular tax. The CA AMT target (us.ca.amt) computes AMT = max(0, TMT − this amount). In dollars.",
    default: {
      value: "0",
      rationale:
        "Assumed no CA regular tax absent contrary input — note this OVERSTATES computed AMT when a real regular-tax figure exists; supply the actual amount whenever claiming us.ca.amt",
    },
  },
  {
    id: "scheduleCNetLoss",
    type: "money",
    min: "0",
    description:
      "Schedule C/F net LOSS for the year as a POSITIVE number (gross receipts minus ACTUAL expenses is negative; § 165(c)(1) trade-or-business loss). Reduces gross income AND § 32(c)(2) earned income (EITC/ACTC); no SE tax attaches to a loss year. Schedule C ONLY — Schedule E losses belong in nonpassiveScheduleELoss or the passive facts. A 'loss' that exists only because the intake's 'W-2 Wages Paid' field was subtracted is a misreading (that field is qbiW2Wages, never an expense). Gross-receipts composition follows selfEmploymentNetProfit's convention (intake receipts + nested 1099-NEC/K + 1099-MISC box 3 issued to the proprietor; MISC box 1 rents → Schedule E; TIN-mismatched 1099s excluded with disclosure). If QBI-flagged, also enter the same amount in qbiLossOffset. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no self-employment loss absent contrary input",
    },
  },
  {
    id: "k1OrdinaryBusinessIncome",
    type: "money",
    min: "0",
    description:
      "Ordinary business income from a partnership or S corporation Schedule K-1 (box 1) in which the taxpayer MATERIALLY participates — QBI-eligible (§ 199A) but not subject to SE tax or payroll tax (an S-corp shareholder's share, or a non-SE partnership allocation; a general partner's SE-taxable share belongs in selfEmploymentNetProfit instead). Material participation keeps it out of § 1411 net investment income — disclosed. Losses out of scope. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no K-1 pass-through business income absent contrary input",
    },
  },
  {
    id: "qbiW2Wages",
    type: "money",
    min: "0",
    description:
      "W-2 wages PAID BY the qualified trade or business, allocable to QBI (§ 199A(b)(4)) — drives the above-threshold wage limit. Intake forms often label this 'W-2 Wages Paid' under the business section: it is a § 199A LIMIT input, NOT a Schedule C expense — never subtract it from selfEmploymentNetProfit. Defaults to $0, which can only understate the deduction (conservative). In dollars.",
    default: {
      value: "0",
      rationale:
        "Assumed the business paid no W-2 wages absent contrary input (conservative above the threshold)",
    },
  },
  {
    id: "qbiUBIA",
    type: "money",
    min: "0",
    description:
      "Unadjusted basis immediately after acquisition of the business's qualified property (§ 199A(b)(6)) — the 2.5% prong of the wage limit. Defaults to $0 (conservative). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no qualified-property UBIA absent contrary input (conservative)",
    },
  },
  {
    id: "businessIsSSTB",
    type: "bool",
    description:
      "The trade or business is a specified service trade or business (§ 199A(d)(2): health, law, accounting, consulting, financial services, athletics, performing arts, …) — above the threshold an SSTB's deduction phases to zero.",
    // no default — only demanded above the § 199A threshold, where it
    // decides everything; the engine must never guess it
  },
  {
    id: "sepContribution",
    type: "money",
    min: "0",
    description:
      "Employer contribution to the self-employed taxpayer's own SEP-IRA or solo-401(k) profit-sharing (§ 404(h): up to 20% of net SE earnings after ½ SE tax, capped at the § 415(c) limit — $70,000 for 2025, $72,000 for 2026). In dollars. DEDUCTIBLE-LIMIT CONVENTION: when a documented SEP/Keogh contribution exceeds the limit, the deducted amount = 20% × (0.9235 × total Schedule C net profit − the ½-SE-tax deduction), rounded half-up — the § 401(c)(2)/§ 1402(a)(12) reading that applies BOTH the 92.35% factor AND the ½-SE subtraction. (Note: Pub. 560's worksheet applies only the ½-SE subtraction; this engine follows the statutory § 1402(a)(12) reduction.) Pass the documented contribution and apply this cap when self-computing the Schedule 1 line 16 amount.",
    default: {
      value: "0",
      rationale: "Assumed no self-employed retirement contribution absent contrary input",
    },
  },
  {
    id: "selfEmployedHealthPremiums",
    type: "money",
    min: "0",
    description:
      "Health insurance premiums paid by a self-employed taxpayer for themselves, spouse, and dependents (§ 162(l)) — deductible up to the business's earned income; no employer-subsidized coverage available (assumed, disclosed). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no self-employed health insurance premiums absent contrary input",
    },
  },
  {
    id: "employeeAnnualWages",
    type: "money",
    min: "0",
    description:
      "One employee's annual wages, for the employer-side payroll-tax target (§ 3111 FICA + FUTA). In dollars.",
    // no default — only demanded by the employer payroll target
  },
  {
    id: "qreCurrentYear",
    type: "money",
    min: "0",
    description:
      "Qualified research expenses for the current year (§ 41(b); § 41(d) qualification attested). In dollars.",
    // no default — only demanded by the research-credit target
  },
  {
    id: "qreAvgPrior3Years",
    type: "money",
    min: "0",
    description:
      "Average annual qualified research expenses over the 3 preceding years — 0 means no prior QREs (the 6% startup rate of § 41(c)(4)(B) applies). In dollars.",
    // no default — the rate regime turns on it; the engine must not guess
  },
  {
    id: "hsaContribution",
    type: "money",
    min: "0",
    description:
      "Personal HSA contributions (not through payroll) under 26 U.S.C. § 223; HDHP coverage assumed. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no HSA contributions absent contrary input",
    },
  },
  {
    id: "hsaCoverage",
    type: "enum",
    enumValues: ["self", "family"],
    description: "HDHP coverage type for HSA limits (§ 223(b)(2)).",
    // no default — only demanded when hsaContribution > 0
  },
  {
    id: "isAge55OrOlder",
    type: "bool",
    description:
      "Taxpayer is 55 or older (HSA catch-up contribution, § 223(b)(3)).",
    default: {
      value: false,
      rationale: "Assumed under 55 absent contrary input (denies the HSA catch-up — conservative)",
    },
  },
  {
    id: "studentLoanInterest",
    type: "money",
    min: "0",
    description:
      "Interest paid on qualified education loans (26 U.S.C. § 221). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no student loan interest absent contrary input",
    },
  },
  {
    id: "carLoanInterest",
    type: "money",
    min: "0",
    description:
      "Interest paid on a qualified passenger vehicle loan (26 U.S.C. § 163(h)(4)): new US-assembled personal-use vehicle purchased after 2024. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no qualified vehicle loan interest absent contrary input",
    },
  },
  {
    id: "charitableCashContributions",
    type: "money",
    min: "0",
    description:
      "Cash contributions to qualifying charities (26 U.S.C. § 170(p); DAFs and certain private foundations excluded). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no charitable cash contributions absent contrary input",
    },
  },
  {
    id: "stateAndLocalTaxesPaid",
    type: "money",
    min: "0",
    description:
      "State and local taxes paid that Schedule A can count (26 U.S.C. § 164(a)): state/local income (or elected general sales) taxes plus real and personal property taxes, personal portion only. Subject to the OBBBA § 164(b)(6) cap. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no deductible state and local taxes absent contrary input",
    },
  },
  {
    id: "mortgageInterestPaid",
    type: "money",
    min: "0",
    description:
      "Home mortgage interest paid on acquisition debt secured by a qualified residence (26 U.S.C. § 163(h)(3)); post-Dec-15-2017 origination assumed. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no home mortgage interest absent contrary input",
    },
  },
  {
    id: "mortgageAverageBalance",
    type: "money",
    min: "0",
    description:
      "Average balance of home acquisition debt for the year (Publication 936 method) — interest is prorated when this exceeds the $750,000 ($375,000 MFS) limit of § 163(h)(3).",
    // no default — only demanded when mortgageInterestPaid > 0; the engine
    // must never guess whether the $750k limit binds
  },
  {
    id: "medicalExpenses",
    type: "money",
    min: "0",
    description:
      "Unreimbursed medical and dental care expenses (26 U.S.C. § 213) — deductible over 7.5% of AGI when itemizing. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no unreimbursed medical expenses absent contrary input",
    },
  },
  {
    id: "casualtyFederalDisasterLosses",
    type: "money",
    min: "0",
    description:
      "Personal casualty losses attributable to FEDERALLY DECLARED disasters that are NOT qualified disaster losses (§ 165(h)(5)): the SUM over events of max(0, min(FMV decline, adjusted basis) − insurance − $100 per casualty) — the per-event Form 4684 lines 1–11 arithmetic is attested by the input. The 10%-of-AGI floor (§ 165(h)(2)) is applied by the engine; deductible only when itemizing. Non-declared personal casualty losses are nondeductible — do not enter them. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no federally-declared-disaster casualty losses absent contrary input",
    },
  },
  {
    id: "casualtyQualifiedDisasterLosses",
    type: "money",
    min: "0",
    description:
      "Net QUALIFIED disaster losses (Form 4684 line 15): the SUM over qualified-disaster events of max(0, min(FMV decline, adjusted basis) − insurance − $500 per casualty) — per-event arithmetic attested. NOT subject to the 10%-of-AGI floor, and allowed even WITHOUT itemizing by increasing the standard deduction (2025 Form 4684 instructions). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no qualified disaster losses absent contrary input",
    },
  },
  {
    id: "passiveActivityIncome",
    type: "money",
    min: "0",
    description:
      "Net INCOME from passive activities this year (§ 469(c): rentals without real-estate-professional status, passive royalties, passive K-1 income) — absorbs passive losses dollar-for-dollar on Form 8582. Transcribe the TOTAL including any self-rental income items, and ALSO flag the self-rental subset in selfRentalNetIncome — the rule itself excludes that subset from the absorption pool (Reg. § 1.469-2(f)(6)); do not pre-net. For the standalone target us.federal.passive_loss_allowed. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no passive-activity income absent contrary input",
    },
  },
  {
    id: "selfRentalNetIncome",
    type: "money",
    min: "0",
    description:
      "The SELF-RENTAL subset of passiveActivityIncome: net rental income items from property rented for use in a trade or business in which the taxpayer MATERIALLY participates (Reg. § 1.469-2(f)(6) recharacterizes each such item's net income as NOT from a passive activity, so it cannot absorb passive losses). Item by item, INCOME items only — a self-rented property that nets a LOSS stays passive (leave its loss in passiveActivityLosses; add nothing here for it). Report the income itself as nonpassive Schedule E income (k1OrdinaryBusinessIncome if QBI-eligible, else scheduleENetIncome); it is also OUT of net investment income for NIIT (Reg. § 1.1411-4(g)(6)(i) deems it ordinary-course). COMPOSING SCHEDULE E AFTERWARD: net the allowed passive loss against the QBI-flagged bucket FIRST — k1OrdinaryBusinessIncome = QBI-eligible income minus allowed QBI-flagged losses; only the non-QBI remainder goes in scheduleENetIncome (e.g. self-rental 10,000 QBI + royalty 2,000 non-QBI with 2,000 allowed QBI-flagged loss → k1 = 8,000, scheduleENetIncome = 2,000). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no self-rental income absent contrary input",
    },
  },
  {
    id: "passiveActivityLosses",
    type: "money",
    min: "0",
    description:
      "Total passive-activity losses claimed this year as a POSITIVE number (current-year passive losses plus prior-year suspended carryovers being applied). For the standalone target us.federal.passive_loss_allowed. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no passive-activity losses absent contrary input",
    },
  },
  {
    id: "rentalActiveParticipationLosses",
    type: "money",
    min: "0",
    description:
      "The portion of passiveActivityLosses from rental real estate in which the taxpayer ACTIVELY PARTICIPATED (§ 469(i)(1) — a lower bar than material participation: bona fide management decisions with ≥10% ownership, attested). Only this portion can use the § 469(i) $25,000 special allowance. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no active-participation rental losses absent contrary input",
    },
  },
  {
    id: "mfsConsideredUnmarried",
    type: "bool",
    description:
      "MFS filer meets the § 32(d)(2) separation requirements: a qualifying child lived with them for more than half the year, they furnished over half the cost of that household, AND either they are legally separated under a decree or the spouse was not a household member during the last 6 months of the year. Unlocks the EITC for an MFS filer (§ 32(d)(1)); without it MFS receives $0.",
    default: {
      value: false,
      rationale: "Assumed the § 32(d)(2) separation tests are not met (conservative: MFS gets no EITC)",
    },
  },
  {
    id: "mfsLivedApartAllYear",
    type: "bool",
    description:
      "MFS filer lived apart from the spouse AT ALL TIMES during the year — § 469(i)(5) (halves the special allowance to $12,500/$50,000; living together at any time = NO allowance) AND § 219(g)(4) (an MFS filer who lived apart all year is NOT treated as married for the IRA-deduction phaseout: the single ranges apply and no spousal-coverage attribution occurs) AND § 86(c)(1)(C)(ii) (the $0 social-security base amount applies only to an MFS filer who did NOT live apart all year; one who did uses the $25,000/$34,000 unmarried amounts).",
    default: {
      value: false,
      rationale:
        "Assumed the spouses lived together at some point (zero MFS allowance — conservative)",
    },
  },
  {
    id: "scheduleENetIncome",
    type: "money",
    min: "0",
    description:
      "Net Schedule E rental/royalty income AFTER § 469 netting (compute allowed passive losses with the standalone target us.federal.passive_loss_allowed, then enter the net POSITIVE result here) that is NOT QBI-eligible. NONPASSIVE Schedule E losses (§ 469(c)(7) real-estate professional) are not enterable here: net them against k1OrdinaryBusinessIncome when QBI-eligible (they reduce the QBI base too), else disclose a wage-substitution workaround and keep medicareWages/socialSecurityWages at their true W-2 values — QBI-eligible pass-through income belongs in k1OrdinaryBusinessIncome instead. Treated as ordinary income with no SE tax; NOT counted as § 1411 investment income by this corpus (nonpassive/self-rental character attested — passive rental income that IS investment income would be missed by the NIIT rule: disclosed limitation). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no non-QBI Schedule E income absent contrary input",
    },
  },
  {
    id: "pensionGrossPayments",
    type: "money",
    min: "0",
    description:
      "TOTAL pension/annuity payments received this year from a qualified-plan annuity with after-tax cost basis (1099-R box 1) — the § 72(d) Simplified Method computes the taxable part. Use taxablePensionsAndAnnuities instead (or additionally, for other pensions) when the taxable amount is already known. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no simplified-method annuity absent contrary input",
    },
  },
  {
    id: "pensionCostBasis",
    type: "money",
    min: "0",
    description:
      "Investment in the contract as of the annuity starting date — employee after-tax contributions (1099-R box 9b). The § 72(d)(1)(B) monthly exclusion is this divided by the anticipated-payments table number; lifetime recovery is capped at this amount. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed zero after-tax basis (fully taxable pension) absent contrary input",
    },
  },
  {
    id: "pensionAgeAtStart",
    type: "int",
    min: "0",
    max: "120",
    description:
      "Primary annuitant's age at the ANNUITY STARTING DATE (not current age) — picks the § 72(d)(1)(B)(iii) single-life anticipated-payments band (≤55: 360, 56-60: 310, 61-65: 260, 66-70: 210, 71+: 160). Required when pensionCostBasis is set and the annuity is single-life.",
    default: {
      value: "0",
      rationale: "Unset; the simplified-method rule refuses rather than assume an age band",
    },
  },
  {
    id: "pensionIsJointAndSurvivor",
    type: "bool",
    description:
      "True for an annuity payable over more than one life with a starting date after 1997 — the § 72(d)(1)(B)(iv) COMBINED-ages table applies (set pensionCombinedAgesAtStart).",
    default: {
      value: false,
      rationale: "Assumed a single-life annuity absent contrary input",
    },
  },
  {
    id: "pensionCombinedAgesAtStart",
    type: "int",
    min: "0",
    max: "240",
    description:
      "Combined ages of both annuitants at the annuity starting date, for joint-and-survivor annuities (§ 72(d)(1)(B)(iv): ≤110: 410, 111-120: 360, 121-130: 310, 131-140: 260, 141+: 210).",
    default: {
      value: "0",
      rationale: "Unset; the simplified-method rule refuses rather than assume a band",
    },
  },
  {
    id: "pensionMonthsThisYear",
    type: "int",
    min: "1",
    max: "12",
    description:
      "Number of monthly annuity payments received this tax year (Simplified Method Worksheet line 4 multiplier). 12 for a full year.",
    default: {
      value: "12",
      rationale: "Assumed a full year of monthly payments absent contrary input",
    },
  },
  {
    id: "pensionBasisPreviouslyRecovered",
    type: "money",
    min: "0",
    description:
      "Cost basis already recovered tax-free in prior years (Simplified Method Worksheet line 6) — lifetime recovery cannot exceed pensionCostBasis for post-1986 starting dates. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed the first year of the annuity absent contrary input",
    },
  },
  {
    id: "rentalDepreciableBasis",
    type: "money",
    min: "0",
    description:
      "Depreciable basis of residential rental BUILDING(S) — cost basis excluding land (land never depreciates, § 167; Pub 527 ch. 2). Drives the § 168 GDS 27.5-year straight-line mid-month depreciation (Pub 946 Table A-6). Set rentalPlacedInServiceMonth for a first-year property; leave it 0 for property in service the whole year. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no depreciable rental property absent contrary input",
    },
  },
  {
    id: "rentalPlacedInServiceMonth",
    type: "int",
    min: "0",
    max: "12",
    description:
      "Month (1-12) the residential rental property was placed in service THIS tax year — first-year depreciation uses the § 168(d)(2) mid-month convention (Pub 946 Table A-6 row 1). 0 (the default) = placed in service in a PRIOR year: the steady-state 3.636% year applies.",
    default: {
      value: "0",
      rationale: "Assumed the property was in service before this year (steady-state 3.636% year) absent contrary input",
    },
  },
  {
    id: "rentalIncomeBeforeDepreciation",
    type: "money",
    min: "0",
    description:
      "Schedule E rental result BEFORE depreciation: rents received minus cash operating expenses (management, repairs, insurance, taxes, mortgage interest…). The engine subtracts the computed § 168 depreciation to reach net rental income. Use scheduleENetIncome instead when you already have the after-depreciation net; the two inputs add (separate properties). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no rental activity reported through the depreciation path absent contrary input",
    },
  },
  {
    id: "businessMilesDriven",
    type: "int",
    min: "0",
    description:
      "Business miles driven for the optional standard mileage rate (70¢/mile for 2025 per Notice 2025-5; 72.5¢/mile for 2026 per Notice 2026-10) — the standalone target us.federal.vehicle_standard_mileage computes the deduction; subtract it from your Schedule C profit yourself.",
    default: {
      value: "0",
      rationale: "Assumed no business mileage absent contrary input",
    },
  },
  {
    id: "isRetiredOnTotalDisability",
    type: "bool",
    description:
      "Retired on permanent and total disability (§ 22(e)(3)) — a § 22(b) qualified individual even under age 65. Set this whenever the taxpayer is documented as retired on permanent and total disability. The physician's statement (Schedule R Part II) is a KEEP-FOR-RECORDS substantiation requirement, not filed with the return — an intake answer that no statement is on file yet does NOT zero the credit; disclose the substantiation gap instead.",
    default: {
      value: false,
      rationale: "Assumed not retired on total disability absent contrary input",
    },
  },
  {
    id: "scheduleRDisabilityIncome",
    type: "money",
    min: "0",
    description:
      "Taxable disability income under §§ 72/105(a) (e.g. a code-3 1099-R reported as wages before minimum retirement age) — caps the § 22(c)(2) initial amount for an under-65 disabled individual. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no § 72/105(a) disability income absent contrary input",
    },
  },
  {
    id: "nontaxableBenefitsForScheduleR",
    type: "money",
    min: "0",
    description:
      "Nontaxable social security, railroad retirement, VA pensions and other excluded disability benefits (§ 22(c)(3)) — reduce the § 22 amount dollar-for-dollar. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no § 22(c)(3) nontaxable benefits absent contrary input",
    },
  },
  {
    id: "qbiLossOffset",
    type: "money",
    min: "0",
    description:
      "QBI-eligible LOSSES (positive number) from activities NOT in selfEmploymentNetProfit/k1OrdinaryBusinessIncome — e.g. an allowed nonpassive § 469(c)(7) rental loss flagged as QBI. Reduces the § 199A QBI base only (Reg. § 1.199A-1(d)(2)(iii)); enter the income-side effect via nonpassiveScheduleELoss. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no external QBI losses absent contrary input",
    },
  },
  {
    id: "nonpassiveScheduleELoss",
    type: "money",
    min: "0",
    description:
      "NONPASSIVE Schedule E losses as a positive number (§ 469(c)(7) real-estate-professional rentals with material participation, or allowed § 469 losses not netted elsewhere) — subtracts from gross income. Schedule E ONLY: never route a Schedule C amount here. A Schedule C 'loss' that exists only because the intake's 'W-2 Wages Paid' field was subtracted is a misreading — that field is the § 199A wage-limit input (qbiW2Wages), never an expense; Schedule C profit = gross receipts minus ACTUAL Schedule C expenses. If the activity is QBI-flagged, also enter the same amount in qbiLossOffset. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no nonpassive Schedule E losses absent contrary input",
    },
  },
  {
    id: "medicareWages",
    type: "money",
    min: "0",
    description:
      "W-2 box 5 Medicare wages and tips — the Form 8959 Additional-Medicare-Tax base. Often HIGHER than box 1 (pre-tax 401(k) deferrals reduce box 1 but not box 5). Leave 0 to approximate with box 1 wages (understates the tax when box 5 > box 1 — disclosed). In dollars.",
    default: {
      value: "0",
      rationale:
        "Approximated by box 1 wages absent contrary input (Form 8959 wants box 5)",
    },
  },
  {
    id: "niitInvestmentExpenses",
    type: "money",
    min: "0",
    description:
      "Deductions properly allocable to investment income for the § 1411 net investment income tax (Form 8960 lines 9–10: investment interest expense, allocable state income tax, and other modifications). Subtracted from gross investment income. COORDINATION: if you applied a § 163(d)(4)(B) election by moving elected capital gain from longTermCapitalGains to otherOrdinaryIncome, that gain already left the NII base — do NOT also enter the matching investment interest here (it would double-reduce NII). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no properly-allocable investment deductions absent contrary input",
    },
  },
  {
    id: "investmentInterestDeduction",
    type: "money",
    min: "0",
    description:
      "Investment interest expense DEDUCTIBLE this year (§ 163(d), Form 4952 line 8) — AFTER the net-investment-income limit and any § 163(d)(4)(B) election, which are attested by the input (the engine does not run Form 4952). RUN THE LIMIT FIRST: with no net investment income (taxable interest + ordinary dividends + elected gains), the deductible amount is $0 and the whole expense carries forward — enter 0, not the amount paid. An itemized deduction; excess carries forward outside this corpus. If an election treated capital gain as investment income, also move that amount from longTermCapitalGains to otherOrdinaryIncome yourself. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no deductible investment interest absent contrary input",
    },
  },
  {
    id: "gamblingLossesItemized",
    type: "money",
    min: "0",
    description:
      "Gambling losses deductible as an itemized deduction (§ 165(d), Schedule A line 16) — LIMITED TO GAMBLING WINNINGS included in income: enter min(losses paid, winnings reported), attested by the input (the engine does not track the per-session limit). TY2025: the full limited amount deducts; the OBBBA 90%-of-losses haircut (§ 165(d) as amended) applies only to taxable years beginning after 12/31/2025. Itemized-only; never reduces winnings directly. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no deductible gambling losses absent contrary input",
    },
  },
  {
    id: "otherItemizedDeductions",
    type: "money",
    min: "0",
    description:
      "Other itemized deductions (Schedule A line 16, attested): impairment-related work expenses of a disabled individual (§ 67(d) — NOT subject to the suspended 2% floor), federal estate tax on income in respect of a decedent, amortizable bond premium, and the other line-16 write-ins. Gambling losses have their own fact (gamblingLossesItemized). Enter the documented total — deductible in full. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no Schedule A line-16 write-in deductions absent contrary input",
    },
  },
  {
    id: "noncashCharitableContributions",
    type: "money",
    min: "0",
    description:
      "Noncash charitable contributions deductible this year (§ 170, Form 8283) — the 20/30/50%-of-AGI property limits and appraisal requirements are ATTESTED by the input (enter the allowed amount, INCLUDING prior-year carryovers used this year). Itemized-only; does not qualify for § 170(p). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no noncash charitable contributions absent contrary input",
    },
  },
  {
    id: "socialSecurityWages",
    type: "money",
    min: "0",
    description:
      "W-2 box 3 social security wages for the SE-tax OASDI wage-base coordination (Schedule SE line 8a). PER PERSON: Schedule SE belongs to ONE individual — on a joint return enter ONLY the SE-earner's own box 3, never the couple's sum (summing can wrongly zero the OASDI portion). Leave 0 to approximate with box 1 wages. In dollars.",
    default: {
      value: "0",
      rationale:
        "Approximated by box 1 wages absent contrary input (Schedule SE line 8a wants box 3)",
    },
  },
  {
    id: "socialSecurityWagesProvided",
    type: "bool",
    description:
      "socialSecurityWages is an EXPLICIT figure for the self-employment earner — set it (with socialSecurityWages, even $0) when that person's own W-2 box 3 is known, so Schedule SE line 8a uses it instead of falling back to box-1 wages. The documents compiler sets it from W-2 recipients; a joint return where the SE earner has no W-2 needs it with socialSecurityWages 0 (us.federal.se_tax).",
    default: { value: false, rationale: "Not provided — Schedule SE line 8a falls back to box-1 wages when box 3 is absent" },
  },
  {
    id: "stateTaxableIncome",
    type: "money",
    min: "0",
    description:
      "STATE taxable income (e.g. CA Form 540 line 19, VA Form 760 line 15, IL net income line 11) — computed by the preparer under state law, then fed to the state tax targets (us.ca.income_tax, us.va.income_tax, us.il.income_tax) so the rate-schedule arithmetic is engine-pinned instead of recalled. In dollars. NM: PIT-1 line 17 (us.nm.income_tax).",
    default: {
      value: "0",
      rationale: "Assumed no state taxable income absent contrary input",
    },
  },
  {
    id: "nyYonkersBase",
    type: "money",
    min: "0",
    description:
      "Yonkers resident surcharge base (2025 IT-201-I Yonkers worksheet, line m) — NOT the same as IT-201 line 46 ('Total New York State taxes'). It is line 46 MINUS a specific credit bundle: the Empire State child credit (IT-213 line 9) + real property tax credit (IT-214 line 20) + child/dependent care credit (IT-216 line 14) + earned income credit (IT-215 line 16) + noncustodial parent EIC (IT-209 line 32/42) + college tuition credit (IT-272 line 5/7) + IT-201 lines 69/69a + IT-201-ATT line 13 other credits, net of a STAR reconciliation add-back (Form IT-119 line 3) — agent-composed per the worksheet, then fed to us.ny.yonkers_surcharge (16.75% x this base, feeds IT-201 LINE 55, not line 54 which is MCTMT). Only relevant when IT-201 line 46 is more than $0 and the taxpayer was a Yonkers resident. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no Yonkers resident surcharge base absent contrary input (not a Yonkers resident, or line 46 is $0)",
    },
  },
  {
    id: "nyIt214Fagi",
    type: "money",
    min: "0",
    description:
      "Federal adjusted gross income for the NY IT-214 Real Property Tax Credit (Form IT-214 line 8) — gates AND buckets the flat Table A/Table B lookup (us.ny.it214). Over $18,000 disqualifies the credit entirely ('If line 8 is more than $18,000, stop; you do not qualify'). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no IT-214 FAGI absent contrary input",
    },
  },
  {
    id: "nyIt214Eligible",
    type: "bool",
    description:
      "Attests the NY IT-214 NON-ARITHMETIC eligibility gates (2025 Form IT-214 Step 2, lines 1-6): full-year New York State resident; occupied the same residence 6 or more months; did NOT own real property with a market value over $85,000; NOT claimable as a dependent on another taxpayer's federal return; did NOT reside in public housing or a completely property-tax-exempt residence; nursing-home residency disclosed per the instructions. Does NOT include the arithmetic gates — the $18,000 FAGI cap, the $450 average-monthly-adjusted-rent test (printed line-12 percentage menu), and the line 18/19 comparison are all COMPUTED by us.ny.it214 from nyIt214Fagi/nyIt214TotalRent/nyIt214RentPercent/nyIt214MonthsPaid/nyIt214HomeownerTaxes.",
    default: {
      value: false,
      rationale: "Assumed the IT-214 Step 2 eligibility gates (residency, occupancy, property value, dependent status, exempt housing) are not met absent contrary attestation",
    },
  },
  {
    id: "nyIt214TotalRent",
    type: "money",
    min: "0",
    description:
      "Form IT-214 line 11 (2025): total rent paid during the year for the qualifying NY residence, EXCLUDING any subsidized part of the rental charge. The engine applies the printed line-12 percentage menu (nyIt214RentPercent) and the $450 line-13 average-monthly test itself. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no rent paid absent contrary input (homeowner or non-claimant)",
    },
  },
  {
    id: "nyIt214RentPercent",
    type: "int",
    min: "0",
    description:
      "Form IT-214 line 12 (2025) printed adjusted-rent percentage, chosen from the form's own menu by which charges the rent INCLUDES: heat+gas+electricity+furnishings+board → 50; heat+gas+electricity+furnishings → 75; heat+gas+electricity → 80; heat (or heat+gas) → 85; none of the above → 100. These are the only five values the printed form allows — never subtract actual utility dollar amounts.",
    default: {
      value: "100",
      rationale: "Assumed rent includes no heat/gas/electricity/furnishings/board charges absent contrary input (100% per the printed menu)",
    },
  },
  {
    id: "nyIt214MonthsPaid",
    type: "int",
    min: "1",
    description:
      "Form IT-214 line 13 divisor (2025): the number of months rent was paid during the year (the printed instruction divides line 12 adjusted rent by this to get average monthly adjusted rent, tested against the $450 cap).",
    default: {
      value: "12",
      rationale: "Assumed rent was paid for the full 12 months absent contrary input",
    },
  },
  {
    id: "nyIt214HomeownerTaxes",
    type: "money",
    min: "0",
    description:
      "Form IT-214 line 17 (2025): homeowners' real property taxes paid during the year (line 15) plus special assessments (line 16) on the qualifying residence. A part-year owner/renter supplies both this and the rent facts; the engine sums both buckets into line 18. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no homeowner real property taxes absent contrary input (renter or non-claimant)",
    },
  },
  {
    id: "nyIt216StateCredit",
    type: "money",
    min: "0",
    description:
      "New York State child and dependent care credit as computed on Form IT-216, line 14 (2025) — qualified expenses (net of excluded W-2 box 10 dependent care benefits) x the federal line-10 decimal (FAGI-keyed, .35 down to .20) x the NYS line-13 limitation factor (NYAGI-keyed sawtooth; both tables quoted verbatim in us.ny.parameters). This is Worksheet 2 line 1 — the STARTING amount the NYC child and dependent care credit prorates (us.ny.nyc_cdcc). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no New York State child and dependent care credit absent contrary input",
    },
  },
  {
    id: "nyIt216Under4Expenses",
    type: "money",
    min: "0",
    description:
      "Form IT-216 line 23 (2025): total qualified child/dependent care expenses paid for qualifying persons who were UNDER 4 years old on December 31 and listed on IT-216 line 3. Numerator of the Worksheet 2 line 4 proration ratio (us.ny.nyc_cdcc). Use the same gross/net basis as nyIt216TotalExpenses so the ratio is consistent. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no qualifying persons under age 4 absent contrary input",
    },
  },
  {
    id: "nyIt216TotalExpenses",
    type: "money",
    min: "0",
    description:
      "Form IT-216 line 3a total (2025): total qualified child/dependent care expenses for ALL qualifying persons. Denominator of the Worksheet 2 line 4 proration ratio (us.ny.nyc_cdcc); the ratio is capped at 100%. Use the same gross/net basis as nyIt216Under4Expenses. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no qualified child/dependent care expenses absent contrary input",
    },
  },
  {
    id: "forceItemized",
    type: "bool",
    description:
      "Force the § 63(e) election to itemize even when the standard deduction (plus § 170(p)) is larger — e.g. an MFS filer coordinating with an itemizing spouse, or an explicit client instruction. Default false = the engine takes the larger bundle automatically.",
    default: {
      value: false,
      rationale: "Assumed the tax-minimizing standard-or-itemized election absent contrary input",
    },
  },
  {
    id: "educatorExpenses",
    type: "money",
    min: "0",
    description:
      "TAXPAYER's eligible educator classroom expenses (§ 62(a)(2)(D)) — capped at $300 for 2025 (indexed). K-12 teachers/counselors/aides with 900+ hours (attested). A spouse who is ALSO an eligible educator gets a separate $300 cap: put the spouse's expenses in spouseEducatorExpenses, never summed here. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no educator expenses absent contrary input",
    },
  },
  {
    id: "spouseEducatorExpenses",
    type: "money",
    min: "0",
    description:
      "SPOUSE's eligible educator classroom expenses (§ 62(a)(2)(D)) — separately capped at $300 for 2025 (per-educator cap; an MFJ couple of two educators deducts up to $600 total). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed the spouse is not an eligible educator absent contrary input",
    },
  },
  {
    id: "mfsAbuseOrAbandonmentException",
    type: "bool",
    description:
      "MFS filer qualifies for the Reg. § 1.36B-2(b)(2) domestic-abuse or spousal-abandonment exception (attested on Form 8962 by checking the 'relief' box) — the § 36B(c)(1)(C) joint-filing requirement is waived and the premium tax credit computes normally; excess-APTC repayment is then subject to the ordinary § 36B(f)(2)(B) caps. Available for at most 3 consecutive years.",
    default: { value: false, rationale: "Assumed no abuse/abandonment relief absent contrary attestation (conservative: MFS gets no PTC and repays APTC uncapped)" },
  },
  {
    id: "hsaDistributions",
    type: "money",
    min: "0",
    description:
      "HSA distributions received (Form 1099-SA box 1, all accounts summed). The portion NOT spent on qualified medical expenses (hsaQualifiedMedicalExpenses) is gross income (§ 223(f)(2)) and draws the 20% additional tax (§ 223(f)(4)) unless hsaDistributionPenaltyExempt. In dollars.",
    default: { value: "0", rationale: "Assumed no HSA distributions absent contrary input" },
  },
  {
    id: "hsaQualifiedMedicalExpenses",
    type: "money",
    min: "0",
    description:
      "Unreimbursed qualified medical expenses paid from HSA distributions (Form 8889 line 15) — ONLY the amount the intake EXPLICITLY attests was spent on qualified medical expenses. Absent an explicit attestation, leave this 0 and the full distribution is taxable (§ 223(f)) — never assume qualified use from silence; the taxpayer bears the burden of substantiating qualified use. In dollars.",
    default: { value: "0", rationale: "Assumed distributions were not for qualified medical expenses absent contrary input (conservative: taxable)" },
  },
  {
    id: "hsaDistributionPenaltyExempt",
    type: "bool",
    description:
      "The § 223(f)(4)(B)-(C) exceptions apply to any taxable HSA distribution: made after age 65, after death, or attributable to disability — the 20% additional tax does not apply (the income inclusion still does).",
    default: { value: false, rationale: "Assumed no penalty exception absent contrary input" },
  },
  {
    id: "alimonyPaidPre2019",
    type: "money",
    min: "0",
    description:
      "Alimony/separate maintenance PAID under an instrument executed BEFORE 2019 (and not modified to adopt TCJA treatment) — deductible above the line under pre-TCJA § 215/§ 62(a)(10). Post-2018-instrument alimony is NOT deductible federally (do not enter it here; note some states, e.g. NY, decoupled). In dollars.",
    default: { value: "0", rationale: "Assumed no pre-2019 alimony paid absent contrary input" },
  },
  {
    id: "alimonyReceivedPre2019",
    type: "money",
    min: "0",
    description:
      "Alimony/separate maintenance RECEIVED under a pre-2019 instrument — includible in gross income under pre-TCJA § 71. Post-2018-instrument alimony received is NOT federal income (exclude it here). In dollars.",
    default: { value: "0", rationale: "Assumed no pre-2019 alimony received absent contrary input" },
  },
  {
    id: "federalEstimatedPayments",
    type: "money",
    min: "0",
    description:
      "Federal estimated tax payments for the year plus any prior-year overpayment applied (Form 1040 line 26) — its OWN line, never folded into withholding (line 25d is withholding only). In dollars.",
    default: { value: "0", rationale: "Assumed no estimated payments absent contrary input" },
  },
  {
    id: "federalExtensionPayment",
    type: "money",
    min: "0",
    description:
      "Payment made with the federal extension request (Form 4868) — a Form 1040 line 31 payment via Schedule 3 line 13a; counted in total payments, NEVER folded into withholding or estimated payments. In dollars.",
    default: { value: "0", rationale: "Assumed no extension payment absent contrary input" },
  },
  {
    id: "earlyWithdrawalPenaltyPaid",
    type: "money",
    min: "0",
    description:
      "Penalty on early withdrawal of savings (1099-INT box 2 / 1099-OID box 3) — deductible above the line in full (§ 62(a)(9); Schedule 1 line 18). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no early-withdrawal penalty absent contrary input",
    },
  },
  {
    id: "otherAdjustments",
    type: "money",
    min: "0",
    description:
      "Other above-the-line adjustments from Schedule 1 lines 24a-24z, ATTESTED as the documented total: jury duty pay given to the employer (24a), reforestation amortization (24d), § 3402 supplemental-unemployment repayments (24e), § 501(c)(18)(D) pension contributions (24f, W-2 box 12 code H), attorney fees for unlawful-discrimination claims (24h) and IRS whistleblower awards (24i), and similar write-in adjustments. Enter the SUM of the documented amounts — each is deductible in full; never fold these into income as negative amounts. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no Schedule 1 line-24 write-in adjustments absent contrary input",
    },
  },
  {
    id: "iraContribution",
    type: "money",
    min: "0",
    description:
      "Traditional IRA contributions for the year (26 U.S.C. § 219). Roth contributions are not deductible and do not belong here. In dollars. GATE-vs-DOLLAR: an intake screener like 'Made contributions to a traditional or Roth IRA = false' does NOT nullify a populated traditional-IRA dollar field — IRA contributions are a DEDUCTION item, so the documented dollar controls (transcribe it; any § 219(g) phase-out still applies, including the § 219(g)(4) lived-apart-all-year MFS carve-out). The boolean-gate-controls rule is for PAYMENT fields only.",
    default: {
      value: "0",
      rationale: "Assumed no traditional IRA contributions absent contrary input",
    },
  },
  {
    id: "isActivePlanParticipant",
    type: "bool",
    description:
      "Taxpayer is an active participant in an employer retirement plan (W-2 box 13 'Retirement plan') — triggers the § 219(g) deduction phase-out.",
    // no default — only demanded when iraContribution > 0; the engine must
    // never guess plan coverage (it decides the whole phase-out)
  },
  {
    id: "spouseIsActivePlanParticipant",
    type: "bool",
    description:
      "Spouse is an active participant in an employer retirement plan (§ 219(g)(7) spousal phase-out).",
    // no default — only demanded for a married non-participant with an IRA
  },
  {
    id: "isAge50OrOlder",
    type: "bool",
    description:
      "Taxpayer attained age 50 before the close of the taxable year (IRA catch-up, § 219(b)(5)(B)).",
    default: {
      value: false,
      rationale: "Assumed under 50 absent contrary input (denies the IRA catch-up — conservative)",
    },
  },
  {
    id: "aotcExpensesStudent1",
    type: "money",
    min: "0",
    description:
      "Qualified tuition and related expenses for the FIRST eligible student (26 U.S.C. § 25A(b)) — half-time enrollment in one of the first 4 postsecondary years, no 4 prior AOTC claims, no felony drug conviction, and SSN/EIN requirements assumed satisfied. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no American Opportunity credit expenses absent contrary input",
    },
  },
  {
    id: "aotcExpensesStudent2",
    type: "money",
    min: "0",
    description:
      "Qualified expenses for a SECOND eligible AOTC student, if any (same § 25A(b) conditions assumed). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no second AOTC student absent contrary input",
    },
  },
  {
    id: "aotcExpensesStudent3",
    type: "money",
    min: "0",
    description:
      "Qualified expenses for a THIRD eligible AOTC student, if any (same § 25A(b) conditions assumed; a fourth simultaneous student is not representable). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no third AOTC student absent contrary input",
    },
  },
  {
    id: "llcQualifiedExpenses",
    type: "money",
    min: "0",
    description:
      "Qualified tuition and related expenses for the Lifetime Learning Credit (26 U.S.C. § 25A(c)) — per return, and not the same expenses claimed for the AOTC (§ 25A(c)(2)(A)). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no Lifetime Learning Credit expenses absent contrary input",
    },
  },
  {
    id: "isSubjectToKiddieTax",
    type: "bool",
    description:
      "Taxpayer is a child to whom 26 U.S.C. § 1(g) applies (under 18, or 18 / full-time student under 24 with earned income ≤ half their support, a living parent, no joint return). Triggers the Form 8615 tax and denies the refundable AOTC (§ 25A(i)).",
    default: {
      value: false,
      rationale:
        "Assumed not a kiddie-tax child absent contrary input (the claimant is typically the parent)",
    },
  },
  {
    id: "parentTaxableIncome",
    type: "money",
    min: "0",
    description:
      "The parent's taxable income (Form 8615 line 6) — needed to compute the allocable parental tax at the parent's rates (§ 1(g)(3)).",
    // no default — the engine must never guess the parent's income
  },
  {
    id: "parentFilingStatus",
    type: "enum",
    enumValues: [...FILING_STATUSES],
    description: "The parent's filing status for the Form 8615 recomputation (§ 1(g)).",
    // no default
  },
  {
    id: "parentHasPreferentialIncome",
    type: "bool",
    description:
      "The parent's taxable income includes net capital gain or qualified dividends (preferential rates) — the Form 8615 recomputation then needs the parent's QDCGT worksheet, which is not modeled (refuses).",
    // no default — deciding it silently would change the parent-rate math
  },
  {
    id: "socialSecurityBenefits",
    type: "money",
    min: "0",
    description:
      "Social security (and tier-1 railroad retirement) benefits received — box 5 of SSA-1099; includible per the \u00a7 86 0/50/85% formula. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no social security benefits absent contrary input",
    },
  },
  {
    id: "taxableIraDistributions",
    type: "money",
    min: "0",
    description:
      "TAXABLE IRA distributions (\u00a7 408(d); Form 8606 basis already applied). When nondeductible-contribution basis exists, compute the taxable amount with the standalone target us.federal.ira8606.taxable_amount (per individual) and enter the result here. ROLLOVERS are excluded entirely: when an interview/confirmation field like 'distributions less rollovers' shows 0, the 1099-R was rolled over and contributes NOTHING here regardless of its box 2a or distribution code \u2014 payer forms cannot see 60-day rollovers. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no IRA distributions absent contrary input",
    },
  },
  {
    id: "ira8606Basis",
    type: "money",
    min: "0",
    description:
      "Form 8606 line 2: this individual's total basis in traditional IRAs from earlier years (the most recent prior Form 8606 line 14). PER INDIVIDUAL \u2014 spouses file separate Forms 8606; run the ira8606 target once per spouse. In dollars.",
    // no default \u2014 the 8606 targets are meaningless without an explicit basis
  },
  {
    id: "ira8606NondeductibleContributions",
    type: "money",
    min: "0",
    description:
      "Form 8606 line 1: nondeductible traditional IRA contributions FOR this year, including those made through the following April 15 (the line 4 timing split is not modeled \u2014 enter the full year's amount). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no current-year nondeductible contributions absent contrary input",
    },
  },
  {
    id: "ira8606YearEndValue",
    type: "money",
    min: "0",
    description:
      "Form 8606 line 6: value of ALL this individual's traditional, SEP, and SIMPLE IRAs as of December 31, plus any outstanding rollovers (\u00a7 408(d)(2)(C)). In dollars.",
    // no default \u2014 a guessed $0 would silently inflate the nontaxable ratio
  },
  {
    id: "ira8606Distributions",
    type: "money",
    min: "0",
    description:
      "Form 8606 line 7: this year's distributions from this individual's traditional/SEP/SIMPLE IRAs, EXCLUDING rollovers, Roth conversions, qualified charitable distributions, and returned contributions (exclusions attested by the input). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no non-conversion IRA distributions absent contrary input",
    },
  },
  {
    id: "ira8606Conversions",
    type: "money",
    min: "0",
    description:
      "Form 8606 line 8: net amount this individual converted from traditional/SEP/SIMPLE IRAs to Roth IRAs this year. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no Roth conversions absent contrary input",
    },
  },
  {
    id: "taxablePensionsAndAnnuities",
    type: "money",
    min: "0",
    description:
      "TAXABLE pensions and annuities (\u00a7 72 exclusion ratio already applied — 1099-R box 2a). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no pension or annuity income absent contrary input",
    },
  },
  {
    id: "unemploymentCompensation",
    type: "money",
    min: "0",
    description: "Unemployment compensation (\u00a7 85, fully includible). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no unemployment compensation absent contrary input",
    },
  },
  {
    id: "otherOrdinaryIncome",
    type: "money",
    min: "0",
    description:
      "Other fully-includible ordinary income reported on Schedule 1 line 8 \u2014 gambling winnings (W-2G, line 8b), prizes and awards, Alaska Permanent Fund dividends (line 8g), jury duty pay, etc. (\u00a7 61(a)). NOT earned income, NOT \u00a7 1411 net investment income, no SE tax. Do not enter income another fact covers. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no other Schedule 1 income absent contrary input",
    },
  },
  {
    id: "eitcAdditionalQualifyingChildren",
    type: "int",
    min: "0",
    description:
      "EIC qualifying children NOT already counted in qualifyingChildren \u2014 \u00a7 32(c)(3) uses the \u00a7 152(c) age rules (under 19, under 24 if a full-time student, or ANY age if permanently and totally disabled), which are wider than the CTC's under-17 cut. A 17-year-old, a 20-year-old student, or a disabled adult child goes here. Counted only for the earned income credit.",
    default: {
      value: "0",
      rationale:
        "Assumed no EIC-only qualifying children absent contrary input (the CTC child count is the floor)",
    },
  },
  {
    id: "earlyDistributionSubjectToPenalty",
    type: "money",
    min: "0",
    description:
      "The portion of retirement distributions subject to the \u00a7 72(t) 10% additional tax — enter only the amount to which NO exception (59\u00bd, disability, SEPP, first home, \u00a7 72(t)(2)) applies. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no penalized early distributions absent contrary input",
    },
  },
  {
    id: "amtIsoExerciseSpread",
    type: "money",
    min: "0",
    description:
      "Bargain element on incentive stock options exercised and NOT sold in the same year (\u00a7 56(b)(3) AMT adjustment). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no ISO exercises absent contrary input",
    },
  },
  {
    id: "amtOtherPreferences",
    type: "money",
    min: "0",
    description:
      "Other Form 6251 Part I adjustments and preferences: tax-exempt private-activity-bond interest, depreciation adjustments, depletion, intangible drilling costs, etc. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no other AMT preference items absent contrary input",
    },
  },
  {
    id: "federalTaxWithheld",
    type: "money",
    min: "0",
    description:
      "Federal income tax withheld so far this year (W-2 box 2 + estimated payments) — credited against the liability under 26 U.S.C. § 31. INCLUDE Form 8959 Part IV excess Medicare withholding: any W-2 box 6 amount over 1.45% of box 5 is Additional-Medicare-Tax withholding that belongs here (otherwise the 0.9% tax is paid twice). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no withholding reported absent contrary input",
    },
  },
  {
    id: "useFormulaMethod",
    type: "bool",
    description:
      "Compute with exact continuous formulas instead of the printed-form methods (analysis/comparison mode — filed returns use the forms). Affects: the IRS Tax Table below $100,000, the § 32(f) EIC Table ($50-bracket midpoints), Schedule SE's per-line whole-dollar rounding, and the state packs that print a table or worksheet (KS us.ks.income_tax, NM us.nm.income_tax — exact § 7-2-7 schedule instead of the midpoint table and the printed over-$100,000 worksheet).",
    default: {
      value: false,
      rationale:
        "The printed-form methods (Tax Table, EIC Table, Schedule SE rounding) are how filed returns compute",
    },
  },
  // ── § 6654 estimated-tax safe harbor ──────────────────────────────────
  {
    id: "priorYearTax",
    type: "money",
    min: "0",
    description:
      "Total tax shown on last year's return (§ 6654(d)(1)(B)(ii)). In dollars.",
    // no default — the engine must never guess a prior-year liability
  },
  {
    id: "priorYearAGI",
    type: "money",
    min: "0",
    description:
      "AGI shown on last year's return — over $150,000 ($75,000 MFS) triggers the 110% safe-harbor prong (§ 6654(d)(1)(C)). In dollars.",
    // no default
  },
  // ── business-entity classification & entity-level tax ────────────────
  {
    id: "entityLegalForm",
    type: "enum",
    enumValues: ["llc", "corporation"],
    description:
      "The business's state-law legal form: a limited liability company, or a state-law corporation (a per-se corporation under Treas. Reg. § 301.7701-2(b)(1)).",
    // no default — the engine must never guess what was formed
  },
  {
    id: "llcMemberCount",
    type: "int",
    min: "1",
    description:
      "Number of members (owners) of the LLC — one member defaults to disregarded-entity treatment, two or more to partnership (Treas. Reg. § 301.7701-3(b)(1)).",
    // no default — only demanded for an LLC with no corporate election
  },
  {
    id: "filedForm8832CorpElection",
    type: "bool",
    description:
      "The entity filed a Form 8832 election to be classified as an association taxable as a corporation (Treas. Reg. § 301.7701-3(c)).",
    default: {
      value: false,
      rationale: "Assumed no Form 8832 election absent contrary input",
    },
  },
  {
    id: "filedForm2553SElection",
    type: "bool",
    description:
      "The entity filed a timely Form 2553 S election under § 1362(a)(1) (for an eligible entity this also deems association classification, Reg. § 301.7701-3(c)(1)(v)(C)).",
    default: {
      value: false,
      rationale: "Assumed no S election absent contrary input",
    },
  },
  {
    id: "sCorpShareholderCount",
    type: "int",
    min: "1",
    description:
      "Number of shareholders, counting married couples and § 1361(c)(1) family members as one (§ 1361(b)(1)(A): may not exceed 100).",
    // no default — only demanded when an S election exists
  },
  {
    id: "sCorpHasIneligibleShareholder",
    type: "bool",
    description:
      "Any shareholder is ineligible under § 1361(b)(1)(B)–(C): a nonresident alien, or an entity other than an estate or eligible trust/exempt organization.",
    // no default — only demanded when an S election exists
  },
  {
    id: "sCorpHasMultipleStockClasses",
    type: "bool",
    description:
      "The corporation has more than one class of stock (§ 1361(b)(1)(D); differences in voting rights alone do not create a second class, § 1361(c)(4)).",
    // no default — only demanded when an S election exists
  },
  {
    id: "corpTaxableIncome",
    type: "money",
    min: "0",
    description:
      "The C corporation's taxable income BEFORE the § 250 deduction, if already computed — used as-is when provided. Leave at 0 to have the engine compute it from corpGrossIncome and the deduction components (charitable/DRD/NOL machinery). CONTRACT: the § 250 deduction is computed separately from corpFDDEI/corpNCTI and subtracted by the tax rule — an AS-FILED Form 1120 line 30 already nets out § 250, so when providing corpFDDEI/corpNCTI enter the pre-§ 250 amount here (line 30 plus the § 250 deduction as filed), never the net. In dollars.",
    default: {
      value: "0",
      rationale:
        "No line-30 amount provided — taxable income computed from the gross-income and deduction components",
    },
  },
  {
    id: "corpGrossIncome",
    type: "money",
    min: "0",
    description:
      "The corporation's gross income (§ 61), INCLUDING any dividends received, any § 951 subpart F and § 951A NCTI/GILTI inclusions with their § 78 gross-ups (§ 951A(a) is a gross-income INCLUSION — the § 250 deduction is computed separately from corpNCTI), and any § 245A-eligible foreign-sub dividends. In dollars.",
    // no default — the engine must never guess income
  },
  {
    id: "corpOrdinaryDeductions",
    type: "money",
    min: "0",
    description:
      "Ordinary business deductions (salaries, rents, prior-year amortization, …) — everything EXCEPT charitable contributions, the dividends-received deduction, and NOLs, which have their own limited rules. Enter compensation already limited by § 162(m) (no deduction for a covered employee's remuneration over $1,000,000 at a publicly held corporation — not modeled, attested). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no ordinary deductions absent contrary input",
    },
  },
  {
    id: "corpCharitableContributions",
    type: "money",
    min: "0",
    description:
      "The corporation's charitable contributions — current-year gifts plus allowable prior-year § 170(d)(2) carryovers being used (both subject to the same ceiling and, from 2026, the OBBBA floor). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no corporate charitable contributions absent contrary input",
    },
  },
  {
    id: "corpDividendsReceived",
    type: "money",
    min: "0",
    description:
      "Dividends received from other taxable domestic corporations (§ 243 DRD; must also be included in corpGrossIncome). Enter only dividends on stock meeting the § 246(c) holding period (held more than 45 days during the 91-day window around the ex-dividend date; 90/181 for certain preferred) — attested; § 1059 extraordinary-dividend basis reduction not modeled. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no intercorporate dividends absent contrary input",
    },
  },
  {
    id: "corpDrdOwnershipTier",
    type: "enum",
    enumValues: ["under-20", "20-to-80", "80-plus"],
    description:
      "Ownership of the dividend-paying corporation: under 20% (50% DRD), 20–80% (65% DRD), or 80%+ affiliated (100% DRD, § 243(a)(3)).",
    // no default — only demanded when dividends were received
  },
  {
    id: "corpNOLCarryforward",
    type: "money",
    min: "0",
    description:
      "Net operating loss carryforward available this year (§ 172: deduction limited to 80% of taxable income before the NOL; post-TCJA, no carrybacks). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no NOL carryforward absent contrary input",
    },
  },
  {
    id: "corpPriorYearTax",
    type: "money",
    min: "0",
    description:
      "Tax shown on the corporation's preceding-year return (§ 6655(d) prior-year prong; unavailable if that year showed zero tax or was short). In dollars.",
    // no default — only demanded for corporate estimated-tax questions
  },
  {
    id: "corpIsLargeCorporation",
    type: "bool",
    description:
      "The corporation had taxable income of $1,000,000 or more in any of the 3 preceding taxable years (§ 6655(g)(2) 'large corporation' — may not use the prior-year safe harbor).",
    // no default — only demanded for corporate estimated-tax questions
  },
  {
    id: "corpFDDEI",
    type: "money",
    min: "0",
    description:
      "TY2025: foreign-derived intangible income (FDII); TY2026+: foreign-derived deduction eligible income (FDDEI, OBBBA — QBAI abolished). The § 250 deduction applies 37.5% (2025) / 33.34% (2026+). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no foreign-derived eligible income absent contrary input",
    },
  },
  {
    id: "corpNCTI",
    type: "money",
    min: "0",
    description:
      "TY2025: the § 951A GILTI inclusion (with its § 78 gross-up); TY2026+: net CFC tested income (NCTI, OBBBA). The § 250 deduction applies 50% (2025) / 40% (2026+). The inclusion itself is GROSS INCOME (§ 951A(a)) — it must also be in corpGrossIncome with its § 78 gross-up; this fact drives only the § 250 deduction and FTC basket. The per-CFC tested-income aggregation is not modeled. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no CFC inclusion absent contrary input",
    },
  },
  {
    id: "generalBusinessCredits",
    type: "money",
    min: "0",
    description:
      "Aggregate current-year § 38(b) general business credits (e.g. the § 41 research credit target's result) — limited under § 38(c). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no general business credits absent contrary input",
    },
  },
  {
    id: "aggregateBusinessLoss",
    type: "money",
    min: "0",
    description:
      "The noncorporate taxpayer's net aggregate business LOSS for the year, entered as a positive number (§ 461(l): the excess over $313k/$626k in 2025, $256k/$512k in 2026, is disallowed and becomes an NOL). In dollars.",
    // no default — only demanded by the excess-business-loss target
  },
  {
    id: "corpForeignTaxesGeneral",
    type: "money",
    min: "0",
    description:
      "Creditable foreign income taxes in the \u00a7 904(d) GENERAL basket. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no general-basket foreign taxes absent contrary input",
    },
  },
  {
    id: "corpForeignSourceIncomeGeneral",
    type: "money",
    min: "0",
    description:
      "Foreign-source taxable income in the general basket (\u00a7 904 limitation numerator; \u00a7 861 expense allocation attested). In dollars.",
    // no default — only demanded when general-basket foreign taxes exist
  },
  {
    id: "corpForeignTaxesNCTI",
    type: "money",
    min: "0",
    description:
      "Foreign taxes attributable to the \u00a7 951A basket (GILTI/NCTI) — the \u00a7 960(d) deemed-paid credit takes the 80% (2025) / 90% (2026+, OBBBA) allowance, no carryovers. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no CFC-basket foreign taxes absent contrary input",
    },
  },
  {
    id: "corpBaseErosionTestMet",
    type: "bool",
    description:
      "The corporation's base erosion percentage is 3% or more (2% for banks/securities dealers) — one of the two \u00a7 59A applicable-taxpayer tests. BEAT applies only to $500M+ multinationals.",
    default: {
      value: false,
      rationale:
        "Assumed the 3% base-erosion test is not met absent contrary input (BEAT reaches only large multinationals with substantial related-party deductions)",
    },
  },
  {
    id: "corpBaseErosionTaxBenefits",
    type: "money",
    min: "0",
    description:
      "Base erosion tax benefits for the year (\u00a7 59A(c)(2)) — include the base-erosion percentage of any NOL deduction (\u00a7 59A(c)(1)(B)). Added back to reach modified taxable income. In dollars.",
    // no default — only demanded when the base-erosion test is met
  },
  {
    id: "corpCapitalGains",
    type: "money",
    min: "0",
    description:
      "The corporation's capital gains for the year (\u00a7 1211(a): losses offset only these; net gain is ordinary-rate income for a corporation). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no corporate capital gains absent contrary input",
    },
  },
  {
    id: "corpCapitalLosses",
    type: "money",
    min: "0",
    description:
      "The corporation's capital losses for the year, including prior-year \u00a7 1212(a) carryovers being used (allowed only to the extent of capital gains). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no corporate capital losses absent contrary input",
    },
  },
  {
    id: "corpPortfolioDebtFinancedPercent",
    type: "int",
    min: "0",
    description:
      "Average indebtedness percentage (0-100) of debt-financed portfolio stock (\u00a7 246A) — reduces the 50%/65% DRD proportionally; 0 = not debt-financed.",
    default: {
      value: "0",
      rationale: "Assumed the dividend-paying stock is not debt-financed absent contrary input",
    },
  },
  {
    id: "corpFilesConsolidatedReturn",
    type: "bool",
    description:
      "The corporation joins a consolidated return (\u00a7\u00a7 1501-1504) — intercompany eliminations and SRLY rules are not modeled, so this refuses.",
    default: {
      value: false,
      rationale: "Assumed a separate (non-consolidated) return absent contrary input",
    },
  },
  {
    id: "corpTIThrough3Months",
    type: "money",
    min: "0",
    description:
      "Corporate taxable income for the first 3 months (\u00a7 6655(e) annualization, installments 1-2). In dollars.",
  },
  {
    id: "corpTIThrough6Months",
    type: "money",
    min: "0",
    description:
      "Corporate taxable income for the first 6 months (\u00a7 6655(e) annualization, installment 3). In dollars.",
  },
  {
    id: "corpTIThrough9Months",
    type: "money",
    min: "0",
    description:
      "Corporate taxable income for the first 9 months (\u00a7 6655(e) annualization, installment 4). In dollars.",
  },
  {
    id: "sCorpHasAccumulatedEandP",
    type: "bool",
    description:
      "The S corporation has accumulated earnings and profits from C-corporation years at the close of the year (§ 1375 applies only then).",
    default: {
      value: false,
      rationale:
        "Assumed no C-year accumulated E&P absent contrary input (an always-S corporation has none)",
    },
  },
  {
    id: "sCorpPassiveInvestmentIncome",
    type: "money",
    min: "0",
    description:
      "The S corporation's passive investment income — royalties, rents, dividends, interest, annuities (§ 1375(b)(3)). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no passive investment income absent contrary input",
    },
  },
  {
    id: "sCorpGrossReceipts",
    type: "money",
    min: "0",
    description: "The S corporation's gross receipts for the year (§ 1375). In dollars.",
    // no default — only demanded when the § 1375 branch is reachable
  },
  {
    id: "sCorpNetPassiveIncome",
    type: "money",
    min: "0",
    description:
      "Passive investment income net of directly-connected deductions (§ 1375(b)(2)). In dollars.",
    // no default — only demanded when the § 1375 branch is reachable
  },
  {
    id: "sCorpTaxableIncomeAsC",
    type: "money",
    min: "0",
    description:
      "The S corporation's taxable income computed as if it were a C corporation (§§ 1374(b)(1)/1375(b)(1)(B) cap). In dollars.",
    // no default — only demanded when §§ 1374/1375 are reachable
  },
  {
    id: "sCorpRecognizedBuiltInGain",
    type: "money",
    min: "0",
    description:
      "Net recognized built-in gain during the § 1374(d)(7) 5-year recognition period after a C-to-S conversion (0 if the period has passed or there was no conversion). In dollars.",
    default: {
      value: "0",
      rationale:
        "Assumed no recognized built-in gain absent contrary input (no C-to-S conversion in the recognition period)",
    },
  },
  {
    id: "corpAvgAdjustedFinancialStatementIncome",
    type: "money",
    min: "0",
    description:
      "3-year-average adjusted financial statement income (§ 56A) — over $1 billion triggers the corporate AMT, which this engine refuses to approximate. In dollars.",
    default: {
      value: "0",
      rationale:
        "Assumed 3-year-average AFSI at or below the $1 billion CAMT threshold absent contrary input",
    },
  },
  {
    id: "corpEquipmentPurchases",
    type: "money",
    min: "0",
    description:
      "Cost of qualified § 168(k) property acquired AND placed in service this year (acquired after January 19, 2025 — 100% bonus depreciation, OBBBA-permanent). EXCLUDE passenger automobiles (the § 280F luxury-auto caps are not modeled) and anything entered in corpSection179Cost. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no qualified property placed in service absent contrary input",
    },
  },
  {
    id: "corpSection179Cost",
    type: "money",
    min: "0",
    description:
      "Cost of § 179 property the corporation elects to expense — including qualified real property (roofs, HVAC, fire/security systems on nonresidential real property, § 179(d)(1)(B)(ii)) that § 168(k) cannot reach. Must NOT also be in corpEquipmentPurchases; EXCLUDE passenger automobiles and sport utility vehicles (the § 280F caps and the § 179(b)(5) SUV cap are not modeled). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no § 179 election absent contrary input",
    },
  },
  {
    id: "corpFiscalYearFiler",
    type: "bool",
    description:
      "The corporation uses a FISCAL taxable year (or files a § 443 short-period return). Fiscal and short years are not modeled — the OBBBA parameters (§ 250 rates, § 59A 10.5%, § 960(d) 90%, § 448(c) $32M, the § 170(b)(2) 1% floor) apply by the taxable year's BEGINNING date, and § 443(b) annualization / § 15 proration are not encoded.",
    default: {
      value: false,
      rationale:
        "Calendar taxable year assumed — fiscal-year and short-period returns refuse",
    },
  },
  {
    id: "corpIsCoveredCorporation",
    type: "bool",
    description:
      "The corporation is a 'covered corporation' for the § 4501 stock-repurchase excise tax: a domestic corporation whose stock is traded on an established securities market (§ 4501(b)).",
    default: {
      value: false,
      rationale: "Assumed not a listed domestic corporation absent contrary input",
    },
  },
  {
    id: "corpStockRepurchasedFMV",
    type: "money",
    min: "0",
    description:
      "Fair market value of the corporation's own stock repurchased (§ 317(b) redemptions and economically similar transactions) during the taxable year, for the § 4501 excise. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no stock repurchases absent contrary input",
    },
  },
  {
    id: "corpStockIssuedFMV",
    type: "money",
    min: "0",
    description:
      "Fair market value of stock issued by the corporation during the taxable year (including to employees) — netted against repurchases under § 4501(c)(3). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no stock issuances absent contrary input",
    },
  },
  {
    id: "corpSection245ADividends",
    type: "money",
    min: "0",
    description:
      "Foreign-source portion of dividends received from specified 10-percent-owned foreign corporations, eligible for the § 245A participation-exemption DRD (100%). Must also be included in corpGrossIncome. Attested by entry: US-shareholder status, NOT a § 245A(e) hybrid dividend, and the § 246(c)(5) 365-day holding period met; no foreign tax credit is allowed for the deducted portion (§ 245A(d)) — keep these taxes out of the FTC inputs. In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no § 245A-eligible foreign-sub dividends absent contrary input",
    },
  },
  {
    id: "corpDomesticResearch",
    type: "money",
    min: "0",
    description:
      "Domestic research or experimental expenditures — currently deductible under § 174A (OBBBA, permanent from 2025). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no domestic research expenditures absent contrary input",
    },
  },
  {
    id: "corpForeignResearch",
    type: "money",
    min: "0",
    description:
      "FOREIGN research or experimental expenditures paid this year — capitalized and amortized over 15 years (§ 174; first-year deduction is 1/30 under the midpoint convention). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no foreign research expenditures absent contrary input",
    },
  },
  {
    id: "corpBusinessInterestExpense",
    type: "money",
    min: "0",
    description:
      "Business interest expense (§ 163(j): limited to 30% of EBITDA-based ATI unless the § 448(c) gross-receipts test is met). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no business interest expense absent contrary input",
    },
  },
  {
    id: "corpAvgGrossReceipts3yr",
    type: "money",
    min: "0",
    description:
      "3-year-average annual gross receipts (§ 448(c) test: $31M for 2025, $32M for 2026 — at or below it the § 163(j) limit does not apply). In dollars.",
    // no default — only demanded when there is business interest expense
  },
  {
    id: "corpDividendsPaid",
    type: "money",
    min: "0",
    description:
      "Dividends paid during the year (the § 561 dividends-paid deduction for the accumulated-earnings computation). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no dividends paid absent contrary input",
    },
  },
  {
    id: "corpAccumulatedEandPStart",
    type: "money",
    min: "0",
    description:
      "Accumulated earnings and profits at the close of the PRECEDING year (§ 535(c)(2) minimum-credit offset). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no prior accumulated earnings and profits absent contrary input",
    },
  },
  {
    id: "corpReasonableNeedsRetention",
    type: "money",
    min: "0",
    description:
      "Earnings retained for the reasonable needs of the business (§§ 535(c)(1), 537 — documented needs; part of the accumulated earnings credit). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no documented reasonable-needs retention absent contrary input",
    },
  },
  {
    id: "corpIsPersonalServiceCorp",
    type: "bool",
    description:
      "The corporation's principal function is services in health, law, engineering, architecture, accounting, actuarial science, performing arts, or consulting (§ 535(c)(2)(B): $150,000 minimum credit instead of $250,000).",
    default: {
      value: false,
      rationale: "Assumed not a listed service corporation absent contrary input",
    },
  },
  {
    id: "corpPHCIncome",
    type: "money",
    min: "0",
    description:
      "Personal holding company income (§ 543: dividends, interest, royalties, annuities, certain rents). In dollars.",
    // no default — only demanded for PHC determinations
  },
  {
    id: "corpAdjustedOrdinaryGrossIncome",
    type: "money",
    min: "0",
    description: "Adjusted ordinary gross income (§ 543(b)(2)) — the 60% test base. In dollars.",
    // no default — only demanded for PHC determinations
  },
  {
    id: "corpOwnedByFiveOrFewer",
    type: "bool",
    description:
      "More than 50% of the stock's value was owned (directly or via § 544 attribution) by 5 or fewer individuals during the last half of the year (§ 542(a)(2)).",
    // no default — only demanded for PHC determinations
  },
  {
    id: "corpUndistributedPHCIncome",
    type: "money",
    min: "0",
    description:
      "Undistributed personal holding company income (§ 545: taxable income adjusted, less federal taxes and the dividends-paid deduction). In dollars.",
    // no default — only demanded when the PHC tax is computed
  },
  {
    id: "qsbsGain",
    type: "money",
    min: "0",
    description:
      "Gain on a sale of qualified small business stock (§ 1202) — original issuance, active-business, and gross-asset tests assumed satisfied (disclosed). In dollars.",
    default: {
      value: "0",
      rationale: "Assumed no QSBS gain absent contrary input",
    },
  },
  {
    id: "qsbsAcquiredAfterJuly2025",
    type: "bool",
    description:
      "The stock was acquired AFTER July 4, 2025 (the OBBBA tiered regime: 50/75/100% at 3/4/5 years, $15M cap) rather than under prior law ($10M cap, 100% at 5 years).",
    // no default — the acquisition date decides the whole regime
  },
  {
    id: "qsbsAcquiredAfterSept2010",
    type: "bool",
    description:
      "For prior-law stock: acquired after September 27, 2010 (the 100%-exclusion vintage; earlier vintages refuse).",
    // no default — only demanded for pre-OBBBA stock held 5+ years
  },
  {
    id: "qsbsHoldingPeriodYears",
    type: "int",
    min: "0",
    description: "Whole years the QSBS was held before the sale (§ 1202(a)/(b) holding tiers).",
    // no default — only demanded when there is QSBS gain
  },
  // ── § 6654(d)(2) annualized-income installments (cumulative periods) ──
  {
    id: "wagesThroughMar31",
    type: "money",
    min: "0",
    description:
      "Wages received January 1 through March 31 (Form 2210 Schedule AI column (a)). Only demanded when the year has wages. In dollars.",
  },
  {
    id: "wagesThroughMay31",
    type: "money",
    min: "0",
    description: "Wages received January 1 through May 31 (Schedule AI column (b)). In dollars.",
  },
  {
    id: "wagesThroughAug31",
    type: "money",
    min: "0",
    description: "Wages received January 1 through August 31 (Schedule AI column (c)). In dollars.",
  },
  {
    id: "seProfitThroughMar31",
    type: "money",
    min: "0",
    description:
      "Self-employment net profit earned January 1 through March 31 (Schedule AI column (a)). Only demanded when the year has SE profit. In dollars.",
  },
  {
    id: "seProfitThroughMay31",
    type: "money",
    min: "0",
    description: "Self-employment net profit January 1 through May 31 (Schedule AI column (b)). In dollars.",
  },
  {
    id: "seProfitThroughAug31",
    type: "money",
    min: "0",
    description: "Self-employment net profit January 1 through August 31 (Schedule AI column (c)). In dollars.",
  },
  // ── § 152 dependent determination (about ONE candidate person) ───────
  {
    id: "depRelationshipChild",
    type: "bool",
    description:
      "Candidate is the taxpayer's child, stepchild, foster child, sibling, step-sibling, or a descendant of any of them (§ 152(c)(2)).",
  },
  {
    id: "depAge",
    type: "int",
    min: "0",
    description: "Candidate's age at the end of the year (§ 152(c)(3)).",
  },
  {
    id: "depIsFullTimeStudent",
    type: "bool",
    description: "Candidate was a full-time student for at least 5 months (§ 152(f)(2)).",
    default: {
      value: false,
      rationale: "Assumed not a full-time student absent contrary input",
    },
  },
  {
    id: "depPermanentlyDisabled",
    type: "bool",
    description: "Candidate is permanently and totally disabled (§ 152(c)(3)(B)).",
    default: {
      value: false,
      rationale: "Assumed not permanently and totally disabled absent contrary input",
    },
  },
  {
    id: "depYoungerThanTaxpayer",
    type: "bool",
    description: "Candidate is younger than the taxpayer (§ 152(c)(3)(A)).",
    default: {
      value: true,
      rationale: "Assumed the candidate is younger than the taxpayer absent contrary input",
    },
  },
  {
    id: "depLivedWithTaxpayerOverHalfYear",
    type: "bool",
    description:
      "Candidate had the same principal residence as the taxpayer for more than half the year (§ 152(c)(1)(B)).",
    // no default — a core test, always asked
  },
  {
    id: "depProvidedOwnSupportOverHalf",
    type: "bool",
    description: "Candidate provided more than half of their own support (§ 152(c)(1)(D)).",
    default: {
      value: false,
      rationale: "Assumed the candidate did not provide over half their own support",
    },
  },
  {
    id: "depFilesJointReturn",
    type: "bool",
    description:
      "Candidate files a joint return with a spouse (other than a refund-only claim) (§ 152(c)(1)(E)).",
    default: {
      value: false,
      rationale: "Assumed the candidate does not file a joint return",
    },
  },
  {
    id: "depRelationshipRelative",
    type: "bool",
    description:
      "Candidate bears a § 152(d)(2) relationship to the taxpayer (parent, grandparent, sibling, in-law, etc.) or lived in the household all year.",
    // no default
  },
  {
    id: "depGrossIncome",
    type: "money",
    min: "0",
    description:
      "Candidate's gross income for the year (§ 152(d)(1)(B) limit: $5,200 TY2025 / $5,300 TY2026). In dollars.",
    // no default
  },
  {
    id: "taxpayerProvidedOverHalfSupport",
    type: "bool",
    description:
      "The taxpayer provided more than half of the candidate's support (§ 152(d)(1)(C)).",
    // no default
  },
  {
    id: "depIsQualifyingChildOfAnother",
    type: "bool",
    description:
      "Candidate is the qualifying child of the taxpayer or any other taxpayer (§ 152(d)(1)(D)).",
    default: {
      value: false,
      rationale: "Assumed not anyone's qualifying child absent contrary input",
    },
  },
  {
    id: "hasMultipleSupportAgreement",
    type: "bool",
    description:
      "A § 152(d)(3) multiple-support agreement is in place for the candidate: the group together provided over half the support, no one person provided over half, each member could otherwise claim the candidate, and every other over-10% contributor signed a Form 2120 waiver.",
    default: {
      value: false,
      rationale: "Assumed no multiple-support agreement absent contrary input",
    },
  },
  {
    id: "taxpayerProvidedOver10PercentSupport",
    type: "bool",
    description:
      "The taxpayer contributed over 10 percent of the candidate's support (§ 152(d)(3)(D) — the support test under a multiple-support agreement).",
    // no default — only demanded when a multiple-support agreement exists
  },
  {
    id: "depDivorcedParentsRule",
    type: "bool",
    description:
      "§ 152(e) applies to the candidate child: the parents are divorced, separated, or lived apart the last 6 months of the year; the child received over half their support from the parents and was in their custody over half the year.",
    default: {
      value: false,
      rationale: "Assumed the divorced-parents rule does not apply absent contrary input",
    },
  },
  {
    id: "taxpayerIsCustodialParent",
    type: "bool",
    description:
      "The taxpayer is the custodial parent (the parent with whom the child resided the greater number of nights, § 152(e)(4)(A)).",
    // no default — only demanded when § 152(e) applies; the engine must not
    // guess which side of the release the taxpayer is on
  },
  {
    id: "custodialParentReleasedClaim",
    type: "bool",
    description:
      "The custodial parent signed a written declaration (Form 8332) releasing the claim to the child for this year (§ 152(e)(2)).",
    // no default — only demanded when § 152(e) applies
  },
  {
    id: "isAtLeastAge25",
    type: "bool",
    description:
      "Taxpayer attained age 25 before the close of the taxable year (26 U.S.C. § 32(c)(1)(A)(ii)(II), childless EITC age floor).",
    // no default — only demanded when the childless-EITC branch is actually
    // reachable; the engine must not guess an eligibility age
  },
  {
    id: "spouseItemizes",
    type: "bool",
    description:
      "Spouse itemizes deductions on a separate return (26 U.S.C. § 63(c)(6)(A)) — if so, an MFS filer's standard deduction is zero.",
    // no default — only demanded for married-filing-separately evaluations
  },

  // ---- Pennsylvania deep pack (state-pa.ts) -------------------------------
  // PA classes are TRANSCRIBED separately from the federal facts: PA
  // classification diverges (capital-gain distributions are dividends,
  // 401(k) deferrals are taxable compensation, eligible retirement income is
  // exempt), so nothing here is auto-mapped from taxableInterest etc.
  {
    id: "paCompensationAdjustment",
    type: "money",
    description:
      "PA compensation adjustment: W-2 Box 16 total MINUS Box 1 total (PA taxes 401(k)/elective deferrals as compensation; active-duty pay outside PA and other exempt items reduce it). May be negative. Default 0 assumes Box 16 = Box 1. Taxable early retirement-plan/IRA distributions under PA's cost-recovery method also go here. In dollars.",
    default: { value: "0", rationale: "PA W-2 Box 16 assumed equal to federal Box 1 wages absent contrary input" },
  },
  {
    id: "paUnreimbursedBusinessExpenses",
    type: "money",
    min: "0",
    description:
      "PA Schedule UE unreimbursed employee business expenses (PA-40 line 1b) — a compensation-class expense, not a line-10 deduction. In dollars.",
    default: { value: "0", rationale: "No unreimbursed employee business expenses claimed absent contrary input" },
  },
  {
    id: "paInterestIncome",
    type: "money",
    min: "0",
    description:
      "PA-taxable interest income (PA-40 line 2, gross class — no expenses; forfeited-interest penalties may offset within the class before entry). Includes commercial-annuity income taxable as PA interest. In dollars.",
    default: { value: "0", rationale: "No PA interest income absent contrary input" },
  },
  {
    id: "paDividendIncome",
    type: "money",
    min: "0",
    description:
      "PA-taxable dividend income (PA-40 line 3, gross class) INCLUDING mutual-fund capital gains distributions, which PA classifies as dividends. In dollars.",
    default: { value: "0", rationale: "No PA dividend income absent contrary input" },
  },
  {
    id: "paBusinessNetIncome",
    type: "money",
    description:
      "Taxpayer's own net income or LOSS from business/profession/farm (PA-40 line 4 class, after within-class netting of the taxpayer's own activities). Negative allowed; a loss never offsets other classes or the spouse. In dollars.",
    default: { value: "0", rationale: "No business income or loss absent contrary input" },
  },
  {
    id: "paSpouseBusinessNetIncome",
    type: "money",
    description:
      "Spouse's own net income or LOSS from business/profession/farm (PA-40 line 4 class). Negative allowed; never netted against the taxpayer's. In dollars.",
    default: { value: "0", rationale: "No spouse business income or loss absent contrary input" },
  },
  {
    id: "paPropertyGainNet",
    type: "money",
    description:
      "Taxpayer's own net gain or LOSS from sale/exchange/disposition of property (PA-40 line 5 class). Negative allowed; no carryover, no cross-class or spousal offset. In dollars.",
    default: { value: "0", rationale: "No property gain or loss absent contrary input" },
  },
  {
    id: "paSpousePropertyGainNet",
    type: "money",
    description:
      "Spouse's own net gain or LOSS from disposition of property (PA-40 line 5 class). Negative allowed; never netted against the taxpayer's. In dollars.",
    default: { value: "0", rationale: "No spouse property gain or loss absent contrary input" },
  },
  {
    id: "paRentRoyaltyNet",
    type: "money",
    description:
      "Taxpayer's own net income or LOSS from rents/royalties/patents/copyrights (PA-40 line 6 class). Negative allowed; short-term rentals (<30 days) belong in the business class instead. In dollars.",
    default: { value: "0", rationale: "No rent/royalty income or loss absent contrary input" },
  },
  {
    id: "paSpouseRentRoyaltyNet",
    type: "money",
    description:
      "Spouse's own net income or LOSS from rents/royalties/patents/copyrights (PA-40 line 6 class). Negative allowed; never netted against the taxpayer's. In dollars.",
    default: { value: "0", rationale: "No spouse rent/royalty income or loss absent contrary input" },
  },
  {
    id: "paEstateTrustIncome",
    type: "money",
    min: "0",
    description:
      "PA-taxable income from estates or trusts (PA-40 line 7, Schedule J) — an estate or trust cannot distribute a loss, so this is never negative. In dollars.",
    default: { value: "0", rationale: "No estate/trust income absent contrary input" },
  },
  {
    id: "paGamblingWinnings",
    type: "money",
    min: "0",
    description:
      "PA-taxable gambling and lottery winnings (PA-40 line 8, Schedule T) net of wager costs (PA Lottery ticket costs deductible only for tickets bought on/after 1/1/2016); noncash PA Lottery prizes are exempt. In dollars.",
    default: { value: "0", rationale: "No gambling winnings absent contrary input" },
  },
  {
    id: "pa529Contributions",
    type: "money",
    min: "0",
    description:
      "PA Schedule O § 529 tuition-program contribution deduction, ALREADY capped by the caller at $19,000 per beneficiary per taxpayer-spouse (2025) — the corpus cannot see per-beneficiary detail. No deduction for 529-to-529 rollovers or beneficiary changes. In dollars.",
    default: { value: "0", rationale: "No 529 contributions claimed absent contrary input" },
  },
  {
    id: "paAbleContributions",
    type: "money",
    min: "0",
    description:
      "PA Schedule O § 529A ABLE contribution deduction, capped by the caller at the annual federal gift-tax exclusion ($19,000 for 2025). In dollars.",
    default: { value: "0", rationale: "No ABLE contributions claimed absent contrary input" },
  },
  {
    id: "paMsaHsaContributions",
    type: "money",
    min: "0",
    description:
      "PA Schedule O Medical Savings Account + Health Savings Account contribution deductions — limited to the amounts allowed for FEDERAL income tax purposes (supply the federal-allowed total). In dollars.",
    default: { value: "0", rationale: "No MSA/HSA deduction claimed absent contrary input" },
  },
  {
    id: "paSpDependentChildren",
    type: "int",
    min: "0",
    description:
      "PA Schedule SP dependent CHILDREN count (natural/adopted/step; grandchild of a grandparent; foster child of a foster parent — never aunts/uncles/unrelated persons) claimable as federal dependents; adult qualifying children count. Raises the Tax Forgiveness eligibility-income threshold $9,500 each.",
    default: {
      value: "0",
      rationale: "Conservative: no SP dependent children assumed — understates the forgiveness threshold, never overstates the credit",
    },
  },
  {
    id: "paEligibilityIncomeAddbacks",
    type: "money",
    min: "0",
    description:
      "PA Schedule SP Section III nontaxable add-backs to eligibility income: nontaxable interest/dividends/gains, alimony received, insurance proceeds and inheritances (incl. 1099-R code-4 box 1), gifts/awards/prizes (incl. noncash PA Lottery), non-PA income, nontaxable military pay (not combat), excluded home-sale gain, nontaxable educational assistance, outside cash support. Do NOT add Social Security/RRB, eligible retirement benefits, child support, military pensions, workers' comp, personal-injury damages, or sick/disability pay. In dollars.",
    default: { value: "0", rationale: "No nontaxable eligibility-income add-backs absent contrary input" },
  },
  {
    id: "paResidentCredit",
    type: "money",
    min: "0",
    description:
      "PA resident credit for income tax paid to other states (PA-40 line 22, Schedule G-L; not allowed for reciprocal-state compensation: IN, MD, NJ, OH, VA, WV). Subtracts from tax BEFORE Tax Forgiveness per Schedule SP Section IV. In dollars.",
    default: { value: "0", rationale: "No other-state tax credit claimed absent contrary input" },
  },

  // ---- New Jersey deep pack (state-nj.ts) ---------------------------------
  {
    id: "njGrossIncome",
    type: "money",
    min: "0",
    description:
      "New Jersey gross income (NJ-1040 line 29: total category income minus the pension/retirement exclusions, BEFORE exemptions and deductions) — keys the Estimated Use Tax Chart (us.nj.use_tax) and the $10,000/$20,000 filing threshold. In dollars.",
    default: { value: "0", rationale: "Assumed no NJ gross income absent contrary input (bottom use-tax tier)" },
  },
  {
    id: "njFederalCdcc",
    type: "money",
    min: "0",
    description:
      "The federal child and dependent care credit (Form 2441) — Worksheet J line 1 input for us.nj.cdcc. Where the federal liability limit zeroed an otherwise-allowable credit, NJ's mock-return guidance supports the credit the filer WOULD have been eligible for; disclose which 2441 amount was supplied. In dollars.",
    default: { value: "0", rationale: "No federal child and dependent care credit claimed absent contrary input" },
  },
  {
    id: "njChildrenUnder6",
    type: "int",
    min: "0",
    description:
      "Count of dependents claimed on NJ-1040 lines 10/11 who were age 5 or younger on the last day of the tax year (born 2020 or later for TY2025) — the NJ Child Tax Credit multiplier (us.nj.ctc).",
    default: { value: "0", rationale: "No children age 5 or younger assumed absent contrary input" },
  },
  {
    id: "njPensionIncome",
    type: "money",
    min: "0",
    description:
      "NJ-1040 line 20a taxable pension/annuity/IRA income ELIGIBLE for the line 28a exclusion — on a joint return where only one spouse is 62+/disabled, ONLY that spouse's pension income (the ineligible spouse's share never excludes). In dollars.",
    default: { value: "0", rationale: "No eligible pension income absent contrary input" },
  },
  {
    id: "njTotalIncome",
    type: "money",
    min: "0",
    description:
      "NJ-1040 line 27 total income (all categories, before the pension exclusion) — the pension-exclusion chart tier and $150,000 cliff key on this amount. In dollars.",
    default: { value: "0", rationale: "Assumed no NJ total income absent contrary input" },
  },
  {
    id: "njPensionEligible",
    type: "bool",
    description:
      "NJ pension-exclusion age/disability gate attested: the filer (or spouse on a joint return) was age 62 or older OR blind/disabled per Social Security guidelines on the last day of the tax year (2025 NJ-1040 line 28a).",
    default: { value: false, rationale: "Conservative: exclusion eligibility not attested — no exclusion" },
  },
  {
    id: "njEitcAgeDecoupled",
    type: "bool",
    description:
      "NJ flat-$260 EITC eligibility attested (2025 NJ-1040 line 58): no qualifying child, at least 18 years old, met ALL federal EIC requirements except the age requirement (NJ eliminated both the under-25 floor and the 65+ ceiling), and not claimed as a dependent on another return.",
    default: { value: false, rationale: "Conservative: age-decoupled NJEITC eligibility not attested" },
  },
  {
    id: "njPropertyTaxesPaid",
    type: "money",
    min: "0",
    description:
      "NJ-1040 line 40a: property taxes due and paid on the principal residence (homeowners), or 18% of rent paid (tenants; 18% of site fees for mobile-home owners), after any Worksheet G multi-owner/multi-unit proration. In dollars.",
    default: { value: "0", rationale: "No property taxes/rent-equivalent paid absent contrary input" },
  },
  {
    id: "njMfsSameHome",
    type: "bool",
    description:
      "Married filing separately AND both spouses maintained the SAME principal residence — halves the NJ property tax deduction cap ($7,500) and the credit/threshold amounts ($25).",
    default: { value: false, rationale: "Assumed separate filers did not share the same main home absent contrary input" },
  },

  // ---- Ohio deep pack (state-oh.ts) ---------------------------------------
  {
    id: "ohModifiedAgi",
    type: "money",
    description:
      "Ohio modified adjusted gross income (MAGI): Ohio adjusted gross income (IT 1040 line 3) PLUS the business income deduction (Schedule of Adjustments line 13) — the base for the exemption tiers and most credit gates (2025 booklet p. 8). Can be negative. In dollars.",
    default: { value: "0", rationale: "Assumed no Ohio MAGI absent contrary input" },
  },
  {
    id: "ohExemptionCount",
    type: "int",
    min: "0",
    description:
      "IT 1040 line 4 exemption count: self (unless claimable as a dependent on another return), spouse if filing jointly, plus federal dependents (Schedule of Dependents).",
    default: { value: "1", rationale: "Assumed a single self-exemption absent contrary input" },
  },
  {
    id: "ohTaxableBusinessIncome",
    type: "money",
    min: "0",
    description:
      "IT 1040 line 6 taxable business income (Schedule of Business Income line 15: business income remaining after the $250,000/$125,000 Business Income Deduction, limited to the line 5 Ohio income tax base) — taxed flat 3% by us.oh.business_income_tax. In dollars.",
    default: { value: "0", rationale: "No taxable business income absent contrary input" },
  },
  {
    id: "ohEligibleRetirementIncome",
    type: "money",
    min: "0",
    description:
      "Retirement income received on account of retirement and still INCLUDED in Ohio AGI (both spouses combined) — the us.oh.retirement_income_credit Table 2 input. Excludes everything deducted on the Schedule of Adjustments (Social Security, railroad, uniformed-services retirement). In dollars.",
    default: { value: "0", rationale: "No qualifying retirement income absent contrary input" },
  },
  {
    id: "ohTaxLessCredits",
    type: "money",
    min: "0",
    description:
      "Ohio Schedule of Credits line 11 (line 8c tax less the line 2-9 credits) — the joint filing credit's percentage base. In dollars.",
    default: { value: "0", rationale: "Assumed no remaining Ohio tax absent contrary input" },
  },
  {
    id: "ohBothSpousesHaveQualifyingIncome",
    type: "bool",
    description:
      "Ohio joint filing credit gate attested: each spouse has at least $500 of QUALIFYING income included in Ohio AGI — not interest, dividends/distributions, capital gains, or rents/royalties, and not amounts deducted on the Schedule of Adjustments (deducted business income, Social Security, uniformed-services retirement never qualify).",
    default: { value: false, rationale: "Conservative: per-spouse $500 qualifying income not attested — no joint filing credit" },
  },
  {
    id: "ohFederalCdccTentative",
    type: "money",
    min: "0",
    description:
      "Federal Form 2441 line 9c (the tentative child and dependent care credit BEFORE the federal liability limit; equals line 9a absent prior-year-expense amounts) — the Ohio CDCC's 100% base when MAGI is under $20,000. In dollars.",
    default: { value: "0", rationale: "No federal Form 2441 tentative credit absent contrary input" },
  },
  {
    id: "ohFederalCdccAllowed",
    type: "money",
    min: "0",
    description:
      "Federal Form 2441 line 11 (the liability-LIMITED child and dependent care credit actually allowed federally) — the Ohio CDCC's 25% base when MAGI is $20,000-$39,999. In dollars.",
    default: { value: "0", rationale: "No federal Form 2441 allowed credit absent contrary input" },
  },

  // ---- North Carolina deep pack (state-nc.ts) -----------------------------
  {
    id: "ncFederalAgi",
    type: "money",
    description:
      "Federal adjusted gross income (D-400 line 6, Form 1040 line 11 verbatim) — keys the NC child-deduction table tiers and the Schedule A 7.5% medical floor. Can be negative. In dollars.",
    default: { value: "0", rationale: "Assumed no federal AGI absent contrary input" },
  },
  {
    id: "ncMortgageInterest",
    type: "money",
    min: "0",
    description:
      "NC Schedule A qualified home mortgage interest (IRC § 163(h)) — combined with real estate property taxes under the $20,000 NC cap (both spouses combined, MFJ or MFS). In dollars.",
    default: { value: "0", rationale: "No mortgage interest claimed absent contrary input" },
  },
  {
    id: "ncRealEstateTaxes",
    type: "money",
    min: "0",
    description:
      "NC Schedule A real estate property taxes (IRC § 164 real property portion only — NC allows NO state/local income tax deduction) — inside the $20,000 combined cap with mortgage interest. In dollars.",
    default: { value: "0", rationale: "No real estate taxes claimed absent contrary input" },
  },
  {
    id: "ncCharitable",
    type: "money",
    min: "0",
    description:
      "NC Schedule A charitable contributions allowed under IRC § 170 for the year (federal AGI-percentage limits apply; NO NC dollar cap and no § 68 overall limitation). In dollars.",
    default: { value: "0", rationale: "No charitable contributions claimed absent contrary input" },
  },
  {
    id: "ncMedicalExpenses",
    type: "money",
    min: "0",
    description:
      "NC Schedule A line 7a qualified medical and dental expenses BEFORE the floor — the rule subtracts 7.5% of ncFederalAgi (D-400 Schedule A lines 7b-7d). In dollars.",
    default: { value: "0", rationale: "No medical expenses claimed absent contrary input" },
  },
  {
    id: "ncClaimOfRightRepayment",
    type: "money",
    min: "0",
    description:
      "NC Schedule A line 8 repayment of claim-of-right income (repayments over $3,000 deducted in full — supply only qualifying amounts). In dollars.",
    default: { value: "0", rationale: "No claim-of-right repayment absent contrary input" },
  },

  // ---- Georgia deep pack (state-ga.ts) ------------------------------------
  {
    id: "gaFederalAgi",
    type: "money",
    description:
      "Federal adjusted gross income (Form 500 line 8, Form 1040 line 11 verbatim — never federal taxable income) — keys the Low Income Credit table. Can be negative. In dollars.",
    default: { value: "0", rationale: "Assumed no federal AGI absent contrary input" },
  },
  {
    id: "gaDependentCount",
    type: "int",
    min: "0",
    description:
      "Form 500 line 7c total dependents (7a qualified + 7b unborn-with-heartbeat; never self/spouse) — each worth the $4,000 Georgia dependent exemption (us.ga.dependent_exemption).",
    default: { value: "0", rationale: "No dependents assumed absent contrary input" },
  },
  {
    id: "gaLicExemptions",
    type: "int",
    min: "0",
    description:
      "GA Low Income Credit Worksheet line 2 exemptions: self + spouse + natural/legally adopted children ONLY (never other dependents, never unborn dependents).",
    default: { value: "0", rationale: "Conservative: no LIC exemptions attested — no credit" },
  },
  {
    id: "gaLic65Count",
    type: "int",
    min: "0",
    description:
      "GA Low Income Credit Worksheet line 3: 1 if filer or spouse is 65+, 2 if both (the statute's 65+ double credit as extra exemptions).",
    default: { value: "0", rationale: "No 65+ additions assumed absent contrary input" },
  },
  {
    id: "gaExclusionTier",
    type: "enum",
    enumValues: ["none", "62to64OrDisabled", "65plus"],
    description:
      "Primary taxpayer's Georgia retirement-exclusion tier (O.C.G.A. § 48-7-27(a)(5)(D)): 62-64 during any part of the year or permanently and totally disabled → $35,000 cap; 65+ during any part of the year → $65,000 cap.",
    default: { value: "none", rationale: "Conservative: exclusion eligibility not attested — no exclusion" },
  },
  {
    id: "gaSpouseExclusionTier",
    type: "enum",
    enumValues: ["none", "62to64OrDisabled", "65plus"],
    description:
      "Spouse's Georgia retirement-exclusion tier (each spouse qualifies separately; the exclusion is never shared).",
    default: { value: "none", rationale: "Conservative: spouse eligibility not attested — no exclusion" },
  },
  {
    id: "gaRetirementIncome",
    type: "money",
    min: "0",
    description:
      "Primary taxpayer's UNEARNED retirement income for the Georgia exclusion (pensions, annuities, interest, dividends, net rents, capital gains, royalties, military retirement — jointly-owned property income at 50%; NEVER Social Security/RRB, which subtract separately, and never lottery/gambling). In dollars.",
    default: { value: "0", rationale: "No retirement income absent contrary input" },
  },
  {
    id: "gaSpouseRetirementIncome",
    type: "money",
    min: "0",
    description: "Spouse's unearned retirement income for the Georgia exclusion (same definition, own items + 50% of joint). In dollars.",
    default: { value: "0", rationale: "No spouse retirement income absent contrary input" },
  },
  {
    id: "gaRetirementEarnedIncome",
    type: "money",
    min: "0",
    description:
      "Primary taxpayer's earned income (wages/salaries/business) — the exclusion counts at most $5,000 of it (Schedule 1 page 2 worksheet 'Maximum Earned Income'). In dollars.",
    default: { value: "0", rationale: "No earned income supplied for the exclusion worksheet" },
  },
  {
    id: "gaSpouseRetirementEarnedIncome",
    type: "money",
    min: "0",
    description: "Spouse's earned income for the exclusion worksheet (at most $5,000 counts). In dollars.",
    default: { value: "0", rationale: "No spouse earned income supplied for the exclusion worksheet" },
  },
  {
    id: "gaFederalCdccAllowed",
    type: "money",
    min: "0",
    description:
      "The federal § 21 child and dependent care credit CLAIMED AND ALLOWED (Form 2441 line 11, liability-limited) — Georgia's IND-CR 202 credit is 50% of it (us.ga.cdcc). In dollars.",
    default: { value: "0", rationale: "No federal CDCC allowed absent contrary input" },
  },
  {
    id: "mdSubdivision",
    type: "enum",
    enumValues: [
      "baltimore_city", "allegany", "anne_arundel", "baltimore_county", "calvert",
      "caroline", "carroll", "cecil", "charles", "dorchester", "frederick",
      "garrett", "harford", "howard", "kent", "montgomery", "prince_georges",
      "queen_annes", "st_marys", "somerset", "talbot", "washington", "wicomico",
      "worcester", "nonresident",
    ],
    description:
      "Maryland taxing subdivision — the county (or Baltimore City) where the filer resided on the LAST day of the tax year (Form 502 political-subdivision box), driving the us.md.local_tax rate (2025 chart: 2.25%-3.30%; Anne Arundel and Frederick are bracketed/tiered by filing status). Use nonresident for the Tax-Gen. \u00a7 10-106.1 special 2.25% nonresident rate.",
    // no default — the engine must never guess the taxing county
  },
  {
    id: "mdFagi",
    type: "money",
    description:
      "Federal adjusted gross income (Maryland Form 502 line 1) — keys the exemption phase-out chart (us.md.exemption_amount), the child tax credit phase-out (us.md.ctc), and the $350,000 Form 502CG surtax gate. May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 federal AGI absent contrary input" },
  },
  {
    id: "mdExemptionCount",
    type: "int",
    min: "0",
    description:
      "Maryland exemption COUNT: Form 502 Exemptions areas A (self + spouse) plus C (dependents from Form 502B line 3) — each worth the Chart 10A phased amount via us.md.exemption_amount. Do NOT include the age-65+/blind area-B boxes (those are a separate unphased $1,000 each).",
    default: { value: "1", rationale: "A single filer claiming their own exemption absent contrary input" },
  },
  {
    id: "mdDependentTaxpayer",
    type: "bool",
    description:
      "Maryland Filing Status 6 — the filer can be claimed as a dependent on another person's return: every Chart 10A exemption is $0 and the poverty level credit is denied (us.md.exemption_amount / us.md.poverty_level_credit).",
    default: { value: false, rationale: "Assumed not claimable as a dependent absent contrary input" },
  },
  {
    id: "mdQualifiedChildren",
    type: "int",
    min: "0",
    description:
      "Number of Maryland CTC qualified children on Form 502B: dependents UNDER 6 at year end, or over 5 and under 17 WITH a disability (assessment attached) — us.md.ctc ($500 each, H.B. 352 phase-out over $15,000 FAGI, gone above $24,000).",
    default: { value: "0", rationale: "Assumed no Maryland CTC qualified children absent contrary input" },
  },
  {
    id: "mdEarnedIncome",
    type: "money",
    min: "0",
    description:
      "Earned income for the Maryland poverty level credit (Form 502 line 1b / Worksheet 18B line 2): wages, salaries, tips, other employee compensation plus net self-employment profit — do NOT net farm/business losses. In dollars.",
    default: { value: "0", rationale: "Assumed no earned income absent contrary input" },
  },
  {
    id: "mdFagiPlusAdditions",
    type: "money",
    description:
      "Maryland Form 502 line 7 (federal AGI + Maryland additions) for the poverty level credit gate (Worksheet 18B line 1; MFS filers who filed a joint federal return use the JOINT federal AGI + additions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 line 7 absent contrary input" },
  },
  {
    id: "mdHouseholdSize",
    type: "int",
    min: "1",
    description:
      "Number of persons in the family/household from the federal return, for the Maryland poverty income guideline (2025: $15,650 for 1 + $5,500 each additional person — printed-chart exact through 8).",
    default: { value: "1", rationale: "A one-person household absent contrary input" },
  },
  {
    id: "mdNetCapitalGainSubject",
    type: "money",
    min: "0",
    description:
      "Form 502CG line 9 — net capital gain income SUBJECT to Maryland's 2% additional tax (line 1c gain minus the six 502CG exempt classes: primary-residence sale under $1.5M, retirement-plan assets, livestock, easement land, trade-or-business property, nonprofit affordable housing). Only nonzero when federal AGI exceeds $350,000. Feeds us.md.capital_gains_surtax (Form 502 lines 20a/21b). In dollars.",
    default: { value: "0", rationale: "Assumed no surtaxable net capital gain (FAGI at or below $350,000, or fully exempt classes) absent contrary input" },
  },
  {
    id: "mdQualifyingPension",
    type: "money",
    min: "0",
    description:
      "ONE person's qualifying pension/retirement annuity in federal AGI for the Maryland pension exclusion (Worksheet 13A line 1): \u00a7 401(a)/403/457(b) employee-retirement-system income only — IRAs (traditional/Roth/rollover), SEP, Keogh, ineligible deferred comp, and foreign retirement income do NOT qualify; the person must be 65+ or totally disabled (or have a totally disabled spouse). Evaluate us.md.pension_exclusion once per qualifying spouse. In dollars.",
    default: { value: "0", rationale: "Assumed no qualifying pension absent contrary input" },
  },
  {
    id: "mdSsRrBenefits",
    type: "money",
    min: "0",
    description:
      "The SAME person's TOTAL Social Security and Railroad Retirement benefits (Tier I + Tier II), whether or not federally taxable — Worksheet 13A line 3 reduces the $41,200 maximum dollar-for-dollar. On a joint return count only the pension-receiving spouse's benefits. In dollars.",
    default: { value: "0", rationale: "Assumed no Social Security/Railroad Retirement benefits absent contrary input" },
  },
  {
    id: "moMagi",
    type: "money",
    description:
      "COMBINED Missouri adjusted gross income (MO-1040 line 6 = both spouses' line 5 amounts) — keys the federal tax deduction percentage tiers (us.mo.federal_tax_deduction: 35/25/15/5/0%). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 combined Missouri AGI absent contrary input" },
  },
  {
    id: "moFederalTaxTotal",
    type: "money",
    min: "0",
    description:
      "MO-1040 line 11 total federal tax: line 9 (federal 1040 line 22 minus lines 27a/29, minus Schedule 2 Part 1 line 3, minus Schedule 3 Part 2 line 9 — never withholding) plus line 10 other federal tax (Schedule 2 Part 1 line 3; Part 2 lines 8, 14, 15; recapture in 21; Schedule 3 Part 1 line 1). Feeds us.mo.federal_tax_deduction. In dollars.",
    default: { value: "0", rationale: "Assumed no federal tax absent contrary input" },
  },
  {
    id: "moPublicPension",
    type: "money",
    min: "0",
    description:
      "ONE spouse's taxable pension from PUBLIC sources (any federal/state/local government pension, federal 1040 line 5b share) for the Missouri public pension exemption (us.mo.public_pension_exemption, MO-A Part 3 Section A: capped at $47,633 for 2025, reduced by that spouse's SS/SSD exemption). Military retirement is a separate 100% subtraction — exclude it here. In dollars.",
    default: { value: "0", rationale: "Assumed no public pension absent contrary input" },
  },
  {
    id: "moSsSameSpouseExemption",
    type: "money",
    min: "0",
    description:
      "The SAME spouse's Social Security / SS Disability exemption from MO-A Part 3 Section C (their taxable SS, exempted 100% when 62+ by December 31 or on SSD) — displaces the public pension exemption dollar-for-dollar (Section A line 3). In dollars.",
    default: { value: "0", rationale: "Assumed no Section C exemption for this spouse absent contrary input" },
  },
  {
    id: "moFederalEic",
    type: "money",
    min: "0",
    description:
      "Federal earned income credit (Form 1040 line 27a) for the Missouri Working Family Tax Credit (us.mo.wftc = 20% for 2025, nonrefundable; MFS and dependent-claimed filers denied; the printed MO-WFTC question 3 gates investment income at $4,400 — see the rule's form-vs-statute disclosure). In dollars.",
    default: { value: "0", rationale: "Assumed no federal EIC absent contrary input" },
  },
  {
    id: "moBusinessIncome",
    type: "money",
    min: "0",
    description:
      "ONE spouse's net business income per the MO-1040 p.16 worksheet (Schedule C/E/F + pass-through business income, losses netted — enter 0 if a combined net loss) — us.mo.business_income_deduction subtracts 20% (R.S.Mo. \u00a7 143.022, MO-A Part 1 line 17). In dollars.",
    default: { value: "0", rationale: "Assumed no business income absent contrary input" },
  },
  {
    id: "wiIncome",
    type: "money",
    description:
      "Wisconsin income (Form 1 line 7 = federal AGI as adjusted by Schedule I, plus Schedule AD additions, minus Schedule SB subtractions) — drives the sliding standard deduction (us.wi.standard_deduction). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 Wisconsin income absent contrary input" },
  },
  {
    id: "wiQualifyingChildren",
    type: "int",
    min: "0",
    description:
      "Number of federal-EIC qualifying children for the Wisconsin earned income credit (us.wi.eic: 1 → 4%, 2 → 11%, 3+ → 34% of the federal credit; zero children → no Wisconsin credit).",
    default: { value: "0", rationale: "Assumed no qualifying children absent contrary input" },
  },
  {
    id: "wiFederalEicForWi",
    type: "money",
    min: "0",
    description:
      "The federal earned income credit AS COMPUTED UNDER WISCONSIN'S IRC (Schedule I Part III recomputation when Part I adjustments exist; otherwise Form 1040 line 27) — the us.wi.eic base. In dollars.",
    default: { value: "0", rationale: "Assumed no federal EIC absent contrary input" },
  },
  {
    id: "wiLowerQualifiedEarnedIncome",
    type: "money",
    min: "0",
    description:
      "The LESSER-earning spouse's qualified earned income from Form 1 Schedule 2 line 5 (earned income minus the listed federal Schedule 1 adjustments and any Wisconsin disability exclusion) — us.wi.married_couple_credit takes 3% up to $480. In dollars.",
    default: { value: "0", rationale: "Assumed no qualified earned income absent contrary input" },
  },
  {
    id: "wiRentHeatIncluded",
    type: "money",
    min: "0",
    description:
      "2025 rent paid on the principal Wisconsin residence where HEAT WAS INCLUDED in rent (Form 1 line 16a) — credited at 2.4% via the printed table's $100-row midpoints (us.wi.school_property_tax_credit). In dollars.",
    default: { value: "0", rationale: "Assumed no heat-included rent absent contrary input" },
  },
  {
    id: "wiRentHeatNotIncluded",
    type: "money",
    min: "0",
    description:
      "2025 rent paid where heat was NOT included (Form 1 line 16a) — credited at 3.0% via the printed table. In dollars.",
    default: { value: "0", rationale: "Assumed no heat-not-included rent absent contrary input" },
  },
  {
    id: "wiPropertyTaxesPaid",
    type: "money",
    min: "0",
    description:
      "2025 property taxes paid on the principal Wisconsin residence (Form 1 line 16b) — credited at 12% via the printed table; the combined 16a+16b credit caps at $300 ($150 MFS). In dollars.",
    default: { value: "0", rationale: "Assumed no property taxes absent contrary input" },
  },
  {
    id: "wiRetirementIncome67",
    type: "money",
    min: "0",
    description:
      "Federally taxable qualified-plan/IRA retirement income of the 67+ individual(s) NOT already subtracted on Schedule SB lines 12-15 — the NEW 2025 Act 15 subtraction (us.wi.retirement_subtraction_67, $24,000/$48,000 cap). CAUTION: claiming it forfeits every Form 1 credit (lines 13-20, 30-35, Schedule CR). In dollars.",
    default: { value: "0", rationale: "Assumed no 67+ retirement income absent contrary input" },
  },
  {
    id: "wiBothSpouses67",
    type: "bool",
    description:
      "BOTH spouses on a joint Wisconsin return were at least 67 on December 31 — raises the Act 15 retirement subtraction cap from $24,000 to $48,000 regardless of which spouse received the income.",
    default: { value: false, rationale: "Assumed not both spouses 67+ absent contrary attestation" },
  },
  {
    id: "mnAgi",
    type: "money",
    description:
      "Federal adjusted gross income (Minnesota Form M1 line 1) — keys the standard-deduction limitation (us.mn.standard_deduction: 3%/10% reduction over $238,950, 80% floor), the dependent-exemption phase-out (us.mn.exemptions), and the Social Security subtraction thresholds (us.mn.social_security_subtraction). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 AGI absent contrary input" },
  },
  {
    id: "mnStdBoxes",
    type: "int",
    min: "0",
    description:
      "Count of Minnesota standard-deduction boxes checked (you/spouse 65-or-older — born before January 2, 1961 — and/or blind): each adds $2,000 (single/HOH) or $1,550 (MFJ/QSS/MFS) to the 2025 base (us.mn.standard_deduction).",
    default: { value: "0", rationale: "Assumed no 65+/blind boxes absent contrary input" },
  },
  {
    id: "mnDependentEarnedIncome",
    type: "money",
    min: "0",
    description:
      "A dependent-claimed filer's earned income for the Minnesota dependent standard-deduction worksheet (deduction = lesser of the table amount or max($1,250, earned + $350)). Only used when isClaimedAsDependent. In dollars.",
    default: { value: "0", rationale: "Assumed no earned income absent contrary input" },
  },
  {
    id: "mnDependents",
    type: "int",
    min: "0",
    description:
      "Number of dependents claimed on Minnesota Schedule M1DQC — $5,200 each for 2025 (us.mn.exemptions, phased 2% per $2,500 ceil-step of AGI over the filing-status threshold).",
    default: { value: "0", rationale: "Assumed no dependents absent contrary input" },
  },
  {
    id: "mnTaxableSs",
    type: "money",
    min: "0",
    description:
      "Federally taxable Social Security benefits (Form 1040 line 6b) for the Minnesota Social Security subtraction (us.mn.social_security_subtraction — simplified method; compute the M1M alternative method separately and take the greater when AGI exceeds the full-subtraction threshold). In dollars.",
    default: { value: "0", rationale: "Assumed no taxable Social Security absent contrary input" },
  },
  {
    id: "mnNetInvestmentIncome",
    type: "money",
    min: "0",
    description:
      "Minnesota net investment income per Schedule NIIT (the federal Form 8960 concept minus class 2a agricultural-land gains) — us.mn.niit charges 1% of the amount over $1,000,000 (TY2024+, Minn. Stat. \u00a7 290.033). In dollars.",
    default: { value: "0", rationale: "Assumed no net investment income absent contrary input" },
  },
  {
    id: "scDependents",
    type: "int",
    min: "0",
    description:
      "South Carolina dependent count for the exemption being computed (us.sc.dependent_exemption, $4,930 each for 2025): pass the FULL federal dependent count for the SC1040 line w exemption, or the under-age-6 count for the additional line t deduction (evaluate the target once per line).",
    default: { value: "0", rationale: "Assumed no dependents absent contrary input" },
  },
  {
    id: "scQualifiedRetirementIncome",
    type: "money",
    min: "0",
    description:
      "One person's qualified retirement income for the South Carolina retirement deduction (401(k)/403(b)/457, IRA, Keogh — EXCLUDING military retirement, which is 100% deducted separately and reduces this deduction) — us.sc.retirement_deduction caps it at $3,000 (under 65) / $10,000 (65+). Per person; evaluate each spouse separately. In dollars.",
    default: { value: "0", rationale: "Assumed no qualified retirement income absent contrary input" },
  },
  {
    id: "scMilitaryRetirementDeduction",
    type: "money",
    min: "0",
    description:
      "The SAME person's military retirement deduction (SC1040 line p-4/p-5, 100% since TY2022) — the printed worksheet REDUCES the us.sc.retirement_deduction CAP ($3,000/$10,000) by this amount before limiting to qualified retirement income (instructions Example 5). In dollars.",
    default: { value: "0", rationale: "Assumed no military retirement deduction absent contrary input" },
  },
  {
    id: "scAgi",
    type: "money",
    description:
      "Federal adjusted gross income for the TY2026 South Carolina Income Adjusted Deduction phase-out (us.sc.income_adjusted_deduction: reduced by deduction x excess-over-$40,000/$60,000/$80,000 divided by $55,000/$82,500/$110,000, the reduction floored to $10s; H.4216). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 AGI absent contrary input (full deduction below the phase-out threshold)" },
  },
  {
    id: "scIs65",
    type: "bool",
    description:
      "The person whose South Carolina retirement deduction is being computed was 65 or older by December 31 — raises the us.sc.retirement_deduction cap from $3,000 to $10,000 (and gates the separate $15,000 age-65 deduction).",
    default: { value: false, rationale: "Assumed under 65 absent contrary attestation" },
  },
  {
    id: "scRetirementDeductionsClaimed",
    type: "money",
    min: "0",
    description:
      "The SAME person's South Carolina retirement deduction (line p-1/p-2) PLUS military retirement deduction (line p-4/p-5) already claimed — us.sc.age65_deduction reduces the $15,000 age-65 deduction by this amount per the printed worksheet. In dollars.",
    default: { value: "0", rationale: "Assumed no retirement deductions claimed absent contrary input" },
  },
  {
    id: "scLowerQualifiedEarnedIncome",
    type: "money",
    min: "0",
    description:
      "The LESSER-earning spouse's South Carolina qualified earned income per the Two Wage Earner Credit worksheet (SC earned income minus the federal adjustments attributable to it) — us.sc.two_wage_earner_credit pays 0.7% of it capped at $50,000 (max $350; married filing jointly only). In dollars.",
    default: { value: "0", rationale: "Assumed no second-earner income absent contrary input" },
  },
  {
    id: "scCareExpenses",
    type: "money",
    min: "0",
    description:
      "Federal Form 2441 child and dependent care EXPENSES (the expense amount, not the federal credit) — us.sc.cdcc pays 7% of it, capped $210/$420 (denied to married filing separately). In dollars.",
    default: { value: "0", rationale: "Assumed no care expenses absent contrary input" },
  },
  {
    id: "scCareChildren",
    type: "int",
    min: "0",
    description:
      "Count of qualifying children/dependents for the South Carolina Child and Dependent Care Credit — 2 or more raises the us.sc.cdcc cap from $210 to $420.",
    default: { value: "1", rationale: "Assumed one qualifying child absent contrary input (the conservative $210 cap)" },
  },
  {
    id: "alAgi",
    type: "money",
    description:
      "Alabama adjusted gross income (Form 40 line 10) — keys the AGI-phased standard deduction chart (us.al.standard_deduction) and the dependent exemption tiers (us.al.dependent_exemption: $1,000 to $50,000, $500 to $100,000, $300 above). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 AGI absent contrary input" },
  },
  {
    id: "alDependents",
    type: "int",
    min: "0",
    description:
      "Alabama dependent count (Form 40 line 14 / Schedule DS) under Alabama's OWN relationship-and-support definition (\u00a7 40-18-19 list + over-50% support; NOT federal \u00a7 152) — us.al.dependent_exemption pays $1,000/$500/$300 each by Alabama AGI.",
    default: { value: "0", rationale: "Assumed no dependents absent contrary input" },
  },
  {
    id: "alFederalTaxPlusNiit",
    type: "money",
    min: "0",
    description:
      "Federal Form 1040 LINE 22 tax PLUS Form 8960 line 17 Net Investment Income Tax — the gross federal tax for Alabama's unlimited federal income tax deduction worksheet (us.al.federal_tax_deduction). NEVER the W-2 federal withholding. In dollars.",
    default: { value: "0", rationale: "Assumed no federal tax absent contrary input" },
  },
  {
    id: "alFederalRefundableCredits",
    type: "money",
    min: "0",
    description:
      "The Alabama line 12 worksheet's refundable-credit subtraction: federal EIC (1040 line 27a) + Additional CTC (line 28) + American Opportunity Credit (line 29) + refundable adoption credit (line 30) + Form 2439 credits (Schedule 3 Part II line 13a). In dollars.",
    default: { value: "0", rationale: "Assumed no refundable federal credits absent contrary input" },
  },
  {
    id: "alTaxableRetirement",
    type: "money",
    min: "0",
    description:
      "One person's OTHERWISE-TAXABLE Alabama retirement income (IRA/401(k)/SEP/Keogh/403(b) distributions after basis recovery — defined-benefit pensions, Social Security, military, and US/AL government retirement are fully exempt and never enter) for the Schedule RS 65+ exclusion (us.al.retirement_exclusion, up to $6,000). Per person. In dollars.",
    default: { value: "0", rationale: "Assumed no taxable retirement income absent contrary input" },
  },
  {
    id: "alIs65",
    type: "bool",
    description:
      "The person whose Alabama retirement exclusion is being computed was 65 or older — gates the $6,000 Schedule RS exclusion (us.al.retirement_exclusion). Still $6,000 for TY2026 (HB388's $12,000 increase DIED May 2025).",
    default: { value: false, rationale: "Assumed under 65 absent contrary attestation" },
  },
  {
    id: "alOvertimePremium",
    type: "money",
    min: "0",
    description:
      "One taxpayer's overtime PREMIUM (the amount above the base rate — W-2 Box 12 code TT) for the TY2026-2028 Alabama overtime premium deduction (us.al.overtime_premium_deduction, Act 2026-604, capped $1,000 per taxpayer). In dollars.",
    default: { value: "0", rationale: "Assumed no overtime premium absent contrary input" },
  },
  {
    id: "orAgi",
    type: "money",
    description:
      "Federal adjusted gross income (Form OR-40 line 7) — keys the federal tax subtraction Table 4 phase-out (us.or.federal_tax_subtraction) and the exemption credit cliffs (us.or.exemption_credit: $100,000 single/MFS, $200,000 others; disability exemptions $100,000 for all). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 AGI absent contrary input" },
  },
  {
    id: "orFederalTaxLiability",
    type: "money",
    min: "0",
    description:
      "The Oregon federal tax liability worksheet line 10 result: 1040 line 22 minus excess-APTC repayment (floor 0), plus Schedule 2 lines 8/16/17 income taxes, minus AOC + refundable adoption + Form 8962 line 24 PTC (floor 0 — the EITC and ACTC are NOT subtracted) — us.or.federal_tax_subtraction caps it at $8,500/$4,250-MFS with the Table 4 AGI phase-out. In dollars.",
    default: { value: "0", rationale: "Assumed no federal tax liability absent contrary input" },
  },
  {
    id: "orStdBoxes",
    type: "int",
    min: "0",
    description:
      "Count of Oregon standard-deduction boxes 17a-d (you/spouse turned 65 by January 1, 2026, and/or blind) — each adds $1,200 (single/HOH) or $1,000 (other statuses) (us.or.standard_deduction).",
    default: { value: "0", rationale: "Assumed no 65+/blind boxes absent contrary input" },
  },
  {
    id: "orDependentEarnedIncome",
    type: "money",
    min: "0",
    description:
      "A dependent-claimed filer's earned income for Oregon's dependent standard-deduction limit (larger of $1,350 or earned + $450, capped at the Table 5 amount). Only used when isClaimedAsDependent. In dollars.",
    default: { value: "0", rationale: "Assumed no earned income absent contrary input" },
  },
  {
    id: "orRegularExemptions",
    type: "int",
    min: "0",
    description:
      "Oregon regular exemption count (OR-40 boxes 6a/6b 'regular' + line 6c dependents) — $256 each for 2025, $0 above the $100,000/$200,000 federal AGI cliff (us.or.exemption_credit).",
    default: { value: "0", rationale: "Assumed no exemptions absent contrary input" },
  },
  {
    id: "orDisabilityExemptions",
    type: "int",
    min: "0",
    description:
      "Oregon severe-disability exemption boxes (6a/6b) plus children with a qualifying disability (line 6d) — $256 each, $0 above $100,000 federal AGI for EVERY filing status (us.or.exemption_credit).",
    default: { value: "0", rationale: "Assumed no disability exemptions absent contrary input" },
  },
  {
    id: "orFederalEic",
    type: "money",
    min: "0",
    description:
      "The federal earned income credit (Form 1040 line 27a) — us.or.eic pays 9% of it (12% when the youngest dependent is under 3). In dollars.",
    default: { value: "0", rationale: "Assumed no federal EIC absent contrary input" },
  },
  {
    id: "orYoungestUnder3",
    type: "bool",
    description:
      "The filer's youngest dependent was younger than 3 at the end of the tax year — raises the Oregon EIC percentage from 9% to 12% of the federal EITC (us.or.eic, Table 9).",
    default: { value: false, rationale: "Assumed no dependent under 3 absent contrary input" },
  },
  {
    id: "orKidsQualifyingIncome",
    type: "money",
    description:
      "Oregon Kids Credit worksheet line 4 qualifying income: OR-40 line 15 income-after-subtractions + OR-ASC code 390/391/392 (tips/overtime/vehicle-interest) addbacks + the Part B loss-and-exclusion addback (losses beyond $20,000 and all excluded foreign earned income) — us.or.kids_credit phases out $26,550-$31,550. May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 qualifying income absent contrary input" },
  },
  {
    id: "orKidsUnder6",
    type: "int",
    min: "0",
    description:
      "Dependents age 5 or younger at the end of 2025 for the Oregon Kids Credit — $1,050 each, capped at 5 children by us.or.kids_credit (refundable; MFS denied; released-exemption children do not count).",
    default: { value: "0", rationale: "Assumed no children under 6 absent contrary input" },
  },
  {
    id: "or2024TaxLiability",
    type: "money",
    min: "0",
    description:
      "The 2024 total Oregon personal income tax liability: 2024 OR-40 line 24 tax-before-credits MINUS the Schedule OR-ASC code 802/815 credit for taxes paid to another state (Kicker worksheet Part A — NOT line 31, which is after the exemption and other credits) — us.or.kicker pays 9.863% of it on the 2025 return. Requires the 2024 return filed before the 2025 return. In dollars.",
    default: { value: "0", rationale: "Assumed no 2024 liability absent contrary input (no kicker)" },
  },
  // ---- Oklahoma (Form 511) ----
  {
    id: "okFederalAgi",
    type: "money",
    description:
      "Federal adjusted gross income (Form 511 line 1 = Form 1040 line 11) — keys the $100,000 child care/child tax credit cliff and the Schedule 511-F/511-G proration denominators (us.ok.child_care_child_tax_credit, us.ok.eic), the special 65+ exemption income limits (us.ok.exemptions, after removing Roth conversion income), and the use tax table (us.ok.use_tax). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 federal AGI absent contrary input" },
  },
  {
    id: "okAgi",
    type: "money",
    description:
      "Oklahoma adjusted gross income (Form 511 line 7) — the proration numerator when it is below federal AGI (Schedules 511-F and 511-G: credit x line 7 / line 1, not more than 100%). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 Oklahoma AGI absent contrary input" },
  },
  {
    id: "okRothConversionIncome",
    type: "money",
    min: "0",
    description:
      "Income from converting a traditional IRA to a Roth IRA that is included in federal AGI — excluded from federal AGI ONLY for the special 65+ exemption income limits (68 O.S. § 2358(E)(1)(c); Form 511 exemption instructions). In dollars.",
    default: { value: "0", rationale: "Assumed no Roth conversion income absent contrary input" },
  },
  {
    id: "okBasicExemptions",
    type: "int",
    min: "0",
    description:
      "Count of Oklahoma exemptions with NO income test: 'yourself' + 'spouse' regular boxes, legally-blind boxes, and dependents (Form 511 page 1) — $1,000 each (us.ok.exemptions). A filer claimable as someone's dependent enters 0 for 'yourself'.",
    default: { value: "0", rationale: "Assumed no exemptions absent contrary input" },
  },
  {
    id: "okSpecialExemptions65",
    type: "int",
    min: "0",
    description:
      "Count of Oklahoma SPECIAL exemption boxes (taxpayer and/or spouse 65 or older at year end, 0-2) — $1,000 each ONLY when federal AGI (less Roth conversion income) is at or under $15,000 single / $25,000 joint / $12,500 MFS / $19,000 head of household (us.ok.exemptions).",
    default: { value: "0", rationale: "Assumed no 65-or-older special exemptions absent contrary input" },
  },
  {
    id: "okFederalItemizedTotal",
    type: "money",
    min: "0",
    description:
      "Federal Schedule A line 17 total itemized deductions (Schedule 511-D line 1) — the starting point for Oklahoma itemized deductions (us.ok.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed no federal itemized deductions absent contrary input" },
  },
  {
    id: "okFederalSaltDeducted",
    type: "money",
    min: "0",
    description:
      "State and local income OR general sales taxes from federal Schedule A line 5a to the extent actually included in line 5e after the SALT cap (Schedule 511-D line 2) — Oklahoma adds them back (us.ok.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed no state/local income or sales tax deducted absent contrary input" },
  },
  {
    id: "okFederalMedical",
    type: "money",
    min: "0",
    description:
      "Medical and dental expenses deducted on federal Schedule A line 4 (Schedule 511-D lines 4 and 9) — exempt from Oklahoma's $17,000 itemized cap (us.ok.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed no medical deduction absent contrary input" },
  },
  {
    id: "okFederalCharity",
    type: "money",
    min: "0",
    description:
      "Gifts to charity deducted on federal Schedule A line 14 (Schedule 511-D lines 5 and 10) — exempt from Oklahoma's $17,000 itemized cap (us.ok.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed no charitable deduction absent contrary input" },
  },
  {
    id: "okGovRetirementYou",
    type: "money",
    min: "0",
    description:
      "TAXPAYER's Oklahoma-government or federal civil service retirement benefits included in federal AGI (Schedule 511-A line 5 systems: OPERS, TRS, OLERS, firefighters, police, judges, county/municipal systems, US civil service other than CSRS-in-lieu-of-SS) — excluded up to $10,000 per person (us.ok.retirement_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed no government retirement income absent contrary input" },
  },
  {
    id: "okGovRetirementSpouse",
    type: "money",
    min: "0",
    description:
      "SPOUSE's Oklahoma-government or federal civil service retirement benefits included in federal AGI (Schedule 511-A line 5) — the $10,000 limit is per individual, in that person's name (us.ok.retirement_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed no spouse government retirement income absent contrary input" },
  },
  {
    id: "okOtherRetirementYou",
    type: "money",
    min: "0",
    description:
      "TAXPAYER's other qualifying retirement income included in federal AGI (Schedule 511-A line 6: IRC 401 plans, 457 plans, 408 IRAs/SEPs, 403(a)/(b) annuities, 402(e) lump sums) — excluded up to $10,000 per person MINUS the same person's line 5 exclusion (us.ok.retirement_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed no other retirement income absent contrary input" },
  },
  {
    id: "okOtherRetirementSpouse",
    type: "money",
    min: "0",
    description:
      "SPOUSE's other qualifying retirement income included in federal AGI (Schedule 511-A line 6) — same per-person $10,000 combined limit (us.ok.retirement_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed no spouse other retirement income absent contrary input" },
  },
  {
    id: "okFederalChildCareCredit",
    type: "money",
    min: "0",
    description:
      "Federal credit for child and dependent care expenses allowed (Form 2441 / Schedule 3 line 2) — Oklahoma allows 20% of it (us.ok.child_care_child_tax_credit, the greater-of test). In dollars.",
    default: { value: "0", rationale: "Assumed no federal child care credit absent contrary input" },
  },
  {
    id: "okFederalChildTaxCredit",
    type: "money",
    min: "0",
    description:
      "Federal child tax credit PLUS additional child tax credit allowed (Form 1040 line 19 + line 28 from Schedule 8812) — Oklahoma allows 5% of the total (us.ok.child_care_child_tax_credit, the greater-of test). NOTE: line 19 also carries the $500 § 24(h)(4) credit for other dependents; the packet names only the CTC and ACTC — the ODC is part of § 24 (\"the child tax credit allowed under the IRC\"), so include it but disclose when one is present. In dollars.",
    default: { value: "0", rationale: "Assumed no federal child tax credit absent contrary input" },
  },
  {
    id: "okEicEligible",
    type: "bool",
    description:
      "Filer meets the FEDERAL 2020-law EIC requirements Oklahoma freezes to (68 O.S. § 2357.43): work-valid SSNs, not married filing separately, investment income $3,650 or less, and — with no qualifying child — age 25 to 64 and not a dependent (us.ok.eic_2020_rules). Unattested = $0.",
    default: { value: false, rationale: "Assumed NOT eligible absent an explicit attestation (conservative: no credit)" },
  },
  {
    id: "okEicQualifyingChildren",
    type: "int",
    min: "0",
    description:
      "Number of EIC qualifying children under the 2020 federal rules (0, 1, 2, or 3-or-more — the table caps at 3) for us.ok.eic_2020_rules.",
    default: { value: "0", rationale: "Assumed no qualifying children absent contrary input" },
  },
  {
    id: "okEicEarnedIncome",
    type: "money",
    min: "0",
    description:
      "Total earned income on Form 511-EIC line 15 (wages less excluded Medicaid waiver payments, plus elected nontaxable combat pay, plus net self-employment earnings) for the year being computed — Oklahoma lets the filer use 2025 OR 2024 earned income (us.ok.eic_2020_rules; run once per year and keep the larger). In dollars.",
    default: { value: "0", rationale: "Assumed no earned income absent contrary input" },
  },
  {
    id: "okEicAgi",
    type: "money",
    description:
      "Federal AGI (Form 1040 line 11) for the SAME year as okEicEarnedIncome — Form 511-EIC line 17: when it reaches the table's phase-out row ($8,800 no children / $19,350 with children; $14,700 / $25,250 married filing jointly) the credit is the SMALLER of the table amounts at earned income and at AGI (us.ok.eic_2020_rules). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 AGI absent contrary input" },
  },
  {
    id: "okEic2020Amount",
    type: "money",
    min: "0",
    description:
      "The federal earned income credit computed under 2020 rules on Form 511-EIC line 20 (the larger of the 2024 and 2025 columns — each is us.ok.eic_2020_rules) — us.ok.eic pays 5% of it, prorated by Oklahoma AGI over federal AGI. In dollars.",
    default: { value: "0", rationale: "Assumed no 2020-rule federal EIC absent contrary input" },
  },
  {
    id: "okGrossHouseholdIncome",
    type: "money",
    min: "0",
    description:
      "Total GROSS household income of everyone in the household, taxable or not (Form 538-S Part 3 line 14: wages incl. nontaxable W-2 amounts, interest, dependents' income, full Social Security incl. Medicare, pensions, alimony, unemployment, EIC received, public assistance, child support, workers' comp, gross rents/business receipts; NOT deferred 401(k)/IRA contributions) — the $20,000/$50,000 sales tax relief limits (us.ok.sales_tax_relief_credit) and the $12,000 property tax relief limit (us.ok.property_tax_relief_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 gross household income absent contrary input" },
  },
  {
    id: "okStrExemptions",
    type: "int",
    min: "0",
    description:
      "Qualified exemptions for the sales tax relief credit (Form 538-S Box D: yourself, spouse, and each federally-claimed dependent who was an Oklahoma resident all year; a deceased taxpayer/spouse or a TANF recipient does not count) — $40 each (us.ok.sales_tax_relief_credit).",
    default: { value: "0", rationale: "Assumed no qualified exemptions absent contrary input" },
  },
  {
    id: "okStrHasDependent",
    type: "bool",
    description:
      "Filer can claim an exemption for a dependent — raises the sales tax relief gross household income limit from $20,000 to $50,000 (us.ok.sales_tax_relief_credit).",
    default: { value: false, rationale: "Assumed no dependent absent contrary input" },
  },
  {
    id: "okStrIs65",
    type: "bool",
    description:
      "Filer or spouse is 65 or older by December 31 of the tax year — raises the sales tax relief gross household income limit to $50,000 (us.ok.sales_tax_relief_credit).",
    default: { value: false, rationale: "Assumed under 65 absent contrary input" },
  },
  {
    id: "okStrDisabled",
    type: "bool",
    description:
      "Filer or spouse has a physical disability constituting a substantial handicap to employment (proof required with Form 538-S) — raises the sales tax relief gross household income limit to $50,000 (us.ok.sales_tax_relief_credit).",
    default: { value: false, rationale: "Assumed no qualifying disability absent contrary input" },
  },
  {
    id: "okStrEligible",
    type: "bool",
    description:
      "Filer meets the Form 538-S gates: Oklahoma resident (domiciled) for the ENTIRE year, not an inmate in DOC custody during the year after a felony conviction, received no TANF in any month, not living in Oklahoma under a visa, and the return is filed by the due date (us.ok.sales_tax_relief_credit). Unattested = $0.",
    default: { value: false, rationale: "Assumed NOT eligible absent an explicit attestation (conservative: no credit)" },
  },
  {
    id: "okPropertyTaxPaid",
    type: "money",
    min: "0",
    description:
      "Ad valorem property taxes paid on the homestead occupied during the year (Form 538-H) — the property tax relief credit is the amount paid, capped at $200 (us.ok.property_tax_relief_credit). In dollars.",
    default: { value: "0", rationale: "Assumed no property tax paid absent contrary input" },
  },
  {
    id: "okPtrEligible",
    type: "bool",
    description:
      "Filer is 65 or older OR totally disabled, is the head of a household, and was an Oklahoma resident domiciled in the state for the ENTIRE preceding calendar year (Form 538-H / Form 511 line 24) — the property tax relief credit also requires gross household income of $12,000 or less (us.ok.property_tax_relief_credit). Unattested = $0.",
    default: { value: false, rationale: "Assumed NOT eligible absent an explicit attestation (conservative: no credit)" },
  },
  // ---- Connecticut (Form CT-1040) ----
  {
    id: "ctAgi",
    type: "money",
    description:
      "Connecticut adjusted gross income (Form CT-1040 line 5 = federal AGI + Schedule 1 additions − subtractions) — the single key to the whole Tax Calculation Schedule: Table A exemption, Table B rates, the Table C 2% add-back, Table D recapture, and the Table E credit percentage (us.ct.income_tax, us.ct.personal_exemption), and to the property tax credit phase-out (us.ct.property_tax_credit). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 Connecticut AGI absent contrary input" },
  },
  {
    id: "ctUseTaxTable",
    type: "bool",
    description:
      "Use the DRS printed tax tables' method (Connecticut AGI at or under $102,000: the schedule evaluated at the $50 row midpoint, rounded once) instead of the Tax Calculation Schedule with its line-level whole-dollar rounding — Form CT-1040 line 6 allows either (us.ct.income_tax). Above $102,000 the schedule is used regardless.",
    default: { value: false, rationale: "The Tax Calculation Schedule (the statutory computation, valid at every income) is the default" },
  },
  {
    id: "ctPropertyTaxPaid",
    type: "money",
    min: "0",
    description:
      "Qualifying Connecticut property tax paid during the year on the primary residence and eligible motor vehicle(s) (Schedule 3 line 63: one vehicle for single/MFS/HOH, two for MFJ/QSS; bills due and paid in the year; no late payments, interest, or fees) — us.ct.property_tax_credit caps it at $300 and phases it out by Connecticut AGI. In dollars.",
    default: { value: "0", rationale: "Assumed no qualifying property tax paid absent contrary input" },
  },
  {
    id: "ctFederalEic",
    type: "money",
    min: "0",
    description:
      "Federal earned income credit claimed and allowed (Form 1040 line 27a; Schedule CT-EITC line 8) — us.ct.eitc pays 40% of it plus $250 with a qualifying child. In dollars.",
    default: { value: "0", rationale: "Assumed no federal EIC absent contrary input" },
  },
  {
    id: "ctEitcQualifyingChild",
    type: "bool",
    description:
      "Filer listed at least one qualifying child on federal Schedule EIC (Schedule CT-EITC lines 4-5) — adds the flat $250 (PA 25-168 § 371, TY2025+) to the Connecticut EITC (us.ct.eitc).",
    default: { value: false, rationale: "Assumed no qualifying child absent contrary input" },
  },
  {
    id: "ctEitcSeparateFagi",
    type: "money",
    description:
      "For a joint FEDERAL filer who must file married-filing-separately for Connecticut: this spouse's separate federal AGI (Schedule CT-EITC line 12) — the 40% credit is multiplied by separate ÷ joint federal AGI to four decimals, not more than 1.0000 (us.ct.eitc). Leave 0 (with ctEitcJointFagi 0) when no proration applies. In dollars.",
    default: { value: "0", rationale: "Assumed no separate-for-Connecticut proration absent contrary input" },
  },
  {
    id: "ctEitcJointFagi",
    type: "money",
    description:
      "The joint federal AGI (Form 1040 line 11; Schedule CT-EITC line 13) when the Connecticut return is married filing separately but the federal return was joint — the proration denominator (us.ct.eitc). 0 = no proration. In dollars.",
    default: { value: "0", rationale: "Assumed no separate-for-Connecticut proration absent contrary input" },
  },
  {
    id: "ctFederalAgi",
    type: "money",
    description:
      "Federal adjusted gross income (Form CT-1040 line 1 = federal Form 1040 line 11a, as the 2025 CT form prints it) — keys the Social Security adjustment thresholds ($75,000 single/MFS; $100,000 MFJ/QSS/HOH) and the pension/annuity/IRA phase-out (us.ct.social_security_adjustment, us.ct.pension_annuity_subtraction). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 federal AGI absent contrary input" },
  },
  {
    id: "ctSsTotalBenefits",
    type: "money",
    min: "0",
    description:
      "Total Social Security benefits received (federal Social Security Benefits Worksheet line 1 = Form SSA-1099 box 5 total) — line A of the Connecticut Social Security Benefit Adjustment Worksheet (us.ct.social_security_adjustment). In dollars.",
    default: { value: "0", rationale: "Assumed no Social Security benefits absent contrary input" },
  },
  {
    id: "ctSsProvisionalExcess",
    type: "money",
    description:
      "Federal Social Security Benefits Worksheet line 9 — the excess of provisional income over the § 86(c) base amount ($25,000 / $32,000) — or line 7 for a married-filing-separately filer who lived with the spouse (line B of the Connecticut worksheet; us.ct.social_security_adjustment). May be zero or negative (then no adjustment). In dollars.",
    default: { value: "0", rationale: "Assumed no provisional-income excess absent contrary input" },
  },
  {
    id: "ctTaxableSs",
    type: "money",
    min: "0",
    description:
      "Federally taxable Social Security benefits (Form 1040 line 6b; federal worksheet line 18) — line E of the Connecticut worksheet; fully subtracted below the AGI threshold (us.ct.social_security_adjustment). In dollars.",
    default: { value: "0", rationale: "Assumed no taxable Social Security absent contrary input" },
  },
  {
    id: "ctPensionAnnuityIncome",
    type: "money",
    min: "0",
    description:
      "Taxable pensions and annuities (Form 1040 line 5b) MINUS military retirement pay, Tier 1/Tier 2 Railroad Retirement, and Connecticut Teachers' Retirement income (each subtracted on its own Schedule 1 line) — the 100% component of the Pension and Annuity Worksheet line 2 (us.ct.pension_annuity_subtraction). Exclude disability pensions before minimum retirement age and corrective distributions. In dollars.",
    default: { value: "0", rationale: "Assumed no pension or annuity income absent contrary input" },
  },
  {
    id: "ctIraDistributions",
    type: "money",
    min: "0",
    description:
      "Taxable IRA distributions other than Roth (Form 1040 line 4b) — 75% enters the Pension and Annuity Worksheet line 2 for TY2025, 100% for TY2026 (us.ct.pension_annuity_subtraction). In dollars.",
    default: { value: "0", rationale: "Assumed no IRA distributions absent contrary input" },
  },
  // ---- Maine (Form 1040ME) ----
  {
    id: "meUseRateSchedule",
    type: "bool",
    description:
      "Compute Form 1040ME line 20 from the rate schedule at the exact income instead of the tax table (taxable income under $100,000 uses the table's $100-row midpoint by default) (us.me.income_tax).",
    default: { value: false, rationale: "The form directs filers to the tax table, so it is the default" },
  },
  {
    id: "meAgeBlindBoxes",
    type: "int",
    min: "0",
    max: "4",
    description:
      "Form 1040ME lines 12a-12d boxes checked (you 65+, you blind, spouse 65+, spouse blind) — $2,000 each for single/HOH, $1,600 each for MFJ/QSS/MFS (us.me.standard_deduction).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "meFederalItemizedDeductions",
    type: "money",
    min: "0",
    description:
      "Schedule 2 line 1: federal Schedule A line 17 (us.me.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meSaltTaxes5e",
    type: "money",
    min: "0",
    description:
      "Schedule 2 line 2a: taxes paid, federal Schedule A line 5e (us.me.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meExemptIncomeCosts",
    type: "money",
    min: "0",
    description:
      "Schedule 2 line 2b: deductible costs of producing Maine-exempt income included in the federal itemized total (us.me.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meFinancialInstitutionCosts",
    type: "money",
    min: "0",
    description:
      "Schedule 2 line 2c: itemized amounts attributable to a pass-through financial institution ownership interest (us.me.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meMedicalDeduction",
    type: "money",
    min: "0",
    description:
      "Schedule 2 line 2d: medical and dental expenses deducted, federal Schedule A line 4 — removed from the capped total and added back uncapped (us.me.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meMaineTaxableIncomeCosts",
    type: "money",
    min: "0",
    description:
      "Schedule 2 line 3a: deductible costs of producing income exempt federally but taxable by Maine (us.me.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meRealEstateTaxes5b",
    type: "money",
    min: "0",
    description:
      "Schedule 2 line 3b: state and local real estate taxes, federal Schedule A line 5b (us.me.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mePersonalPropertyTaxes5c",
    type: "money",
    min: "0",
    description:
      "Schedule 2 line 3c: personal property taxes, federal Schedule A line 5c (us.me.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meAgi",
    type: "money",
    description:
      "Maine adjusted gross income, Form 1040ME line 16 — the deduction and exemption phase-outs, dependent credit phase-out, other-jurisdiction ratio, and use tax estimate (us.me.deduction_phaseout, us.me.personal_exemption, us.me.dependent_exemption_credit, us.me.other_jurisdiction_credit, us.me.use_tax). May be negative. In dollars.",
  },
  {
    id: "meDeductionBeforePhaseout",
    type: "money",
    min: "0",
    description:
      "Form 1040ME line 17 worksheet line 6: the standard deduction from the chart or Schedule 2 line 7 itemized deductions, before the phase-out (us.me.deduction_phaseout). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meExemptions",
    type: "int",
    min: "0",
    max: "2",
    description:
      "Form 1040ME line 13: personal exemptions (0, 1, or 2) — $5,150 each (us.me.personal_exemption).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "meFederalAgi",
    type: "money",
    description:
      "Federal adjusted gross income, Form 1040ME line 14 — the pension deduction phase-out and the adult dependent care percentage (us.me.pension_deduction, us.me.adult_dependent_care_credit). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meNonMilitaryPension",
    type: "money",
    min: "0",
    description:
      "Pension Income Deduction Worksheet line P1 for one recipient: eligible non-military employee retirement plan and IRA benefits in federal AGI (us.me.pension_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meSocialSecurityReceived",
    type: "money",
    min: "0",
    description:
      "Pension Income Deduction Worksheet line P3: the recipient's total Social Security and railroad retirement benefits received, whether taxable or not (us.me.pension_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meMilitaryRetirement",
    type: "money",
    min: "0",
    description:
      "Pension Income Deduction Worksheet line P9: eligible military retirement pay in federal AGI — 100% deductible (us.me.pension_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meDependentsSixPlus",
    type: "int",
    min: "0",
    description:
      "Dependent Exemption Tax Credit Worksheet line 1: qualifying children and dependents (line 13a) at least 6 years old at any time in the year — $305 each (us.me.dependent_exemption_credit).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "meDependentsUnderSix",
    type: "int",
    min: "0",
    description:
      "Dependent Exemption Tax Credit Worksheet line 3: qualifying children and dependents under 6 at the end of the year — $610 each (us.me.dependent_exemption_credit).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "meFederalChildCareCredit",
    type: "money",
    min: "0",
    description:
      "Child Care Credit Worksheet line 2: the federal child and dependent care credit, Schedule 3 line 2 (us.me.child_care_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meChildCareExpenses",
    type: "money",
    min: "0",
    description:
      "Child Care Credit Worksheet line 1: total expenses on federal Form 2441 line 2 column (d) (us.me.child_care_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meStar5ChildCareExpenses",
    type: "money",
    min: "0",
    description:
      "Child Care Credit Worksheet line 1a column B: expenses paid to a Star 5 quality certificate provider — that share of the credit is 50% instead of 25% (us.me.child_care_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meAdultCareExpenses",
    type: "money",
    min: "0",
    description:
      "Adult Dependent Care Credit Worksheet line 1 column C: adult day care, hospice, and respite expenses not used for the federal credit (us.me.adult_dependent_care_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meAdultCareQualifyingIndividuals",
    type: "int",
    min: "0",
    description:
      "Adult Dependent Care Credit Worksheet: qualifying individuals (1 → $3,000 cap; 2 or more → $6,000) (us.me.adult_dependent_care_credit).",
    default: { value: "1", rationale: "Assumed one qualifying individual when expenses are given" },
  },
  {
    id: "meFederalEic",
    type: "money",
    min: "0",
    description:
      "Earned Income Tax Credit Worksheet line 1: federal EIC, Form 1040 line 27a (or the pro forma amount) (us.me.eitc). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meHasQualifyingChild",
    type: "bool",
    description:
      "Earned Income Tax Credit Worksheet: at least one qualifying child for the federal EIC — 25% instead of 50% (us.me.eitc).",
    default: { value: false, rationale: "Assumed no qualifying child unless stated" },
  },
  {
    id: "meTaxBeforeCredits",
    type: "money",
    min: "0",
    description:
      "Form 1040ME line 20 income tax (us.me.other_jurisdiction_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meOtherJurisdictionIncome",
    type: "money",
    min: "0",
    description:
      "Other Jurisdiction worksheet line 2d: income sourced to and taxed by the other jurisdiction, adjusted for Maine modifications (us.me.other_jurisdiction_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meOtherJurisdictionTax",
    type: "money",
    min: "0",
    description:
      "Other Jurisdiction worksheet line 4b: income tax paid to the other jurisdiction on that income (not withholding) (us.me.other_jurisdiction_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meTotalIncome",
    type: "money",
    description:
      "Schedule PTFC/STFC line 3: total income — federal total income plus nontaxable Social Security/railroad benefits, tax-exempt interest, and loss add-backs (us.me.property_tax_fairness_credit, us.me.sales_tax_fairness_credit). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mePropertyTaxPaid",
    type: "money",
    min: "0",
    description:
      "Schedule PTFC/STFC line 4: property tax paid on the Maine home in 2025 (up to 10 acres) (us.me.property_tax_fairness_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meRentPaid",
    type: "money",
    min: "0",
    description:
      "Schedule PTFC/STFC line 5a: rent paid on the Maine home in 2025 (us.me.property_tax_fairness_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meRentIncludesUtilities",
    type: "bool",
    description:
      "Schedule PTFC/STFC line 5b: the rent includes heat, utilities, furniture, or similar items (us.me.property_tax_fairness_credit).",
    default: { value: false, rationale: "Assumed rent excludes utilities" },
  },
  {
    id: "meUtilitiesAmount",
    type: "money",
    min: "0",
    description:
      "Schedule PTFC/STFC line 5c: the known amount of heat, utilities, furniture, or similar items in the rent; $0 with meRentIncludesUtilities means unknown → 15% of the rent (us.me.property_tax_fairness_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meAge65",
    type: "bool",
    description:
      "Schedule PTFC/STFC line 7: you or your spouse (MFJ) were at least 65 during the tax year — $4,100 benefit base and $2,000 cap (us.me.property_tax_fairness_credit).",
    default: { value: false, rationale: "Assumed under 65" },
  },
  {
    id: "meDisabledVeteran",
    type: "bool",
    description:
      "Schedule PTFC/STFC line 14: you or your spouse are rated 100% permanently and totally disabled by the VA — the credit doubles (us.me.property_tax_fairness_credit).",
    default: { value: false, rationale: "Assumed not a disabled veteran" },
  },
  {
    id: "meDependents13a",
    type: "int",
    min: "0",
    description:
      "Form 1040ME line 13a: qualifying children and dependents for the federal child tax credit or credit for other dependents (us.me.property_tax_fairness_credit, us.me.sales_tax_fairness_credit).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "meUseTaxPurchases",
    type: "money",
    min: "0",
    description:
      "Form 1040ME line 30: purchases for use in Maine on which no sales tax was paid — 5.5% (us.me.use_tax). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "meUseTaxEstimate",
    type: "bool",
    description:
      "Form 1040ME line 30: use the 0.04% of Maine AGI estimate for unknown untaxed purchases (us.me.use_tax).",
    default: { value: false, rationale: "Assumed exact purchases are reported" },
  },
  // ---- Hawaii (Form N-11) ----
  {
    id: "hiUseRateSchedule",
    type: "bool",
    description:
      "Compute Form N-11 line 27 from the Tax Rate Schedules at the exact income instead of the Tax Table (taxable income under $100,000 uses the table's $50-row midpoint by default; $100,000 or more always uses the schedules) (us.hi.income_tax, us.hi.capital_gains_tax, us.hi.other_state_credit).",
    default: { value: false, rationale: "The line 27 instruction directs filers under $100,000 to the Tax Table" },
  },
  {
    id: "hiNetLongTermCapitalGain",
    type: "money",
    description:
      "Tax on Capital Gains Worksheet line 4: Hawaii net long-term capital gain (federal Schedule D line 15 plus Hawaii long-term adjustments) (us.hi.capital_gains_tax). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed no long-term capital gain absent contrary input" },
  },
  {
    id: "hiNetCapitalGain",
    type: "money",
    description:
      "Tax on Capital Gains Worksheet line 7: Hawaii net capital gain (federal Schedule D line 16 plus Hawaii adjustments) (us.hi.capital_gains_tax). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed no net capital gain absent contrary input" },
  },
  {
    id: "hiInvestmentInterestN158",
    type: "money",
    min: "0",
    description:
      "Tax on Capital Gains Worksheet line 9: Form N-158 line 4e — net capital gain elected as investment income (us.hi.capital_gains_tax). In dollars.",
    default: { value: "0", rationale: "Assumed no Form N-158 election absent contrary input" },
  },
  {
    id: "hiCapitalGainsStatutoryThreshold",
    type: "bool",
    description:
      "Tax on Capital Gains Worksheet line 12: use HRS § 235-51(f)(1)(B)'s 'taxable income taxed at a rate below 7.25 per cent' under the 2025 brackets ($48,000 single/MFS, $72,000 HOH, $96,000 MFJ/QSS) instead of the printed $24,000 / $36,000 / $48,000 (us.hi.capital_gains_tax).",
    default: { value: false, rationale: "The printed 2025 worksheet amounts are the default; the statutory amounts are an election to disclose" },
  },
  {
    id: "hiEarnedIncome",
    type: "money",
    min: "0",
    description:
      "Earned income (wages, salaries, tips, professional fees, taxable scholarships, net business and farm income less the SE tax deduction) — the dependent-filer standard deduction (us.hi.standard_deduction) and Schedule X line 23 (us.hi.child_dependent_care_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiAgi",
    type: "money",
    description:
      "Hawaii adjusted gross income, Form N-11 line 20 — the medical, casualty, and miscellaneous floors and the overall limitation (us.hi.itemized_deductions), the renters credit AGI test (us.hi.renters_credit), and the child care percentage (us.hi.child_dependent_care_credit). May be negative. In dollars.",
  },
  {
    id: "hiFederalAgi",
    type: "money",
    description:
      "Federal adjusted gross income, Form N-11 line 7 — the state income/sales tax deduction gate (us.hi.itemized_deductions) and the food/excise credit table (us.hi.food_excise_credit). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiMedicalExpenses",
    type: "money",
    min: "0",
    description: "Worksheet A-1 line 1: medical and dental expenses before the 7.5% floor (us.hi.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiStateLocalIncomeTaxes",
    type: "money",
    min: "0",
    description:
      "Worksheet A-2 line 5: state and local income taxes (or the elected general sales taxes) — allowed only when federal AGI is under $100,000 single/MFS, $150,000 HOH, $200,000 MFJ/QSS; exclude amounts claimed under the other-state credit (us.hi.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiRealEstateTaxes",
    type: "money",
    min: "0",
    description: "Worksheet A-2 line 6: real estate taxes (no foreign real property taxes) (us.hi.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiPersonalPropertyTaxes",
    type: "money",
    min: "0",
    description: "Worksheet A-2 line 7: personal property taxes paid to other states (us.hi.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiOtherTaxes",
    type: "money",
    min: "0",
    description: "Worksheet A-2 line 8: other deductible taxes (us.hi.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiHomeMortgageInterest",
    type: "money",
    min: "0",
    description: "Worksheet A-3 lines 10-12: home mortgage interest and points (pre-TCJA limits) (us.hi.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiInvestmentInterest",
    type: "money",
    min: "0",
    description: "Worksheet A-3 line 13: investment interest from Form N-158 — protected from the overall limitation (us.hi.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiCharitableContributions",
    type: "money",
    min: "0",
    description: "Worksheet A-4 line 18: gifts to charity (cash, other, carryover) within the AGI limits (us.hi.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiCasualtyLosses",
    type: "money",
    min: "0",
    description: "Worksheet A-5 line 19: casualty and theft losses after the $100-per-casualty reduction, before the 10% floor (us.hi.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiJobAndMiscExpenses",
    type: "money",
    min: "0",
    description: "Worksheet A-6 line 26: unreimbursed employee business expenses, tax preparation fees, and other expenses subject to the 2% floor (us.hi.itemized_deductions; ignored for TY2026). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiOtherMiscDeductions",
    type: "money",
    min: "0",
    description: "Worksheet A-6 line 30: other deductions not subject to the 2% limit (gambling losses to the extent of winnings, impairment-related work expenses) (us.hi.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiGamblingLossesInMisc",
    type: "money",
    min: "0",
    description: "Total Itemized Deductions Worksheet line 2d: gambling and casualty or theft losses included in Worksheet A-6 line 30 — protected from the overall limitation (us.hi.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiExemptions",
    type: "int",
    min: "0",
    description:
      "Form N-11 line 6e: total exemptions (yourself, spouse, dependents, plus one more for each taxpayer or spouse 65 or older) — $1,144 each (us.hi.personal_exemption).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "hiDisabledPersons",
    type: "int",
    min: "0",
    max: "2",
    description:
      "Form N-11 line 25 ovals: taxpayers (you and/or your spouse) claiming the $7,000 blind, deaf, or totally disabled exemption in lieu of all regular exemptions (Form N-172 certified) (us.hi.personal_exemption).",
    default: { value: "0", rationale: "Assumed no disability exemption absent contrary input" },
  },
  {
    id: "hiNonDisabledSpouseAge65",
    type: "bool",
    description:
      "With one disabled spouse on a joint return, the non-disabled spouse is 65 or older — $9,288 instead of $8,144 (us.hi.personal_exemption).",
    default: { value: false, rationale: "Assumed the non-disabled spouse is under 65" },
  },
  {
    id: "hiReservePay",
    type: "money",
    min: "0",
    description: "Form N-11 line 15: the taxpayer's military reserve or Hawaii National Guard duty pay (W-2 Box 16 from the reserve component) — the first $8,636 is excluded (us.hi.reserve_pay_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed no reserve pay absent contrary input" },
  },
  {
    id: "hiSpouseReservePay",
    type: "money",
    min: "0",
    description: "Form N-11 line 15: the spouse's reserve or National Guard duty pay on a joint return (us.hi.reserve_pay_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed no spouse reserve pay absent contrary input" },
  },
  {
    id: "hiSpouseFederalAgi",
    type: "money",
    description: "Form N-311 line 5: the spouse's federal AGI, added for married filing separately (us.hi.food_excise_credit). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiFoodExciseQualifiedExemptions",
    type: "int",
    min: "0",
    description:
      "Form N-311 line 8: qualified exemptions — yourself, spouse, and dependents present in Hawaii more than nine months and not claimable by another (not the extra age-65 exemption), plus minor children supported by public agencies (us.hi.food_excise_credit).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input — the nine-month presence test is an attestation" },
  },
  {
    id: "hiSpouseAgi",
    type: "money",
    description: "Schedule X Part I: the spouse's Hawaii adjusted gross income, added for married filing separately (us.hi.renters_credit). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiRentPaid",
    type: "money",
    min: "0",
    description:
      "Schedule X line 7: rent paid in 2025 for the Hawaii residence (not exempt from real property tax) net of utilities, parking, ground rent, and subsidies — must exceed $1,000 (us.hi.renters_credit). In dollars.",
    default: { value: "0", rationale: "Assumed no rent paid absent contrary input" },
  },
  {
    id: "hiRentersExemptions",
    type: "int",
    min: "0",
    description:
      "Schedule X line 11: qualified exemptions (yourself, spouse, dependents present more than nine months and not claimable by another) plus one more for you and one for your spouse if 65 or older — $50 each (us.hi.renters_credit).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input — the nine-month presence test is an attestation" },
  },
  {
    id: "hiChildCareExpenses",
    type: "money",
    min: "0",
    description: "Schedule X line 20/22: qualified child and dependent care expenses paid in 2025 (before the $10,000 / $20,000 cap) (us.hi.child_dependent_care_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiChildCareQualifyingPersons",
    type: "int",
    min: "0",
    description: "Schedule X line 17: qualifying persons (1 → $10,000 cap; 2 or more → $20,000) (us.hi.child_dependent_care_credit).",
    default: { value: "1", rationale: "Assumed one qualifying person when expenses are given" },
  },
  {
    id: "hiDependentCareBenefits",
    type: "money",
    min: "0",
    description: "Schedule X line 18: deductible and excluded dependent care benefits (lines 14 + 15) that reduce the expense cap (us.hi.child_dependent_care_credit). In dollars.",
    default: { value: "0", rationale: "Assumed no dependent care benefits absent contrary input" },
  },
  {
    id: "hiSpouseEarnedIncome",
    type: "money",
    min: "0",
    description: "Schedule X line 24: the spouse's earned income on a joint return (or the $200 / $400 monthly deemed amount for a student or disabled spouse) (us.hi.child_dependent_care_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiMfsConsideredUnmarried",
    type: "bool",
    description:
      "Schedule X Part II checkbox: a married-filing-separately filer who lived apart from the spouse the last six months, kept the qualifying person's home, and paid over half its cost (us.hi.child_dependent_care_credit).",
    default: { value: false, rationale: "MFS filers are married for the credit unless attested" },
  },
  {
    id: "hiFederalEic",
    type: "money",
    min: "0",
    description: "Form N-356 line 2: the federal earned income credit claimed on the federal return (Form 1040 line 27a) — 40% (us.hi.eitc). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiNetCapitalGainLine27a",
    type: "money",
    min: "0",
    description: "Other State and Foreign Tax Credit Worksheet line 2: the net capital gain beside Form N-11 line 27a (us.hi.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiOutOfStateIncome",
    type: "money",
    min: "0",
    description: "Other State and Foreign Tax Credit Worksheet line 3: out-of-state income including capital gains, excluding Hawaii-exempt income (us.hi.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiOutOfStateLtcg",
    type: "money",
    min: "0",
    description: "Other State and Foreign Tax Credit Worksheet line 4: long-term capital gains from sources outside Hawaii (us.hi.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiOtherStateTaxEligible",
    type: "money",
    min: "0",
    description: "Other State and Foreign Tax Credit Worksheet line 9: tax paid to other states plus foreign tax not credited federally (us.hi.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiTaxLine13",
    type: "money",
    min: "0",
    description: "Other State and Foreign Tax Credit Worksheet line 13: the Form N-11 line 27 tax from the table, schedule, or capital gains worksheet (us.hi.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "hiAdjustedTaxLiability",
    type: "money",
    description: "Other State and Foreign Tax Credit Worksheet line 19: Form N-11 line 34 adjusted tax liability (us.hi.other_state_credit). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  // ---- Rhode Island (Form RI-1040) ----
  {
    id: "riUseRateSchedule",
    type: "bool",
    description:
      "Compute Form RI-1040 line 8 with the Tax Computation Worksheet arithmetic at the exact income instead of the Tax Table (taxable income under $100,000 uses the table's $50-row midpoint by default; $100,000 or more always uses the worksheet) (us.ri.income_tax).",
    default: { value: false, rationale: "The line 8 instruction directs filers under $100,000 to the Tax Table" },
  },
  {
    id: "riModifiedAgi",
    type: "money",
    description:
      "Modified federal adjusted gross income, Form RI-1040 line 3 (federal AGI plus RI Schedule M net modifications) — the standard deduction and exemption phase-outs (us.ri.standard_deduction, us.ri.exemption) and the other-state credit ratio (us.ri.other_state_credit). May be negative. In dollars.",
  },
  {
    id: "riExemptions",
    type: "int",
    min: "0",
    description:
      "RI Schedule E line 5: total exemptions — yourself (unless claimable by another), your spouse on a joint return, and dependents — $5,100 each (us.ri.exemption).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "riFederalAgi",
    type: "money",
    description:
      "Federal adjusted gross income, Form RI-1040 line 1 — the Social Security and pension modification income tests and the use tax lookup table (us.ri.social_security_modification, us.ri.pension_modification, us.ri.use_tax). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "riTaxpayerFullRetirementAge",
    type: "bool",
    description:
      "The taxpayer has reached Social Security full retirement age — born on or before March 1, 1959 for 2025 (Social Security Worksheet line 5; Schedule M line 1t question 1) (us.ri.social_security_modification, us.ri.pension_modification).",
    default: { value: false, rationale: "Assumed under full retirement age unless stated" },
  },
  {
    id: "riSpouseFullRetirementAge",
    type: "bool",
    description:
      "The spouse has reached Social Security full retirement age — born on or before March 1, 1959 for 2025 (joint returns) (us.ri.social_security_modification, us.ri.pension_modification).",
    default: { value: false, rationale: "Assumed under full retirement age unless stated" },
  },
  {
    id: "riSocialSecurityBenefits",
    type: "money",
    min: "0",
    description: "Social Security Worksheet line 8: total Social Security benefits, Form 1040 line 6a (us.ri.social_security_modification). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "riSocialSecurityBenefitsFraPerson",
    type: "money",
    min: "0",
    description:
      "Social Security Worksheet line 9: the part of line 8 attributed to the spouse who has reached full retirement age when only one spouse has (us.ri.social_security_modification). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "riTaxableSocialSecurity",
    type: "money",
    min: "0",
    description: "Social Security Worksheet line 11: taxable Social Security, Form 1040 line 6b (us.ri.social_security_modification). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "riTaxpayerPensionIncome",
    type: "money",
    min: "0",
    description:
      "Schedule M line 1t table line 2 column (a): the taxpayer's federally taxable pension and annuity income (Form 1040 line 5b), not IRA distributions or military service pensions (us.ri.pension_modification). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "riSpousePensionIncome",
    type: "money",
    min: "0",
    description: "Schedule M line 1t table line 2 column (b): the spouse's taxable pension and annuity income on a joint return (us.ri.pension_modification). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "riFederalChildCareCredit",
    type: "money",
    min: "0",
    description: "RI Schedule I line 20: the federal child and dependent care credit, Schedule 3 line 2 — 25% (us.ri.child_dependent_care_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "riIncomeTax",
    type: "money",
    min: "0",
    description: "RI Schedule I line 19: Form RI-1040 line 8 income tax — the cap on the child care credit (us.ri.child_dependent_care_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "riIncomeTaxAfterFederalCredit",
    type: "money",
    min: "0",
    description: "RI Schedule II line 23: line 8 income tax less the Schedule I line 22 credit (us.ri.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "riOtherStateIncome",
    type: "money",
    min: "0",
    description: "RI Schedule II line 24: income derived from the other state (Form RI-1040MU line 29 for several states) (us.ri.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "riOtherStateTaxPaid",
    type: "money",
    min: "0",
    description: "RI Schedule II line 28: income tax due and paid to the other state (not withholding; $0 if fully refunded) (us.ri.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "riFederalEic",
    type: "money",
    min: "0",
    description: "RI Schedule EIC line 39: the federal earned income credit, Form 1040 line 27a — 16% (us.ri.eitc). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "riHouseholdIncome",
    type: "money",
    description: "Form RI-1040H line 32: total 2025 household income of every household member, taxable and nontaxable, with losses added back (us.ri.property_tax_relief_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "riHouseholdMembers",
    type: "int",
    min: "1",
    description: "Form RI-1040H line 1f: persons in the household — the '1 person' or '2 or more' percentage column (us.ri.property_tax_relief_credit).",
    default: { value: "1", rationale: "Assumed a one-person household absent contrary input" },
  },
  {
    id: "riAge65OrDisabled",
    type: "bool",
    description:
      "Form RI-1040H Part 1 question D: you or your spouse were 65 or older, or receiving Social Security disability benefits, as of December 31, 2025 — plus domicile for the whole year and current taxes/rent (us.ri.property_tax_relief_credit).",
    default: { value: false, rationale: "Eligibility is an attestation; absent it the credit is $0" },
  },
  {
    id: "riPropertyTaxPaid",
    type: "money",
    min: "0",
    description: "Form RI-1040H line 2: property taxes paid or payable for 2025 on the homestead (the owner's share) (us.ri.property_tax_relief_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "riRentPaid",
    type: "money",
    min: "0",
    description: "Form RI-1040H line 7: rent paid in 2025 for occupancy only (net of utilities and furnishings), also rented land under a taxed home — 20% counts as property tax (us.ri.property_tax_relief_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "riUseTaxLookupTable",
    type: "bool",
    description: "RI Schedule U Option #2: use the safe-harbor lookup table on federal AGI instead of actual purchases (us.ri.use_tax).",
    default: { value: false, rationale: "Actual purchases (Option #1) unless the lookup table is elected" },
  },
  {
    id: "riUseTaxPurchases",
    type: "money",
    min: "0",
    description: "RI Schedule U line 1: total price of purchases subject to use tax — 7% (us.ri.use_tax). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "riSalesTaxPaidOtherStates",
    type: "money",
    min: "0",
    description: "RI Schedule U line 3: sales taxes paid in other states on the line 1 purchases (us.ri.use_tax). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "riLargePurchasesNetUseTax",
    type: "money",
    min: "0",
    description: "RI Schedule U line 7e: net use tax due on single purchases of $1,000 or more (7% less sales tax paid) added to the lookup amount (us.ri.use_tax). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  // ---- West Virginia (Form IT-140) ----
  {
    id: "wvUseRateSchedule",
    type: "bool",
    description:
      "Compute Form IT-140 line 8 from the Rate Schedule at the exact income instead of the printed Tax Table (statuses 1, 2, 3, 5 under $100,000 use the table by instruction; MFS and $100,000+ always use the schedule) (us.wv.income_tax).",
    default: { value: false, rationale: "The line 8 instruction directs table users to the Tax Table" },
  },
  {
    id: "wvExemptions",
    type: "int",
    min: "0",
    description:
      "Form IT-140 exemption box (e): yourself (unless claimable as a dependent), spouse (MFJ), dependents, and the surviving-spouse extra exemption — $2,000 each; $500 when zero (us.wv.exemption_deduction).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "wvAgi",
    type: "money",
    description:
      "Federal adjusted gross income, Form IT-140 line 1 — the low-income exclusion and Social Security thresholds, and HEPTC-1 line 4 gross household income (us.wv.low_income_exclusion, us.wv.social_security_modification, us.wv.homestead_excess_property_tax_credit); the SCTC/HEPTC poverty tests use wvHouseholdIncome. May be negative. In dollars.",
  },
  {
    id: "wvEarnedIncome",
    type: "money",
    min: "0",
    description:
      "Low-income exclusion worksheet line B: wages, salaries, tips, other employee compensation, and net self-employment earnings (us.wv.low_income_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvTaxableSocialSecurity",
    type: "money",
    min: "0",
    description:
      "Schedule M line 34(c): Social Security benefits taxable federally (Form 1040 line 6b) for the column (us.wv.social_security_modification). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvSeniorOrDisabled",
    type: "bool",
    description:
      "The person for this Schedule M column is 65 or older on December 31 or certified permanently and totally disabled (us.wv.senior_citizen_modification).",
    default: { value: false, rationale: "Eligibility must be affirmed; assumed not met" },
  },
  {
    id: "wvIncomeNotOnLines35to46",
    type: "money",
    min: "0",
    description:
      "Schedule M line 47 box (c): the person's income not reported on lines 35 through 46 (the rule caps it at $8,000) (us.wv.senior_citizen_modification). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvLines29to34",
    type: "money",
    min: "0",
    description:
      "Schedule M line 47 box (d): the person's lines 29 through 34 subtractions (obligation interest, law enforcement / police / fire / military retirement, the $2,000 PERS-TRS-federal modification, Social Security); for line 48 (us.wv.surviving_spouse_modification) pass lines 29-34 PLUS the line 47 modification, since the two together may not exceed $8,000. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvSurvivingSpouseEligible",
    type: "bool",
    description:
      "Schedule M line 48: the filer is the unremarried surviving spouse of a decedent who was 65 or disabled, in the taxable year following the death (us.wv.surviving_spouse_modification).",
    default: { value: false, rationale: "Eligibility must be affirmed; assumed not met" },
  },
  {
    id: "wvFamilySize",
    type: "int",
    min: "0",
    description:
      "Schedule FTC-1 line 5: exemptions in boxes (a), (b), and (c) — the family size (0 → no credit; over 8 uses the size-8 column) (us.wv.family_tax_credit).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "wvModifiedAgi",
    type: "money",
    description:
      "Schedule FTC-1 line 4: federal AGI + increasing modifications + federal tax-exempt interest (us.wv.family_tax_credit). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvTaxBeforeCredits",
    type: "money",
    min: "0",
    description:
      "Form IT-140 line 8 income tax (us.wv.family_tax_credit, us.wv.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvFederalAmt",
    type: "bool",
    description:
      "The filer paid federal alternative minimum tax — disqualifies the Family Tax Credit, SCTC, and HEPTC (us.wv.family_tax_credit, us.wv.senior_citizens_tax_credit, us.wv.homestead_excess_property_tax_credit).",
    default: { value: false, rationale: "Assumed no federal AMT" },
  },
  {
    id: "wvOtherStateTax",
    type: "money",
    min: "0",
    description:
      "Schedule E line 1: income tax computed on the other state's 2025 return (not withholding) (us.wv.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvOtherStateIncome",
    type: "money",
    min: "0",
    description:
      "Schedule E line 3: net income derived from the other state included in West Virginia total income (us.wv.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvAdjustedGrossIncome",
    type: "money",
    description:
      "Schedule E line 4: West Virginia adjusted gross income, Form IT-140 line 4 (us.wv.other_state_credit). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvAlternativeTax",
    type: "money",
    min: "0",
    description:
      "Schedule E line 7: the Rate Schedule tax on West Virginia taxable income minus the other-state income (line 6) (us.wv.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvOtherRecapCredits",
    type: "money",
    min: "0",
    description:
      "Schedule E line 9: the sum of Tax Credit Recap lines 2 through 26 (Family Tax Credit, child care, business credits) (us.wv.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvFederalChildCareCredit",
    type: "money",
    min: "0",
    description:
      "Federal child and dependent care credit, Form 2441 — West Virginia allows 50% (us.wv.child_care_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvHouseholdSize",
    type: "int",
    min: "0",
    description:
      "Number of people living in the household — the SCTC (150% of poverty) and HEPTC (300%) income limits (us.wv.senior_citizens_tax_credit, us.wv.homestead_excess_property_tax_credit).",
    default: { value: "1", rationale: "Assumed a one-person household" },
  },
  {
    id: "wvHouseholdIncome",
    type: "money",
    description:
      "Federal AGI (or income less Social Security when not required to file federally) tested against the SCTC / HEPTC poverty-guideline limits (us.wv.senior_citizens_tax_credit, us.wv.homestead_excess_property_tax_credit). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvDisabledVeteranCreditClaimed",
    type: "bool",
    description:
      "The Disabled Veteran real property tax credit (line 21B) is claimed — bars the SCTC and HEPTC (us.wv.senior_citizens_tax_credit, us.wv.homestead_excess_property_tax_credit).",
    default: { value: false, rationale: "Assumed not claimed" },
  },
  {
    id: "wvSeniorCitizenCreditAmount",
    type: "money",
    min: "0",
    description:
      "Schedule SCTC-A Part III line 2: the Senior Citizens Tax Credit computed on the Tax Division's mailed form (property tax on up to the first $20,000 of taxable assessed value) (us.wv.senior_citizens_tax_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvPropertyTaxPaid",
    type: "money",
    min: "0",
    description:
      "Schedule HEPTC-1 line 1: West Virginia property tax paid on the owner-occupied home in 2025, after discount and before interest (us.wv.homestead_excess_property_tax_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvSeniorCitizenCredit",
    type: "money",
    min: "0",
    description:
      "Schedule HEPTC-1 line 2: the allowable Senior Citizens Tax Credit (subtracted from the property tax) (us.wv.homestead_excess_property_tax_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvAdditions",
    type: "money",
    min: "0",
    description:
      "Schedule HEPTC-1 line 4a: increasing modifications, Schedule M line 59 (us.wv.homestead_excess_property_tax_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvTaxExemptInterest",
    type: "money",
    min: "0",
    description:
      "Schedule HEPTC-1 line 4b: federal tax-exempt interest (us.wv.homestead_excess_property_tax_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvWorkersCompensation",
    type: "money",
    min: "0",
    description:
      "Schedule HEPTC-1 line 4c: earnings replacement insurance (workers' compensation) received (us.wv.homestead_excess_property_tax_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvNontaxableSocialSecurity",
    type: "money",
    min: "0",
    description:
      "Schedule HEPTC-1 line 4d: Social Security, SSI, and SSDI received but not in federal AGI (us.wv.homestead_excess_property_tax_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvOtherHouseholdIncome",
    type: "money",
    min: "0",
    description:
      "Schedule HEPTC-1 line 4e: income of other household members who would file separately (us.wv.homestead_excess_property_tax_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvUseTaxPurchases",
    type: "money",
    min: "0",
    description:
      "Schedule UT line 1: purchases subject to the 6% state use tax on which no sales tax was paid (us.wv.use_tax). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvMunicipalUseTaxPurchases",
    type: "money",
    min: "0",
    description:
      "Schedule UT Part II: purchases used in a municipality that imposes a municipal use tax (us.wv.use_tax). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "wvMunicipalUseTaxRateBps",
    type: "int",
    min: "0",
    max: "100",
    description:
      "Schedule UT Part II tax rate in basis points (50 for 0.5%, 100 for 1%) (us.wv.use_tax).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  // ---- Idaho (Form 40) ----
  {
    id: "idAgeBlindBoxes",
    type: "int",
    min: "0",
    max: "4",
    description:
      "Form 40 lines 12a-12b boxes checked (you 65+, you blind, spouse 65+, spouse blind; must match the federal return) — $2,000 each for single/HOH, $1,600 each for MFJ/QSS/MFS (us.id.standard_deduction).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "idEarnedIncome",
    type: "money",
    min: "0",
    description:
      "Earned income (wages, salaries, tips, professional fees, taxable scholarships) — the dependent-filer standard deduction (us.id.standard_deduction) and the Form 39R child care worksheet line 5 (us.id.child_care_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idSpouseEarnedIncome",
    type: "money",
    min: "0",
    description:
      "Spouse's earned income on a joint return — Form 39R child care worksheet line 6 (us.id.child_care_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idFederalItemizedDeductions",
    type: "money",
    min: "0",
    description:
      "Form 40 line 13: total federal itemized deductions, Schedule A line 17 (us.id.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idForeignTaxCredit",
    type: "money",
    min: "0",
    description:
      "Federal foreign tax credit claimed — Idaho allows it as an addition to itemized deductions (us.id.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idSaltIncomeOrSalesTaxes",
    type: "money",
    min: "0",
    description:
      "Federal Schedule A line 5a: state and local income taxes or general sales taxes (us.id.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idRealEstateTaxes",
    type: "money",
    min: "0",
    description:
      "Federal Schedule A line 5b: state and local real estate taxes (us.id.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idPersonalPropertyTaxes",
    type: "money",
    min: "0",
    description:
      "Federal Schedule A line 5c: state and local personal property taxes (us.id.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idSaltAllowed",
    type: "money",
    min: "0",
    description:
      "Federal Schedule A line 5e: state and local taxes allowed after the federal cap — used when line 5d exceeds $40,000 ($20,000 MFS) (us.id.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idQualifyingChildren",
    type: "int",
    min: "0",
    description:
      "Form 40 line 24 worksheet line 1: qualifying children (IRC § 24(c)) age 16 or under on December 31 — $205 each (us.id.child_tax_credit).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "idTaxBeforeCredits",
    type: "money",
    min: "0",
    description:
      "Form 40 line 20 Idaho income tax — the base for the credit limits (us.id.child_tax_credit, us.id.other_state_credit, us.id.educational_contribution_credit, us.id.youth_rehab_contribution_credit, us.id.live_organ_donation_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idOtherStateCredit",
    type: "money",
    min: "0",
    description:
      "Form 40 line 21 credit for income tax paid to other states — reduces the tax available for the Part D and child tax credits. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idEducationalCredit",
    type: "money",
    min: "0",
    description:
      "Form 39R Part D line 1 educational entity credit already allowed — reduces the tax available for the youth/rehab and live organ credits. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idYouthCredit",
    type: "money",
    min: "0",
    description:
      "Form 39R Part D line 2 youth and rehabilitation facility credit already allowed — reduces the tax available for the live organ donation credit. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idInvestmentTaxCredit",
    type: "money",
    min: "0",
    description:
      "Form 44 Part I line 1: Idaho investment tax credit (Form 49) — the only Form 44 line that reduces the tax available for the youth/rehabilitation facility credit (us.id.youth_rehab_contribution_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idContributionCredits",
    type: "money",
    min: "0",
    description:
      "Form 40 line 22: total Form 39R Part D credits — reduces the tax available for the child tax credit (us.id.child_tax_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idBusinessCredits",
    type: "money",
    min: "0",
    description:
      "Form 40 line 23 / Form 44 Part I: business income tax credits — reduce the tax available for the Part D and child tax credits. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idFoodCreditPersons",
    type: "int",
    min: "0",
    description:
      "Food Tax Credit worksheet: household members (you, spouse, resident dependents) qualified for all twelve months — $155 each (us.id.food_tax_credit).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "idFoodCreditPartialMonths",
    type: "int",
    min: "0",
    description:
      "Food Tax Credit worksheet: total qualified months across household members qualified for only part of the year — $12.92 each (us.id.food_tax_credit).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "idOtherStateIncome",
    type: "money",
    min: "0",
    description:
      "Form 39R Part C line 2: federal AGI earned in the other state and taxed by both states, adjusted for Idaho modifications (us.id.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idAdjustedIncome",
    type: "money",
    description:
      "Form 39R Part C line 3: Idaho adjusted income, Form 40 line 11 (us.id.other_state_credit). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idOtherStateTaxDue",
    type: "money",
    min: "0",
    description:
      "Form 39R Part C line 6: the other state's tax due from its table or schedule minus its income tax credits (not SALT workaround payments) (us.id.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idEducationalContributions",
    type: "money",
    min: "0",
    description:
      "Form 39R Part D line 1: cash contributed to qualified Idaho educational entities (us.id.educational_contribution_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idYouthContributions",
    type: "money",
    min: "0",
    description:
      "Form 39R Part D line 2: cash or goods contributed to Idaho youth and rehabilitation facilities, centers for independent living, or licensed substance abuse centers (us.id.youth_rehab_contribution_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idOrganDonationExpenses",
    type: "money",
    min: "0",
    description:
      "Form 39R Part D line 3: unreimbursed travel, lodging, and lost wages for a live organ donation (us.id.live_organ_donation_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idRetirementEligible",
    type: "bool",
    description:
      "The filer (or spouse) meets the § 63-3022A age/disability test — 65, or 62 and disabled; military retirees: disabled, 62, or employed with income requiring a federal return (us.id.retirement_benefits_deduction).",
    default: { value: false, rationale: "Eligibility must be affirmed; assumed not met" },
  },
  {
    id: "idRailroadBenefits",
    type: "money",
    min: "0",
    description:
      "Form 39R line 8b: federal Railroad Retirement benefits received (RRB-1099 Box 5 net SSEB, RRB-1099-R Box 7 less Box 8) (us.id.retirement_benefits_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idSocialSecurityBenefits",
    type: "money",
    min: "0",
    description:
      "Form 39R line 8c: Social Security benefits received, SSA-1099 Box 5 (gross, not the taxable portion) (us.id.retirement_benefits_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idQualifyingRetirementBenefits",
    type: "money",
    min: "0",
    description:
      "Form 39R line 8e: qualifying CSRS/FSRDS, Idaho firefighter, Idaho city police, or military retirement benefits included in federal income (us.id.retirement_benefits_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idChildCareExpenses",
    type: "money",
    min: "0",
    description:
      "Form 39R child care worksheet line 1: qualified expenses paid, excluding employer-paid or excluded amounts (us.id.child_care_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idDependentCareBenefitsExcluded",
    type: "money",
    min: "0",
    description:
      "Form 39R child care worksheet line 3: excluded dependent care benefits from federal Form 2441 Part III (us.id.child_care_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idItemizingForIdaho",
    type: "bool",
    description:
      "The filer uses itemized deductions on Form 40 line 17 (line 15 exceeds line 16) — the health and long-term care worksheets then allocate the federal medical deduction (us.id.health_insurance_deduction, us.id.long_term_care_deduction).",
    default: { value: false, rationale: "Assumed the standard deduction absent contrary input" },
  },
  {
    id: "idSchAHealthPremiums",
    type: "money",
    min: "0",
    description:
      "Health/LTC worksheet line 1: health insurance premiums claimed on federal Schedule A (us.id.health_insurance_deduction, us.id.long_term_care_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idSchALtcPremiums",
    type: "money",
    min: "0",
    description:
      "Health/LTC worksheet line 2: long-term care premiums claimed on federal Schedule A. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idSchAOtherMedical",
    type: "money",
    min: "0",
    description:
      "Health/LTC worksheet line 3: other medical expenses claimed on federal Schedule A. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idAgi",
    type: "money",
    description:
      "Federal adjusted gross income, Form 40 line 7 — the 7.5% medical floor in the health/LTC worksheets (us.id.health_insurance_deduction, us.id.long_term_care_deduction). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idHealthPremiumsPaid",
    type: "money",
    min: "0",
    description:
      "Health/LTC worksheet line 7: total health insurance premiums paid for you, your spouse, and dependents, excluding pre-tax/cafeteria-plan and business-deducted premiums (us.id.health_insurance_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idHealthPremiumsDeductedElsewhere",
    type: "money",
    min: "0",
    description:
      "Health/LTC worksheet line 9: health insurance costs deducted elsewhere on the federal return (e.g. self-employed health insurance) (us.id.health_insurance_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idLtcPremiumsPaid",
    type: "money",
    min: "0",
    description:
      "Health/LTC worksheet line 11: total qualified long-term care insurance premiums paid (us.id.long_term_care_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idLtcDeductedElsewhere",
    type: "money",
    min: "0",
    description:
      "Health/LTC worksheet line 14: long-term care premiums deducted elsewhere on the federal return (us.id.long_term_care_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idEnergyDeviceCost2025",
    type: "money",
    min: "0",
    description:
      "Form 39R line 5a: cost of an alternative energy device placed in service in 2025 (40%) (us.id.alternative_energy_device_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idEnergyDeviceCost2024",
    type: "money",
    min: "0",
    description:
      "Form 39R line 5b: cost of an alternative energy device placed in service in 2024 (20%). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idEnergyDeviceCost2023",
    type: "money",
    min: "0",
    description:
      "Form 39R line 5c: cost of an alternative energy device placed in service in 2023 (20%). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idEnergyDeviceCost2022",
    type: "money",
    min: "0",
    description:
      "Form 39R line 5d: cost of an alternative energy device placed in service in 2022 (20%). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idQualifiedCapitalGain",
    type: "money",
    min: "0",
    description:
      "Form CG: capital gain net income from qualified Idaho property (real property held 12+ months, etc.) (us.id.capital_gains_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idNetCapitalGain",
    type: "money",
    min: "0",
    description:
      "Capital gain net income from all property included in taxable income — caps the Idaho capital gains deduction (us.id.capital_gains_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "idReceivedPublicAssistance",
    type: "bool",
    description:
      "Form 40 line 31 box: receiving Idaho public assistance payments at the end of the tax year (not food stamps or WIC) — no $10 permanent building fund tax (us.id.permanent_building_fund_tax).",
    default: { value: false, rationale: "Assumed not receiving public assistance" },
  },
  {
    id: "idBlind",
    type: "bool",
    description:
      "You or your spouse are legally blind at the end of the tax year — no $10 permanent building fund tax (us.id.permanent_building_fund_tax).",
    default: { value: false, rationale: "Assumed not blind" },
  },
  {
    id: "idRequiredToFile",
    type: "bool",
    description:
      "Idaho requires this return (gross income at or above the filing threshold for the filing status) — the $10 permanent building fund tax applies (us.id.permanent_building_fund_tax).",
    default: { value: true, rationale: "Assumed required to file" },
  },
  {
    id: "idHomeFamilyMembers",
    type: "int",
    min: "0",
    description:
      "Form 39R Part E: family members age 65+ (not you or your spouse) or with a developmental disability for whom you maintained a home all year and provided over half the support — $100 each, at most $300 (us.id.home_for_family_member_credit).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "idHomeFamilyPartialMonths",
    type: "int",
    min: "0",
    description:
      "Form 39R Part E: total months of home maintenance for partially-qualified family members — $8.33 each (us.id.home_for_family_member_credit).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "idUseTaxPurchases",
    type: "money",
    min: "0",
    description:
      "Form 40 line 28: purchases on which no Idaho sales tax was paid (online, mail order, out-of-state) — 6% (us.id.use_tax). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  // ---- Nebraska (Form 1040N) ----
  {
    id: "neUseTaxTable",
    type: "bool",
    description:
      "Compute Nebraska line 15 from the paper 2025 Nebraska Tax Table (row-midpoint cells and the over-$77,760 endpoint worksheet) instead of the Tax Calculation Schedule that e-filers must use (us.ne.income_tax). The two differ by up to $3 (the table prices each $100 row at its midpoint).",
    default: { value: false, rationale: "Electronic filers must use the Tax Calculation Schedule, so it is the default" },
  },
  {
    id: "neExemptions",
    type: "int",
    min: "0",
    description:
      "Form 1040N line 4 Nebraska personal exemptions: yourself and spouse (unless claimable as another taxpayer's dependent) plus the dependents who qualify for the federal child tax credit or other dependent credit — $171 each (us.ne.personal_exemption_credit).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "neAgeBlindBoxes",
    type: "int",
    min: "0",
    max: "4",
    description:
      "Form 1040N line 2a boxes checked: you 65 or older, you blind, spouse 65 or older, spouse blind (0-4) — $2,000 each for single/HOH, $1,650 each for MFJ/QSS/MFS; the rule clamps at 2 for single, QSS, and HOH (us.ne.standard_deduction). For MFS the spouse boxes count only if you can claim the spouse's exemption.",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "neFederalStandardDeduction",
    type: "money",
    min: "0",
    description:
      "The federal standard deduction actually allowed on Form 1040 line 12e — caps the Nebraska standard deduction for a filer who can be claimed as another taxpayer's dependent (us.ne.standard_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "neFederalItemizedDeductions",
    type: "money",
    min: "0",
    description:
      "Form 1040N line 7: total federal itemized deductions, Schedule A line 17 (us.ne.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "neSaltIncomeTaxes",
    type: "money",
    min: "0",
    description:
      "Form 1040N line 8: state and local INCOME taxes on federal Schedule A line 5a, before the federal cap — $0 if line 5a is general sales taxes (us.ne.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "neFederalOtherTax",
    type: "money",
    min: "0",
    description:
      "Form 1040N line 16c: federal tax on lump-sum distributions (Form 4972) plus federal tax on early distributions (the lesser of Form 5329 or Schedule 2 line 8) — Nebraska adds 29.6% (us.ne.other_tax). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "neAgi",
    type: "money",
    description:
      "Federal adjusted gross income, Form 1040N line 5 (Form 1040 line 11) — the $29,000 child care credit split (us.ne.child_care_credit_nonrefundable, us.ne.child_care_credit_refundable) and the Schedule II ratio denominator (us.ne.other_state_credit). May be negative. In dollars.",
  },
  {
    id: "neFederalChildCareCredit",
    type: "money",
    min: "0",
    description:
      "Federal child and dependent care credit allowed, Schedule 3 line 2 — Nebraska allows 25% when AGI exceeds $29,000 (us.ne.child_care_credit_nonrefundable). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "neChildCareExpenses",
    type: "money",
    min: "0",
    description:
      "Form 2441N line 2(C)/3: qualified child and dependent care expenses paid, before the $3,000 / $6,000 cap (us.ne.child_care_credit_refundable). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "neChildCareQualifyingPersons",
    type: "int",
    min: "0",
    description:
      "Form 2441N line 2 qualifying persons — caps line 3 at $3,000 for one, $6,000 for two or more (us.ne.child_care_credit_refundable).",
    default: { value: "1", rationale: "Assumed one qualifying person when expenses are given" },
  },
  {
    id: "neEarnedIncome",
    type: "money",
    min: "0",
    description:
      "Form 2441N line 4: the taxpayer's earned income (us.ne.child_care_credit_refundable). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "neSpouseEarnedIncome",
    type: "money",
    min: "0",
    description:
      "Form 2441N line 5: the spouse's earned income on a joint return (student/disabled deemed amounts per the federal instructions) (us.ne.child_care_credit_refundable). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "neFederalEic",
    type: "money",
    min: "0",
    description:
      "Federal earned income credit, Form 1040 line 27a — Nebraska allows 10% (us.ne.eitc). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "neTaxBeforeCredits",
    type: "money",
    min: "0",
    description:
      "Form 1040N line 17: total Nebraska tax before the personal exemption credit (line 15 + line 16) (us.ne.tax_after_credits, us.ne.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "neNonrefundableCredits",
    type: "money",
    min: "0",
    description:
      "Form 1040N line 34: total nonrefundable credits, lines 18 through 33 (us.ne.tax_after_credits). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "neNetAdjustments",
    type: "money",
    description:
      "Form 1040N line 12 minus line 13 (net Schedule I adjustments; may be negative) — under $5,000 the § 77-2715(1) federal tax liability cap applies (us.ne.tax_after_credits). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "neFederalTaxBeforeCredits",
    type: "money",
    min: "0",
    description:
      "Federal Tax Liability Worksheet line 3: Form 1040 line 16 + Schedule 2 line 2 + Schedule 2 line 8 — the ceiling on Nebraska tax after nonrefundable credits when net adjustments are under $5,000 (us.ne.tax_after_credits). In dollars.",
  },
  {
    id: "neOtherStateAgi",
    type: "money",
    min: "0",
    description:
      "Schedule II line 2: adjusted gross income derived from the other state per the DOR Conversion Chart (not that state's taxable income) (us.ne.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "neOtherStateTaxPaid",
    type: "money",
    min: "0",
    description:
      "Schedule II line 5: income tax due and paid to the other state or its political subdivision (not the amount withheld; no foreign taxes) (us.ne.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "neAdjustmentsIncreasing",
    type: "money",
    min: "0",
    description:
      "Form 1040N line 12: total Schedule I Part A adjustments increasing federal AGI — part of the Schedule II ratio denominator (us.ne.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "neAdjustmentsDecreasing",
    type: "money",
    min: "0",
    description:
      "Form 1040N line 13: total Schedule I Part B adjustments decreasing federal AGI — part of the Schedule II ratio denominator (us.ne.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "neUseTaxPurchases",
    type: "money",
    min: "0",
    description:
      "Form 1040N line 58: 2025 taxable purchases on which no Nebraska sales tax was collected (us.ne.use_tax). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "neLocalUseTaxRateBps",
    type: "int",
    min: "0",
    max: "200",
    description:
      "Form 1040N line 58 local use tax rate in basis points — 0, 50, 100, 150, 175, or 200 (0.5% to 2%) from the local sales and use tax codes schedule (us.ne.use_tax).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  // ---- New Mexico (Form PIT-1) ----
  {
    id: "nmAgi",
    type: "money",
    description:
      "Federal adjusted gross income, PIT-1 line 9 (Form 1040 line 11) — the base of the low- and middle-income exemption (us.nm.low_middle_income_exemption), the 65-or-older/blind exemption table (us.nm.age65_blind_exemption), the Social Security exemption cliff (us.nm.social_security_exemption), and the child income tax credit tiers (us.nm.child_income_tax_credit). May be negative. In dollars.",
  },
  {
    id: "nmExemptions",
    type: "int",
    min: "0",
    description:
      "PIT-1 line 5 exemptions: yourself (unless you can be claimed as a dependent) + spouse on a joint return + dependents and other dependents reported on the federal return — each worth up to $2,500 (us.nm.low_middle_income_exemption).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "nmDependents",
    type: "int",
    min: "0",
    description:
      "Dependents and other dependents on PIT-1 line 8 / Schedule PIT-S (federal § 152) — $4,000 for each beyond the first for a head of household or MFJ filer (us.nm.dependents_deduction).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "nmAge65OrBlindPersons",
    type: "int",
    min: "0",
    max: "2",
    description:
      "Taxpayer and spouse who are 65 or older OR blind (PIT-1 boxes 1c/1d/2c/2d) — one exemption per person, never two for the same person (us.nm.age65_blind_exemption); at most 1 unless married filing jointly.",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "nmAge65Count",
    type: "int",
    min: "0",
    max: "2",
    description:
      "Taxpayer and spouse who are 65 or older — gates the $3,000 medical care expense exemption, the $2,800 refundable medical care credit, and the property tax rebate for persons 65 or older (us.nm.medical_expense_exemption_65, us.nm.medical_care_credit_65, us.nm.property_tax_rebate_65).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "nmTaxableSocialSecurity",
    type: "money",
    min: "0",
    description:
      "Federally taxable Social Security benefits (Form 1040 line 6b) — exempt in full when AGI is not over the § 7-2-5.14 limit (us.nm.social_security_exemption). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "nmNetCapitalGain",
    type: "money",
    min: "0",
    description:
      "Net capital gain per IRC § 1222(11) — the excess of net long-term capital gain over net short-term capital loss (us.nm.capital_gains_deduction: up to $2,500). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "nmBusinessSaleGain",
    type: "money",
    min: "0",
    description:
      "Net capital gain from the sale of a business allocated or apportioned to New Mexico under § 7-2-11 (us.nm.capital_gains_deduction: 40% of up to $1,000,000). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "nmArmedForcesRetirementPay",
    type: "money",
    min: "0",
    description:
      "The primary taxpayer's armed forces retirement pay (or survivor pay of an armed forces retiree) included in federal AGI — $30,000 exempt (us.nm.armed_forces_retirement_exemption). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "nmArmedForcesRetirementPaySpouse",
    type: "money",
    min: "0",
    description:
      "The spouse's armed forces retirement pay on a joint return — its own $30,000 exemption (us.nm.armed_forces_retirement_exemption). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "nmMedicalExpenses",
    type: "money",
    min: "0",
    description:
      "Unreimbursed and uncompensated medical care expenses paid in the year for the taxpayer, spouse, or dependents (§ 7-2-5.9 definition; includes Medicare Part B premiums) — $28,000 or more with a taxpayer 65+ unlocks the $3,000 exemption and the $2,800 credit (us.nm.medical_expense_exemption_65, us.nm.medical_care_credit_65). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "nmModifiedGrossIncome",
    type: "money",
    min: "0",
    description:
      "PIT-RC line 12 modified gross income (§ 7-2-2(L)): ALL income of the taxpayer, spouse, and dependents, taxable or not, undiminished by losses — wages, gross Social Security and pensions, unemployment, public assistance, business profit (no losses), gross capital gains, gifts, interest, child support (us.nm.lictr, us.nm.property_tax_rebate_65, us.nm.county_property_tax_rebate). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "nmRebateExemptions",
    type: "int",
    min: "0",
    description:
      "PIT-RC line 13a rebate exemptions: PIT-1 line 5 exemptions minus non-qualifying household members, plus 1 for each blind person and 2 for each person 65 or older (§ 7-2-14(C)) — selects the LICTR column (us.nm.lictr).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "nmFederalEic",
    type: "money",
    min: "0",
    description:
      "Federal earned income credit (Form 1040 line 27), or the EIC computed under the NM Expansion for a filer denied federally only by the SSN or under-25 age rule — New Mexico allows 25% (us.nm.working_families_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "nmQualifyingChildren",
    type: "int",
    min: "0",
    description:
      "Qualifying children under IRC § 152(c) (plus public-assistance-supported minor children) — one child income tax credit each (us.nm.child_income_tax_credit).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "nmPropertyTaxBilled",
    type: "money",
    min: "0",
    description:
      "Property tax billed for the calendar year on the principal place of residence (dwelling plus up to five acres) (us.nm.property_tax_rebate_65 line 15, us.nm.county_property_tax_rebate line 18a). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "nmRentPaid",
    type: "money",
    min: "0",
    description:
      "Rent paid during the year on the principal place of residence, including government subsidies paid to the landlord — 6% counts as property tax (us.nm.property_tax_rebate_65 lines 16a-16c). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "nmRebateCounty",
    type: "bool",
    description:
      "The taxpayer OWNS and occupies a principal residence in Los Alamos, Santa Fe, Doña Ana, or Bernalillo County — enables the additional low income property tax rebate (us.nm.county_property_tax_rebate).",
    default: { value: false, rationale: "Assumed not a resident of one of the four rebate counties absent contrary input" },
  },
  {
    id: "nmSaltIncomeTaxes",
    type: "money",
    min: "0",
    description:
      "Federal Schedule A line 5a: state and local INCOME taxes (or general sales taxes) claimed — PIT-1 line 10 worksheet line 1 (us.nm.salt_addback). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "nmSaltTotal",
    type: "money",
    min: "0",
    description:
      "Federal Schedule A line 5d: total state and local taxes before the SALT cap — worksheet line 2 (us.nm.salt_addback). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "nmSaltAllowed",
    type: "money",
    min: "0",
    description:
      "Federal Schedule A line 5e: state and local taxes actually deducted after the cap — worksheet line 4 (us.nm.salt_addback). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "nmFederalStandardDeduction",
    type: "money",
    min: "0",
    description:
      "The federal standard deduction the filer could have claimed on Form 1040 line 12 had they not itemized — worksheet line 7 (us.nm.salt_addback). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "nmFederalItemizedDeductions",
    type: "money",
    min: "0",
    description:
      "Total federal itemized deductions actually claimed on Form 1040 line 12 — worksheet line 8 (us.nm.salt_addback). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "nmFederalItemized",
    type: "bool",
    description:
      "The filer itemized deductions on the 2025 federal return (PIT-1 box 12a) — the state and local tax add-back applies only then (us.nm.salt_addback).",
    default: { value: false, rationale: "Assumed the federal standard deduction was taken absent contrary input" },
  },
  // ---- Arkansas (Form AR1000F) ----
  {
    id: "arStatus4",
    type: "bool",
    description:
      "Arkansas Filing Status 4 — a married couple (filingStatus mfj) filing SEPARATELY ON THE SAME RETURN, each spouse taxed on their own column; false = status 2 (joint). Affects us.ar.standard_deduction ($2,470 per column instead of $4,940), us.ar.additional_tax_credit (per column, not doubled), us.ar.capital_gains ($1,500 loss limit per column), and us.ar.low_income_tax (refused for status 4).",
    default: { value: false, rationale: "A married couple is assumed to file jointly (status 2) absent the status-4 election" },
  },
  {
    id: "arAgi",
    type: "money",
    description:
      "Arkansas adjusted gross income (AR1000F line 25) of the return or COLUMN being evaluated — the Low Income Tax Table lookup base (us.ar.low_income_tax), the standard-deduction cap (us.ar.standard_deduction), and, as the COMBINED line 25A + 25B, the 10% medical and 2% miscellaneous floors (us.ar.itemized_deductions). May be negative. In dollars.",
  },
  {
    id: "arDependents",
    type: "int",
    min: "0",
    description:
      "Dependents listed on AR1000F line 7B — $29 each (us.ar.personal_tax_credits) and the '1 or no' vs '2 or more' Low Income Tax Table column (us.ar.low_income_tax).",
    default: { value: "0", rationale: "Assumed no dependents absent contrary input" },
  },
  {
    id: "arCreditBoxes",
    type: "int",
    min: "0",
    max: "8",
    description:
      "Count of AR1000F line 7A boxes checked for '65 or over', '65 Special' (65+ and NOT claiming the line 18 retirement exclusion), 'Blind', and 'Deaf' — taxpayer and spouse (at most 4 each; the rule clamps an unmarried filer at 4). $29 each (us.ar.personal_tax_credits). Do NOT count Yourself, Spouse, or the head-of-household/surviving-spouse box — the rule adds those from filingStatus.",
    default: { value: "0", rationale: "Assumed no 65+/blind/deaf boxes absent contrary input" },
  },
  {
    id: "arPensionTaxable",
    type: "money",
    min: "0",
    description:
      "ONE taxpayer's federally taxable employer-plan pension and qualified traditional IRA distributions (1099-R box 2a; IRA only after 59½ or on death/disability) — the base of the $6,000 exclusion (us.ar.retirement_exclusion). Premature IRA withdrawals and annuities go on line 16 with no exclusion. In dollars.",
    default: { value: "0", rationale: "Assumed no pension or qualified IRA distributions absent contrary input" },
  },
  {
    id: "arMilitaryRetirement",
    type: "money",
    min: "0",
    description:
      "The same taxpayer's exempt military retirement pay (AR1000F line 17) — reduces the $6,000 pension/IRA exclusion dollar for dollar (Ark. Code § 26-51-307(f); us.ar.retirement_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed no military retirement absent contrary input" },
  },
  {
    id: "arChildCareExpenses",
    type: "money",
    min: "0",
    description:
      "AR2441 line 2(c)/3: qualified child and dependent care expenses paid in the year, before the $3,000 / $6,000 cap (us.ar.child_care_credit). In dollars.",
    default: { value: "0", rationale: "Assumed no child care expenses absent contrary input" },
  },
  {
    id: "arChildCareQualifyingPersons",
    type: "int",
    min: "0",
    description:
      "Number of qualifying persons on AR2441 line 2 — caps line 3 at $3,000 for one, $6,000 for two or more (us.ar.child_care_credit).",
    default: { value: "1", rationale: "Assumed one qualifying person when expenses are given" },
  },
  {
    id: "arEarnedIncome",
    type: "money",
    min: "0",
    description: "AR2441 line 4: the taxpayer's earned income (us.ar.child_care_credit). In dollars.",
    default: { value: "0", rationale: "Assumed no earned income absent contrary input (denies the credit)" },
  },
  {
    id: "arSpouseEarnedIncome",
    type: "money",
    min: "0",
    description:
      "AR2441 line 5: the spouse's earned income when filingStatus is mfj (Arkansas status 2 or 4; a student or disabled spouse's deemed income per the instructions); ignored for other statuses (us.ar.child_care_credit). In dollars.",
    default: { value: "0", rationale: "Assumed no spouse earned income absent contrary input (denies a married couple's credit)" },
  },
  {
    id: "arFederalAgi",
    type: "money",
    description:
      "AR2441 line 7 = federal Form 1040 line 11 — sets the 35%-to-20% percentage (1 point per $2,000 over $15,000) (us.ar.child_care_credit). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 federal AGI absent contrary input (35% tier)" },
  },
  {
    id: "arLongTermGain",
    type: "money",
    description:
      "AR1000D line 3: Arkansas net long-term capital gain or LOSS (negative) for the column — federal Schedule D line 15 adjusted for depreciation differences (us.ar.capital_gains). In dollars.",
    default: { value: "0", rationale: "Assumed no long-term capital gain or loss absent contrary input" },
  },
  {
    id: "arShortTermGain",
    type: "money",
    description:
      "AR1000D lines 6/11: Arkansas net short-term capital gain (positive) or loss (negative) for the column — federal Schedule D line 7 (us.ar.capital_gains). In dollars.",
    default: { value: "0", rationale: "Assumed no short-term capital gain or loss absent contrary input" },
  },
  {
    id: "arMedicalExpenses",
    type: "money",
    min: "0",
    description: "AR3 line 1: medical and dental expenses paid, not reimbursed — the rule subtracts 10% of Arkansas AGI (us.ar.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed no medical expenses absent contrary input" },
  },
  {
    id: "arTaxesPaid",
    type: "money",
    min: "0",
    description:
      "AR3 lines 5-6: real estate tax plus personal property tax and other deductible taxes (city income taxes, foreign income taxes on income taxed here) — NOT Arkansas or federal income taxes or sales taxes (us.ar.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed no deductible taxes absent contrary input" },
  },
  {
    id: "arInterestPaid",
    type: "money",
    min: "0",
    description: "AR3 lines 8-11: home mortgage interest (institutions and individuals), deductible points, and investment interest limited to investment income (us.ar.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed no deductible interest absent contrary input" },
  },
  {
    id: "arContributions",
    type: "money",
    min: "0",
    description: "AR3 lines 13-16: cash, art/literary, other, and carryover contributions (excess over 60% of AGI carries forward five years) (us.ar.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed no contributions absent contrary input" },
  },
  {
    id: "arCasualtyLosses",
    type: "money",
    min: "0",
    description: "AR3 line 18: total casualty and theft losses from AR4684 (after the $100 exclusion and the 10%-of-AGI test) (us.ar.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed no casualty losses absent contrary input" },
  },
  {
    id: "arTuitionDeduction",
    type: "money",
    min: "0",
    description: "AR3 line 19: post-secondary education tuition deduction(s) from AR1075 (us.ar.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed no tuition deduction absent contrary input" },
  },
  {
    id: "arMiscExpenses",
    type: "money",
    min: "0",
    description: "AR3 lines 20-21: unreimbursed employee business expenses (AR2106) and other miscellaneous deductions SUBJECT to the 2%-of-AGI floor — the rule subtracts 2% of Arkansas AGI (us.ar.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed no miscellaneous expenses absent contrary input" },
  },
  {
    id: "arOtherMiscDeductions",
    type: "money",
    min: "0",
    description: "AR3 lines 26-28: volunteer firefighter expenses (≤ $1,000), gambling losses (≤ winnings), and other miscellaneous deductions NOT subject to the 2% floor (us.ar.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed none absent contrary input" },
  },
  // ---- Kansas (Form K-40) ----
  {
    id: "ksStdBoxes",
    type: "int",
    min: "0",
    max: "4",
    description:
      "Count of Kansas standard-deduction boxes for 65-or-older and/or blind (taxpayer and spouse: at most 2 for single/HOH/QSS, 4 for MFJ/MFS — the rule clamps a single/HOH count at 2) — each adds $850 (single/HOH/QSS) or $700 (MFJ/MFS) to the base deduction (us.ks.standard_deduction).",
    default: { value: "0", rationale: "Assumed no 65+/blind boxes absent contrary input" },
  },
  {
    id: "ksDependents",
    type: "int",
    min: "0",
    description:
      "Number of dependents claimed on the federal return — $2,320 each on Form K-40 (us.ks.exemptions); zero when the filer is claimed as someone else's dependent (isClaimedAsDependent).",
    default: { value: "0", rationale: "Assumed no dependents absent contrary input" },
  },
  {
    id: "ksChildrenBornThisYear",
    type: "int",
    min: "0",
    description:
      "Dependent children born during the tax year — an ADDITIONAL $2,320 Kansas exemption each (K.S.A. 79-32,121; us.ks.exemptions).",
    default: { value: "0", rationale: "Assumed no children born this year absent contrary input" },
  },
  {
    id: "ksStillbirths",
    type: "int",
    min: "0",
    description:
      "Stillbirths during the tax year for which a certificate of stillbirth was issued — $2,320 Kansas exemption each (us.ks.exemptions).",
    default: { value: "0", rationale: "Assumed none absent contrary input" },
  },
  {
    id: "ksDisabledVeterans",
    type: "int",
    min: "0",
    description:
      "Honorably discharged veterans on the return (taxpayer and/or spouse) certified by the VA at the 100% permanent disability rate — an additional $2,320 Kansas exemption each for 2025 and later (us.ks.exemptions).",
    default: { value: "0", rationale: "Assumed no qualifying disabled veterans absent contrary input" },
  },
  {
    id: "ksMedicalExpenses",
    type: "money",
    min: "0",
    description:
      "Medical and dental expenses paid (Kansas Schedule A line 1; the federal Schedule A line 1 amount, or the total if the filer did not itemize federally) — Kansas allows 100% of § 213 expenses over 7.5% of federal AGI (us.ks.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed no medical expenses absent contrary input" },
  },
  {
    id: "ksFederalAgi",
    type: "money",
    description:
      "Federal adjusted gross income (Kansas Schedule A line 2 = Form 1040 line 11) — the base of the 7.5% medical floor (us.ks.itemized_deductions). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed $0 federal AGI absent contrary input" },
  },
  {
    id: "ksPropertyTaxes",
    type: "money",
    min: "0",
    description:
      "State and local REAL ESTATE plus value-based PERSONAL PROPERTY taxes paid (Kansas Schedule A lines 5-6) — 100% deductible with no SALT cap; state/local income or sales taxes are NOT deductible in Kansas (us.ks.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed no property taxes absent contrary input" },
  },
  {
    id: "ksMortgageInterest",
    type: "money",
    min: "0",
    description:
      "Qualified residence interest and points (Kansas Schedule A lines 8a-8c, § 163(h)) — 100% deductible (us.ks.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed no mortgage interest absent contrary input" },
  },
  {
    id: "ksCharitableContributions",
    type: "money",
    min: "0",
    description:
      "Gifts to charity by cash, other than cash, and carryover (Kansas Schedule A lines 10-12, § 170 limits) — 100% deductible (us.ks.itemized_deductions). In dollars.",
    default: { value: "0", rationale: "Assumed no charitable contributions absent contrary input" },
  },
  {
    id: "ksFederalEic",
    type: "money",
    min: "0",
    description:
      "Federal earned income credit (Form 1040 line 27a) — Kansas allows 17%, nonrefundable to the line 16 tax with the excess refundable (us.ks.eitc); residents only, valid SSNs required. In dollars.",
    default: { value: "0", rationale: "Assumed no federal EIC absent contrary input" },
  },
  {
    id: "ksFederalChildCareCredit",
    type: "money",
    min: "0",
    description:
      "Federal child and dependent care credit ALLOWED (Form 2441 / Schedule 3 line 2) — Kansas allows 50%, nonrefundable, residents only (us.ks.child_care_credit). In dollars.",
    default: { value: "0", rationale: "Assumed no federal child care credit absent contrary input" },
  },
  // ---- Montana (Form 2) ----
  {
    id: "mtNetLongTermCapitalGains",
    type: "money",
    description:
      "Form 2 page 2 line 2: net long-term capital gains subject to the federal net long-term capital gains tax — generally the LESSER of federal Schedule D line 15 or line 16 (us.mt.income_tax, us.mt.capital_gains_tax). Montana taxes these at 3% / 4.1%; qualified dividends are NOT included (they are Montana ordinary income). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mtTaxpayerAge65",
    type: "bool",
    description:
      "Form 2 line 6: you attained age 65 — a $5,660 subtraction from federal taxable income for 2025 (us.mt.age65_subtraction).",
    default: { value: false, rationale: "Assumed not attested — Montana attestations produce $0 unless stated" },
  },
  {
    id: "mtSpouseAge65",
    type: "bool",
    description:
      "Form 2 line 6: your spouse attained age 65 — a second $5,660 subtraction, on a JOINT return only (us.mt.age65_subtraction).",
    default: { value: false, rationale: "Assumed not attested — Montana attestations produce $0 unless stated" },
  },
  {
    id: "mtFederalEic",
    type: "money",
    description:
      "Form 2 line 15: the federal earned income credit from federal Form 1040 line 27 — Montana allows 10% of it for 2025, 20% from 2026, refundable (us.mt.eitc). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mtAge62",
    type: "bool",
    description:
      "Schedule 2EC eligibility: the claimant reached age 62 by December 31 of the tax year (us.mt.elderly_homeowner_renter_credit).",
    default: { value: false, rationale: "Assumed not attested — Montana attestations produce $0 unless stated" },
  },
  {
    id: "mtResided9Months",
    type: "bool",
    description:
      "Schedule 2EC eligibility: the claimant resided in Montana for at least nine months during the tax year (us.mt.elderly_homeowner_renter_credit).",
    default: { value: false, rationale: "Assumed not attested — Montana attestations produce $0 unless stated" },
  },
  {
    id: "mtOccupied6Months",
    type: "bool",
    description:
      "Schedule 2EC eligibility: the claimant occupied a Montana residence as an owner, renter or lessee for at least six months during the tax year (us.mt.elderly_homeowner_renter_credit).",
    default: { value: false, rationale: "Assumed not attested — Montana attestations produce $0 unless stated" },
  },
  {
    id: "mtSoleHouseholdClaimant",
    type: "bool",
    description:
      "Schedule 2EC attestation: 'I am the only member of my household claiming this credit' — only one elderly homeowner/renter credit is allowed per household (us.mt.elderly_homeowner_renter_credit).",
    default: { value: false, rationale: "Assumed not attested — Montana attestations produce $0 unless stated" },
  },
  {
    id: "mtGrossHouseholdIncome",
    type: "money",
    description:
      "Schedule 2EC line 18: GROSS household income — all income of ALL household members, taxable and non-taxable, including the full amount of pensions and annuities, Railroad Retirement and veterans' disability benefits, excluded capital gains, alimony, support money, cash public assistance, tax-exempt interest, all Social Security, and refundable credits received in cash (expressly including the 2024 Montana property tax rebate). This is NOT federal AGI. Must be under $45,000 (us.mt.elderly_homeowner_renter_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mtPropertyTaxBilled",
    type: "money",
    description:
      "Schedule 2EC line 23: property tax billed on the Montana residence and up to one acre, including special assessments and fees but excluding penalties and interest (us.mt.elderly_homeowner_renter_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mtRentPaid",
    type: "money",
    description:
      "Schedule 2EC line 24: rent paid in the tax year for the Montana residence — 15% of it is the rent-equivalent tax paid. Excludes mortgage payments, nursing home costs paid directly from Social Security, and rent paid by a rental assistance program (us.mt.elderly_homeowner_renter_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mtOrdinaryIncomeTax",
    type: "money",
    description:
      "Schedule III Part II line 5: Montana ordinary income tax from Form 2 page 2 line 12 — the base the other-state credit's ordinary block is limited by (us.mt.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mtCapitalGainsTax",
    type: "money",
    description:
      "Schedule III Part II line 15: Montana net long-term capital gains tax from Form 2 page 2 line 11 — the base the other-state credit's capital gains block is limited by (us.mt.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mtOtherStateOrdinaryIncome",
    type: "money",
    description:
      "Schedule III Part II line 1: income sourced and taxable to the other state or country that is included in Montana taxable income, EXCLUDING net long-term capital gains (us.mt.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mtOtherStateCapitalGains",
    type: "money",
    description:
      "Schedule III Part II line 11: net long-term capital gain sourced and taxable to the other state or country and included in Montana taxable income (us.mt.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mtOtherStateTotalIncome",
    type: "money",
    description:
      "Schedule III Part II lines 2 and 12: ALL income sourced and taxable to the other state or country — the denominator of the first ratio (us.mt.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mtOrdinaryIncomeSourcedToMontana",
    type: "money",
    description:
      "Schedule III Part II line 3: income sourced and taxable to Montana excluding net long-term capital gains (full-year residents: federal Form 1040 line 9 excluding net long-term capital gains, less related expenses) — the denominator of the second ratio (us.mt.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mtFederalNetLongTermCapitalGains",
    type: "money",
    description:
      "Schedule III Part II line 13: federal net long-term capital gains — the denominator of the capital gains block's second ratio (us.mt.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mtOtherStateTaxPaid",
    type: "money",
    description:
      "Schedule III Part II lines 4 AND 14: the TOTAL income tax liability actually paid to the other state or country, excluding penalties and interest (us.mt.other_state_credit). The same figure feeds both blocks — the line 16 ratio attributes the capital-gains share; do not pre-attribute. North Dakota WAGES are not eligible (reciprocity); foreign tax is not eligible if a federal Form 1116 credit was claimed. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mtTuitionSavingsContributions",
    type: "money",
    description:
      "Schedule I line 16: contributions to a Montana family education savings (section 529) account — up to $4,500, or $9,000 on a joint return, for 2025 (us.mt.tuition_savings_subtraction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mtAbleContributions",
    type: "money",
    description:
      "Schedule I line 17: contributions to an Achieving a Better Life Experience (ABLE) account — up to $3,000, or $6,000 on a joint return (us.mt.able_subtraction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mtMilitaryRetirementIncome",
    type: "money",
    description:
      "Schedule I line 13: military pension, military retirement income, or military survivor benefits (Form WMRE) — the subtraction is the LESSER of Montana source wage income or 50% of this amount (us.mt.military_retirement_subtraction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mtMontanaSourceWageIncome",
    type: "money",
    description:
      "MCA 15-30-2120(8)(b): Montana source wage income — the cap on the military retirement subtraction. The statute defines it as wages, salary, tips and other compensation for services performed in Montana PLUS net income from a trade, business, profession or occupation carried on in Montana PLUS net income from Montana farming, so Schedule C and F net income count; a fully retired veteran with none of the three gets nothing (us.mt.military_retirement_subtraction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "mtMilitaryRetireeEligible",
    type: "bool",
    description:
      "MCA 15-30-2120(9)(a): the military retiree either became a Montana resident on or after June 30, 2023, or was a resident before receiving the pension and remained one after (us.mt.military_retirement_subtraction).",
    default: { value: false, rationale: "Assumed not attested — Montana attestations produce $0 unless stated" },
  },
  {
    id: "mtMilitaryRetireeWithinFiveYears",
    type: "bool",
    description:
      "MCA 15-30-2120(9)(b): the subtraction is being claimed within the five consecutive years allowed after first qualifying (us.mt.military_retirement_subtraction).",
    default: { value: false, rationale: "Assumed not attested — Montana attestations produce $0 unless stated" },
  },
  // ---- Delaware (Form PIT-RES) ----
  {
    id: "deUseRateSchedule",
    type: "bool",
    description:
      "Form PIT-RES line 24: compute from the rate schedule at the exact taxable income instead of the printed Tax Table (taxable income under $60,000 uses the table's row midpoint by instruction; $60,000 or more always uses the schedule) (us.de.income_tax).",
    default: { value: false, rationale: "Assumed not attested — Delaware attestations produce $0 unless stated" },
  },
  {
    id: "deItemizes",
    type: "bool",
    description:
      "Form PIT-RES line 20b: itemizing Delaware deductions instead of the standard deduction. Delaware's election is INDEPENDENT of the federal one, but it disallows the line 21 additional standard deduction entirely (us.de.standard_deduction).",
    default: { value: false, rationale: "Assumed not attested — Delaware attestations produce $0 unless stated" },
  },
  {
    id: "deAdditionalDeductionBoxes",
    type: "int",
    description:
      "Form PIT-RES line 21: the number of boxes checked for age 65 or over and blindness — $2,500 each, maximum two boxes ($5,000) per person. Four boxes are possible on a joint return, and on a married-filing-separate return (status 3) when the spouse's boxes qualify under 30 Del. C. § 1108(b)(2)/(4): that spouse is 65 or over or blind, has NO gross income, and is not another taxpayer's dependent. Two boxes for every other status, and per column of a combined separate return. Not allowed with itemized deductions (us.de.standard_deduction).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "deExemptions",
    type: "int",
    description:
      "Form PIT-RES line 27a: the number of federal exemptions (yourself, your spouse on a joint return, and dependents) — $110 each. A childless joint return enters 2 (us.de.personal_credits).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "deAge60Persons",
    type: "int",
    description:
      "Form PIT-RES line 27b: the number of persons 60 or over on December 31 (you and/or your spouse) — an additional $110 each (us.de.personal_credits).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "deAge60OrOver",
    type: "bool",
    description:
      "Form PIT-RES line 6: the person claiming the pension exclusion was 60 or over on December 31 of the tax year — the 60-or-over tier allows $12,500 of pension PLUS eligible retirement income, while under 60 allows only $2,000 of pension (us.de.pension_exclusion).",
    default: { value: false, rationale: "Assumed not attested — Delaware attestations produce $0 unless stated" },
  },
  {
    id: "deDomiciledForPensionExclusion",
    type: "bool",
    description:
      "TY2026 and after: the person claiming the 60-or-over pension exclusion has been legally domiciled in Delaware (a 'resident individual' under 30 Del. C. § 1103) for at least three years — 30 Del. C. § 1106(b)(3)f.4, added by 85 Del. Laws c. 426 effective August 17, 2026. A 60-or-over person who does not meet it gets NO pension exclusion at all, not the under-60 tier (us.de.pension_exclusion version 2). Not needed for TY2025.",
    default: { value: false, rationale: "Assumed not attested — Delaware attestations produce $0 unless stated" },
  },
  {
    id: "deMilitaryPension",
    type: "bool",
    description:
      "Form PIT-RES line 6 checkbox: the pension is a United States military pension — raises the UNDER-60 exclusion from $2,000 to $12,500. Since 84 Del. Laws c. 437 the definition covers the Army, Navy, Air Force, Marine Corps, Space Force, Coast Guard, the NOAA and Public Health Service commissioned corps, and the National Guard (us.de.pension_exclusion).",
    default: { value: false, rationale: "Assumed not attested — Delaware attestations produce $0 unless stated" },
  },
  {
    id: "dePensionIncome",
    type: "money",
    description:
      "Form PIT-RES line 6: amounts received as pensions from employers, the United States, this State or its subdivisions. Excludes early distributions (1099-R box 7 code 1, or an early-withdrawal penalty) and employer-paid disability pension income before minimum retirement age (us.de.pension_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "deEligibleRetirementIncome",
    type: "money",
    description:
      "Form PIT-RES line 6, 60-or-over worksheet: eligible retirement income — dividends, capital gains net of losses, interest, net rental income from real property, and qualified retirement plan distributions (IRA, 401(k), Keogh, and IRC 457 government deferred compensation). Counts ONLY for a person 60 or over (us.de.pension_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "deAgiBeforeExclusion",
    type: "money",
    description:
      "Form PIT-RES line 10: adjusted gross income after the Section B subtractions but BEFORE the line 11 exclusion — the statutory 'adjusted gross income (without reduction by this exclusion)' income test (us.de.elderly_disabled_exclusion). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "deEarnedIncome",
    type: "money",
    description:
      "Form PIT-RES line 11 worksheet: earned income (wages, tips, farm or business income) — must be under $2,500, or under $5,000 on a joint return, for the elderly/disabled exclusion (us.de.elderly_disabled_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "deQualifiesElderlyDisabled",
    type: "bool",
    description:
      "Form PIT-RES line 11 worksheet: you were at least 60 years old OR totally and permanently disabled on December 31 (us.de.elderly_disabled_exclusion).",
    default: { value: false, rationale: "Assumed not attested — Delaware attestations produce $0 unless stated" },
  },
  {
    id: "deSpouseQualifiesElderlyDisabled",
    type: "bool",
    description:
      "Form PIT-RES line 11 worksheet: your spouse was at least 60 years old OR totally and permanently disabled on December 31 — the $4,000 joint tier requires BOTH spouses to qualify (us.de.elderly_disabled_exclusion).",
    default: { value: false, rationale: "Assumed not attested — Delaware attestations produce $0 unless stated" },
  },
  {
    id: "deFederalEic",
    type: "money",
    description:
      "DE Schedule II line 13: the federal earned income credit from federal Form 1040 line 27. Delaware allows either 20% limited to the tax or 4.5% fully refundable (us.de.eitc). In dollars.",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "deEitcTaxAfterCredits",
    type: "money",
    description:
      "DE Schedule II line 12: Form PIT-RES line 33 — the Delaware tax after ALL other non-refundable credits, which decides which earned income credit branch applies (us.de.eitc). In dollars.",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "deFederalChildCareCredit",
    type: "money",
    description:
      "Form PIT-RES line 31 worksheet: the federal child and dependent care credit from federal Form 2441 line 11. Delaware allows 50% of it, capped at $3,000 and at the tax (us.de.child_care_credit). In dollars.",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "deAdjustedGrossIncome",
    type: "money",
    description:
      "Form PIT-RES line 12: Delaware adjusted gross income — the denominator of the other-state credit ratio (us.de.other_state_credit). May be negative. In dollars.",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "deIncomeTax",
    type: "money",
    description:
      "Form PIT-RES line 24: the Delaware tax before credits, which the other-state credit ratio is applied to (us.de.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "deOtherStateIncome",
    type: "money",
    description:
      "Other-state credit worksheet line 1: adjusted gross income from the other state's return. The ratio to Delaware AGI is capped at 100% (us.de.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "deOtherStateTaxPaid",
    type: "money",
    description:
      "Other-state credit worksheet line 6: income tax paid to the other state net of its credits. EXCLUDES city and county taxes; the District of Columbia counts as a state (us.de.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "deVolunteerFirefighters",
    type: "int",
    description:
      "Form PIT-RES line 29: the number of qualifying active volunteer firefighters or members of a volunteer fire company auxiliary, ambulance or rescue squad on the return (0, 1 or 2) — $1,000 each. The Division verifies this credit before processing, so it defaults to none (us.de.volunteer_firefighter_credit).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  // ---- North Dakota (Form ND-1) ----
  {
    id: "ndUseRateSchedule",
    type: "bool",
    description:
      "Form ND-1 line 20: compute from the rate schedule at the exact taxable income instead of the printed Tax Table (taxable income under $100,000 uses the table's $50-row midpoint, which section 57-38-30.3(10) makes mandatory; $100,000 or more always uses the schedule) (us.nd.income_tax).",
    default: { value: false, rationale: "Assumed not elected — the Tax Table governs below $100,000" },
  },
  {
    id: "ndNetLongTermCapitalGain",
    type: "money",
    description:
      "Net long-term capital gain worksheet line 3: the SMALLER of federal Schedule D lines 15 and 16 — or, when no Schedule D was required, the capital gain distributions from Form 1040 line 7. The worksheet stops outright if either Schedule D figure is zero or less, so a net loss yields no exclusion (us.nd.capital_gain_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "ndCapitalGainAlreadyExcluded",
    type: "money",
    description:
      "Net long-term capital gain worksheet line 6: the portion of that gain already included in an amount entered on Form ND-1 line 7 (exempt Native American income) or line 16 (Schedule ND-1SA subtractions), which is not eligible for the 40% exclusion (us.nd.capital_gain_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "ndQualifiedDividends",
    type: "money",
    description:
      "Form ND-1 line 13: qualified dividends from federal Form 1040 or 1040-SR line 3a — North Dakota excludes 40%. A part-year resident or nonresident uses the portion reported to North Dakota (us.nd.qualified_dividend_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "ndCollegeSaveContributions",
    type: "money",
    description:
      "Form ND-1 line 12: contributions to a North Dakota College SAVE account administered by the Bank of North Dakota — capped at $5,000, or $10,000 on a joint return. Rollovers from another section 529 plan do NOT qualify (us.nd.college_save_deduction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "ndTaxableIncome",
    type: "money",
    description:
      "Form ND-1 line 18: North Dakota taxable income — the marriage penalty credit requires it to exceed $81,036 for 2025 (us.nd.marriage_penalty_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "ndLowerQualifiedIncome",
    type: "money",
    description:
      "Marriage Penalty Credit Worksheet: the qualified income of the LOWER-earning spouse, which must exceed $47,550 for 2025 (us.nd.marriage_penalty_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "ndSingleScheduleTaxA",
    type: "money",
    description:
      "Marriage Penalty Credit Worksheet line 7: the tax on WORKSHEET LINE 6 computed on the SINGLE rate schedule (us.nd.marriage_penalty_credit). Line 6 is the lower-earning spouse's qualified income MINUS the worksheet's preprinted $15,750 (half the federal joint standard deduction) — the rule takes this line as a computed amount and does NOT subtract the $15,750 itself, so a caller supplying the tax on the unreduced income overstates the credit. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "ndSingleScheduleTaxB",
    type: "money",
    description:
      "Marriage Penalty Credit Worksheet line 9: the tax on WORKSHEET LINE 8 computed on the SINGLE rate schedule (us.nd.marriage_penalty_credit). Line 8 is Form ND-1 line 18 taxable income MINUS that same worksheet line 6 amount (the lower-earning spouse's qualified income less the preprinted $15,750). The rule takes this line as a computed amount and performs neither subtraction itself. In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "ndJointScheduleTax",
    type: "money",
    description:
      "Marriage Penalty Credit Worksheet line 10: the tax on WORKSHEET LINE 1 — the couple's Form ND-1 line 18 taxable income, NOT their qualified income — computed on the MARRIED FILING JOINTLY rate schedule (us.nd.marriage_penalty_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "ndDoublyTaxedIncome",
    type: "money",
    description:
      "Schedule ND-1CR line 1c: the part of federal AGI sourced to the other state that was received or earned while a North Dakota resident — the numerator of the four-decimal ratio (us.nd.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "ndOtherStateIncomeBase",
    type: "money",
    description:
      "Schedule ND-1CR line 2: for a full-year resident, federal AGI (Form ND-1 line 1a) LESS the line 5 United States obligation interest — the denominator of the ratio (us.nd.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "ndIncomeTaxBeforeCredits",
    type: "money",
    description:
      "Schedule ND-1CR line 4: the North Dakota tax from Form ND-1 line 20, which the ratio is applied to (us.nd.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "ndOtherStateTaxPaid",
    type: "money",
    description:
      "Schedule ND-1CR line 6: the NET income tax shown on the other state's return — after that state's credits but before its withholding and estimated payments — plus any local jurisdiction tax in that same state. Foreign countries do not qualify, and Montana and Minnesota WAGES are excluded by reciprocity (us.nd.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  // ---- Vermont (Form IN-111) ----
  {
    id: "vtUseRateSchedule",
    type: "bool",
    description:
      "Form IN-111 line 8: apply the rate schedule at the exact taxable income instead of the printed Tax Table (taxable income under $75,000 uses the $100-row midpoint; 'TAXABLE INCOME UNDER $75,000 USE THE TAX TABLES') (us.vt.income_tax).",
    default: { value: false, rationale: "Assumed not elected — the Tax Table governs below $75,000" },
  },
  {
    id: "vtFederalAgi",
    type: "money",
    description:
      "Form IN-111 line 1: federal adjusted gross income — the base for the 3% minimum tax above $150,000, the retirement and military exclusion phase-outs, the child tax credit and veteran credit phase-outs, the student loan interest limit and the estimated use tax table (us.vt.income_tax and the Vermont credit and exclusion rules). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtUsObligationInterest",
    type: "money",
    description:
      "Schedule IN-112 Part I line 7: interest income from U.S. government obligations — subtracted from federal AGI before the 3% minimum tax is figured, per the Form IN-111 line 8 instruction (us.vt.income_tax). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtAdditionalDeductionBoxes",
    type: "int",
    min: "0",
    max: "4",
    description:
      "Form IN-111 line 4: the number of standard deduction boxes checked on federal Form 1040 (born before January 2, 1961, or blind) — $1,250 each; the chart allows at most two for single and head of household and four for the 'Married Filing Jointly or Qualifying Widow(er)' row and for married filing separately (us.vt.standard_deduction).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "vtExemptions",
    type: "int",
    min: "0",
    description:
      "Form IN-111 line 5d: total personal exemptions — 1 for yourself unless someone can claim you, 1 for a spouse on a joint return only (NOT a qualifying widow(er) or married filing separately), plus other dependents (us.vt.personal_exemption).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "vtRetirementElection",
    type: "enum",
    enumValues: ["none", "social_security", "contributory_system"],
    description:
      "Schedule IN-112 line 12 election under 32 V.S.A. § 5830e(e)(1): exclude EITHER federally taxable Social Security ('social_security') OR up to $10,000 of Civil Service Retirement System / other non-Social-Security contributory system income ('contributory_system'); only one may be elected (us.vt.retirement_income_exclusion).",
    default: { value: "none", rationale: "Assumed no election — the exclusion is claimed only when the filer elects it" },
  },
  {
    id: "vtTaxableSocialSecurity",
    type: "money",
    description:
      "Federal Form 1040 line 6b: federally taxable Social Security benefits — excluded in full at federal AGI up to $55,000 ($70,000 joint), phased out to $65,000 ($80,000 joint), when the Social Security election is made (us.vt.retirement_income_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtContributorySystemIncome",
    type: "money",
    description:
      "Retirement Income Exemption Worksheet line 11: income received from the Civil Service Retirement System or another contributory system of the U.S., Vermont or another state based on earnings NOT covered by Social Security — the first $10,000 is excludable on the same AGI thresholds as Social Security, when that election is made (us.vt.retirement_income_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtMilitaryRetirementIncome",
    type: "money",
    description:
      "Schedule IN-112 line 13: federally taxable U.S. military retirement income and military survivor benefit income (federal Form 1040 line 5b, DFAS 1099-R) — excluded in full at federal AGI up to $125,000, phased out to $175,000, for every filing status (us.vt.military_retirement_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtNetAdjustedCapitalGain",
    type: "money",
    description:
      "Schedule IN-153 Part I line 8: net adjusted capital gain — the smaller of federal Schedule D lines 15 and 16, less qualified dividends and other ineligible amounts, less allocated investment interest expense; the base of the $5,000 flat exclusion. Zero when the federal return shows a net capital loss (us.vt.capital_gains_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtEligibleLongTermGain",
    type: "money",
    description:
      "Schedule IN-153 Part II line 17: net adjusted capital gain from assets held MORE than three years, excluding gain on a primary or nonprimary residence, depreciable personal property (other than farm property and standing timber), and publicly traded stocks, bonds and financial instruments, less allocated investment interest — 40% is excludable up to $350,000 (us.vt.capital_gains_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtFederalTaxableIncome",
    type: "money",
    description:
      "Schedule IN-153 line 20 base: federal taxable income (Form 1040 line 15) — the capital gains exclusion cannot exceed 40% of it (us.vt.capital_gains_exclusion). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input — with no federal taxable income the exclusion is $0" },
  },
  {
    id: "vtStudentLoanInterestPaid",
    type: "money",
    description:
      "Schedule IN-112 line 16a: total interest paid in the year on qualified student loans (us.vt.student_loan_interest_subtraction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtStudentLoanInterestDeductedFederally",
    type: "money",
    description:
      "Schedule IN-112 line 16b: student loan interest already deducted on federal Form 1040 Schedule 1 line 21 — only the excess is subtracted for Vermont (us.vt.student_loan_interest_subtraction). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtCharitableContributions",
    type: "money",
    description:
      "Form IN-111 line 11: charitable contributions allowable under IRC § 170, whether or not itemized federally — the credit is 5% of the first $20,000 (us.vt.charitable_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtFederalTaxAdjustmentBase",
    type: "money",
    description:
      "Schedule IN-119 Part I line 4 (federal tax on qualified plans and tax-favored accounts, investment credit recapture, Form 4972 lump-sum tax) or Part II line 11 (federal credit for the elderly or disabled, Vermont-based investment credit, farm income averaging) — 24% of it is the Vermont adjustment (us.vt.federal_tax_adjustment). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtOtherStateIncome",
    type: "money",
    description:
      "Schedule IN-117 line 9: modified adjusted gross income taxed by the other state or Canadian province AND by Vermont — the AGI taxed there plus its bonus depreciation and non-Vermont obligation addbacks, less bonus depreciation and U.S. government interest subtracted there (us.vt.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtModifiedAgi",
    type: "money",
    description:
      "Schedule IN-117 line 17: modified Vermont adjusted gross income — federal AGI plus Schedule IN-112 lines 3 and 4, less lines 7 and 9 (us.vt.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtIncomeTax",
    type: "money",
    description:
      "Schedule IN-117 line 18: Vermont income tax from Form IN-111 line 14 (after the charitable credit, before the income adjustment and credits) (us.vt.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtOtherStateTaxPaid",
    type: "money",
    description:
      "Schedule IN-117 line 20: income tax PAID to the other state or Canadian province on the line 9 income — not withholding, not city or county tax, and not the portion of Canadian tax taken as a federal foreign tax credit (us.vt.other_state_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtFederalEic",
    type: "money",
    description:
      "Schedule IN-112 Part II line 6: the federal earned income credit from Form 1040 — Vermont allows 38% with qualifying children, 100% without (us.vt.eitc). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtEitcQualifyingChildren",
    type: "int",
    min: "0",
    description:
      "Schedule IN-112 Part II line 5: number of qualifying children from federal Schedule EIC — one or more makes the Vermont credit 38% of the federal credit; none makes it 100% (us.vt.eitc).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "vtChildrenSixOrUnder",
    type: "int",
    min: "0",
    description:
      "Schedule IN-112 Part II line 3: number of qualifying children (IRC § 152(c)) who were six years of age or younger at the close of the calendar year — born 2019 through 2025 for tax year 2025 — $1,000 each before the AGI phase-out (us.vt.child_tax_credit).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
  {
    id: "vtFederalChildCareCredit",
    type: "money",
    description:
      "Schedule IN-112 Part II line 1: the federal child and dependent care credit from Form 2441 line 11 — Vermont allows 72%, refundable (us.vt.child_dependent_care_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtVeteranDischargeRecord",
    type: "bool",
    description:
      "Schedule IN-112 Part II lines 8-12: the filer has a discharge record or other record of separation from active duty verifying service in the uniformed services — the eligibility condition for the $250 veteran credit under 32 V.S.A. § 5830g(b) (us.vt.veteran_credit).",
    default: { value: false, rationale: "Assumed not attested — the credit is claimed only with the record" },
  },
  {
    id: "vtUseTaxEstimateFromTable",
    type: "bool",
    description:
      "Use Tax Worksheet Part 1: the filer did NOT keep records of untaxed purchases under $1,000 and uses the Estimated Use Tax Table on federal AGI instead of 6% of recorded purchases (us.vt.use_tax).",
    default: { value: false, rationale: "Assumed records were kept — the table is an estimate the filer elects" },
  },
  {
    id: "vtUseTaxSmallPurchases",
    type: "money",
    description:
      "Use Tax Worksheet line 2a: total untaxed purchases of items under $1,000 each, from records (us.vt.use_tax). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtUseTaxLargePurchases",
    type: "money",
    description:
      "Use Tax Worksheet line 3a: total untaxed purchases of items $1,000 or more each — always reported item by item, even when the table estimates the small purchases (us.vt.use_tax). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtUseTaxPaidOtherState",
    type: "money",
    description:
      "Use Tax Worksheet line 3d: sales tax paid to another state on the purchases reported on lines 2a and 3a (us.vt.use_tax). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtSelfEmploymentIncome",
    type: "money",
    description:
      "Child Care Contribution Worksheet line 1: net earnings from self-employment, federal Schedule SE line 6 (us.vt.child_care_contribution). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtSelfEmploymentIncomeOutsideVermont",
    type: "money",
    description:
      "Child Care Contribution Worksheet line 2: the part of Schedule SE line 6 earned for work performed outside Vermont (us.vt.child_care_contribution). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtVheipContributions",
    type: "money",
    description:
      "Schedule IN-119 Part II line 1: contributions during the year to Vermont Higher Education Investment Plan (VHEIP / VT529) accounts — the credit is 10% of the first $2,500 per beneficiary ($5,000 on a joint return) (us.vt.vheip_credit). In dollars.",
    default: { value: "0", rationale: "Assumed $0 absent contrary input" },
  },
  {
    id: "vtVheipBeneficiaries",
    type: "int",
    min: "0",
    description:
      "Schedule IN-119 Part II line 1: the number of VHEIP account beneficiaries contributed for — each carries its own $2,500 ($5,000 joint) contribution cap (us.vt.vheip_credit).",
    default: { value: "0", rationale: "Assumed 0 absent contrary input" },
  },
];
