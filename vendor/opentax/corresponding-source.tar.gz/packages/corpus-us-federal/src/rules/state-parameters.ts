/**
 * State parameter pack v1 — the seed of the state corpus, born from the
 * finding that STALE STATE PARAMETERS caused most agent errors in
 * evaluation runs. Scope: the return-critical 2025 parameters and
 * tax schedules for IL / VA / CA (+ NY's statutory standard deduction),
 * each web-verified July 2026 from the state agency. State returns remain
 * agent-assembled; these targets pin the arithmetic and make every number
 * lookup-able instead of recalled.
 *
 * Split into per-state modules (state-il.ts / state-va.ts / state-ca.ts /
 * state-ny.ts, sharing rules/state-helpers.ts) — this file is now a thin
 * re-export so packages/corpus-us-federal/src/index.ts needs no changes.
 */

import type { Rule } from "@invaro/opentax-core";
import { ilRules } from "./state-il.js";
import { vaRules } from "./state-va.js";
import { caRules } from "./state-ca.js";
import { nyRules } from "./state-ny.js";
import { paRules } from "./state-pa.js";
import { njRules } from "./state-nj.js";
import { ohRules } from "./state-oh.js";
import { ncRules } from "./state-nc.js";
import { gaRules } from "./state-ga.js";
import { mdRules } from "./state-md.js";
import { moRules } from "./state-mo.js";
import { wiRules } from "./state-wi.js";
import { mnRules } from "./state-mn.js";
import { scRules } from "./state-sc.js";
import { alRules } from "./state-al.js";
import { orRules } from "./state-or.js";
import { okRules } from "./state-ok.js";
import { ctRules } from "./state-ct.js";
import { ksRules } from "./state-ks.js";
import { arRules } from "./state-ar.js";
import { nmRules } from "./state-nm.js";
import { neRules } from "./state-ne.js";
import { idRules } from "./state-id.js";
import { wvRules } from "./state-wv.js";
import { meRules } from "./state-me.js";
import { hiRules } from "./state-hi.js";
import { riRules } from "./state-ri.js";
import { mtRules } from "./state-mt.js";
import { deRules } from "./state-de.js";
import { ndRules } from "./state-nd.js";
import { vtRules } from "./state-vt.js";
import { otherStateRules } from "./state-other.js";

export const stateParameterRules: Rule[] = [
  ...ilRules,
  ...vaRules,
  ...caRules,
  ...nyRules,
  ...paRules,
  ...njRules,
  ...ohRules,
  ...ncRules,
  ...gaRules,
  ...mdRules,
  ...moRules,
  ...wiRules,
  ...mnRules,
  ...scRules,
  ...alRules,
  ...orRules,
  ...okRules,
  ...ctRules,
  ...ksRules,
  ...arRules,
  ...nmRules,
  ...neRules,
  ...idRules,
  ...wvRules,
  ...meRules,
  ...hiRules,
  ...riRules,
  ...mtRules,
  ...deRules,
  ...ndRules,
  ...vtRules,
  ...otherStateRules,
];
